import json


def test_canonical_json_order_is_stable():
    left = json.dumps({"b": 2, "a": 1}, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    right = json.dumps({"a": 1, "b": 2}, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    assert left == right == '{"a":1,"b":2}'
