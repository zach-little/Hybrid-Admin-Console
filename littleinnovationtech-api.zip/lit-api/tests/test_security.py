from app.security import hash_password, verify_password, validate_password


def test_password_hash_round_trip():
    password = "ThisIsATestPassword!123"
    digest = hash_password(password)
    valid, _ = verify_password(digest, password)
    assert valid


def test_password_policy():
    validate_password("LongEnoughPassword123!")
