# Little Innovation Tech Account & Licensing API

Standalone API for the Little Innovation Tech customer portal and HILOP licensing service.

## Service boundary

- Static website/customer portal -> `lit-api`
- HILOP installations -> `lit-api`
- `lit-api` -> `lit-vault` PostgreSQL over the private `lit-services` Docker network
- PostgreSQL is not exposed publicly
- Ed25519 private signing material is mounted into `lit-api` read-only and is never stored in PostgreSQL

## Implemented API

### Account

- `POST /api/v1/account/register`
- `POST /api/v1/account/login`
- `POST /api/v1/account/logout`
- `GET /api/v1/account/me`
- `GET /api/v1/account/organization`
- `PATCH /api/v1/account/organization`
- `GET /api/v1/account/members`
- `GET /api/v1/account/licenses`
- `GET /api/v1/account/licenses/{license_id}`
- `POST /api/v1/account/licenses/{license_id}/activation-keys`
- `POST /api/v1/account/licenses/{license_id}/activation-keys/{key_id}/revoke`
- `POST /api/v1/account/licenses/{license_id}/installations/{installation_id}/deactivate`
- `POST /api/v1/account/trials`
- email-verification and password-reset endpoints

Browser sessions are opaque random tokens stored as hashes in `user_sessions` and delivered as Secure, HttpOnly, SameSite=Lax cookies.

### HILOP

- `POST /api/v1/hilop/activate`
- `POST /api/v1/hilop/license/refresh`
- `POST /api/v1/hilop/deactivate`
- `GET /.well-known/hilop-license-key`

Activation exchanges a one-time/display-once activation key for an installation credential. Installation credentials are stored only as hashes.

Signed license responses contain:

- parsed `payload`
- `payload_b64`, the exact UTF-8 JSON bytes that were signed
- Ed25519 `signature`
- `key_id`

HILOP should verify the signature against `payload_b64`, then parse those verified bytes. It should not trust a separately reserialized JSON object.

### Internal admin

Requires the `X-LIT-Admin-Key` header.

- `GET/POST /api/v1/admin/organizations`
- `GET/POST /api/v1/admin/licenses`
- `POST /api/v1/admin/licenses/{license_id}/activation-keys`
- `POST /api/v1/admin/licenses/{license_id}/revoke`
- `GET /api/v1/admin/trials`
- `POST /api/v1/admin/trials/{trial_id}/approve`

The admin key is an initial internal-control mechanism until a dedicated staff/admin identity plane is built.

## Important activation-key behavior

Activation key plaintext is never persisted. The API returns it only when generated. The database stores an HMAC-SHA256 digest using `ACTIVATION_KEY_PEPPER`, plus prefix/last-four metadata.

If a key is lost, generate a replacement; do not add a plaintext recovery mechanism.

## Email status

SMTP integration is implemented but defaults to:

```text
SMTP_MODE=disabled
REQUIRE_EMAIL_VERIFICATION=false
```

This lets the account API function before a transactional-email provider is selected. Configure SMTP first, then set `REQUIRE_EMAIL_VERIFICATION=true` if desired.

## Citadel deployment

Expected paths:

```text
/opt/littlecastle/apps/lit-api/
/opt/littlecastle/secrets/lit-licensing-app.env
/opt/littlecastle/secrets/lit-api.env
/opt/littlecastle/secrets/hilop-signing/
```

Existing Docker resources:

```text
lit-vault
lit-services
```

### 1. Generate API and signing secrets

```bash
cd /opt/littlecastle/apps/lit-api
./deploy/create-secrets.sh
```

The script creates an Ed25519 signing key and two unrelated 256-bit secrets: the internal admin API key and the activation-key HMAC pepper.

### 2. Build and start the API

```bash
cd /opt/littlecastle/apps/lit-api
./deploy/run-lit-api.sh
```

No host port is published. `lit-api` is reachable only through the Docker network until nginx is connected and configured.

### 3. Connect nginx to the private service network

```bash
docker network connect lit-services littlecastle-nginx 2>/dev/null || true
```

Add the contents of `deploy/nginx-lit-api.conf` inside the existing `littleinnovation.tech` nginx `server` block, then validate and reload:

```bash
docker exec littlecastle-nginx nginx -t
docker exec littlecastle-nginx nginx -s reload
```

### 4. Smoke test

```bash
cd /opt/littlecastle/apps/lit-api
./scripts/smoke-test.sh
```

Expected public endpoints:

```text
https://littleinnovation.tech/api/v1/health/live
https://littleinnovation.tech/api/v1/health/ready
https://littleinnovation.tech/.well-known/hilop-license-key
```

## Retrieve the internal admin API key

Use only on Citadel/admin-controlled systems:

```bash
sudo awk -F= '$1=="ADMIN_API_KEY"{print $2}' /opt/littlecastle/secrets/lit-api.env
```

Avoid putting the key into shell history. A safer temporary shell pattern is:

```bash
read -r ADMIN_API_KEY < <(sudo awk -F= '$1=="ADMIN_API_KEY"{print $2}' /opt/littlecastle/secrets/lit-api.env)
```

Then use:

```bash
-H "X-LIT-Admin-Key: $ADMIN_API_KEY"
```

and clear it afterward:

```bash
unset ADMIN_API_KEY
```

## Example: create a paid HILOP license

First obtain an organization UUID from:

```bash
curl -fsS \
  -H "X-LIT-Admin-Key: $ADMIN_API_KEY" \
  'https://littleinnovation.tech/api/v1/admin/organizations'
```

Then create a license:

```bash
curl -fsS \
  -H "X-LIT-Admin-Key: $ADMIN_API_KEY" \
  -H 'Content-Type: application/json' \
  -X POST \
  https://littleinnovation.tech/api/v1/admin/licenses \
  -d '{
    "organization_id":"ORGANIZATION-UUID-HERE",
    "license_type":"subscription",
    "edition":"professional",
    "expires_at":"2027-08-16T23:59:59Z",
    "grace_until":"2027-08-30T23:59:59Z",
    "max_installations":2,
    "entitlements":{
      "active_directory":true,
      "entra_id":true,
      "exchange_online":true,
      "exchange_onprem":true,
      "automation":true,
      "advanced_workflows":true,
      "reporting":true,
      "api_access":true,
      "managed_identities":5000,
      "administrators":10,
      "directories":5
    }
  }'
```

The response contains the license UUID. Generate an activation key with:

```bash
curl -fsS \
  -H "X-LIT-Admin-Key: $ADMIN_API_KEY" \
  -H 'Content-Type: application/json' \
  -X POST \
  https://littleinnovation.tech/api/v1/admin/licenses/LICENSE-UUID-HERE/activation-keys \
  -d '{"max_uses":1}'
```

Save the returned `activation_key` at that moment. It cannot be recovered later.

## Example: approve a pending trial

```bash
curl -fsS \
  -H "X-LIT-Admin-Key: $ADMIN_API_KEY" \
  'https://littleinnovation.tech/api/v1/admin/trials?status=pending'
```

Approve one with:

```bash
curl -fsS \
  -H "X-LIT-Admin-Key: $ADMIN_API_KEY" \
  -H 'Content-Type: application/json' \
  -X POST \
  https://littleinnovation.tech/api/v1/admin/trials/TRIAL-UUID-HERE/approve \
  -d '{
    "duration_days":30,
    "grace_days":3,
    "edition":"professional",
    "max_installations":1,
    "entitlements":{
      "active_directory":true,
      "entra_id":true,
      "exchange_online":true,
      "exchange_onprem":true,
      "automation":true,
      "advanced_workflows":true,
      "reporting":true,
      "api_access":true,
      "managed_identities":500,
      "administrators":3,
      "directories":3
    }
  }'
```

The response creates the trial license and returns a display-once activation key.

## Signing-key rotation

Never replace key material while reusing the same `SIGNING_KEY_ID`. On startup the API checks the database and refuses to start if a known key ID resolves to different public-key material.

For rotation, generate a new private key, choose a new key ID, deploy it, and later teach HILOP to trust both the old and new public keys during the transition.

## Current deliberate limitations

- Portal JavaScript is not yet wired to these endpoints.
- SMTP is disabled until configured.
- Internal admin operations use one server-side API key rather than staff accounts/RBAC.
- Rate limiting is process-local. The supplied deployment intentionally runs one Uvicorn worker. If the API is horizontally scaled, move rate limiting to a shared store or reverse-proxy layer.
- Billing/Stripe integration is not included.
