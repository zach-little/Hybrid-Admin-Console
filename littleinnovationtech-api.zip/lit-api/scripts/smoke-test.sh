#!/usr/bin/env sh
set -eu

BASE_URL="${1:-https://littleinnovation.tech}"

echo "Live:"
curl -fsS "$BASE_URL/api/v1/health/live"
printf '\n\nReady:\n'
curl -fsS "$BASE_URL/api/v1/health/ready"
printf '\n\nHILOP public key:\n'
curl -fsS "$BASE_URL/.well-known/hilop-license-key"
printf '\n'
