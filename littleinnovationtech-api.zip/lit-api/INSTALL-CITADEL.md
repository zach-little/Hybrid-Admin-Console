# Citadel install — Little Innovation Tech Account & Licensing API

Target directory:

```text
/opt/littlecastle/apps/lit-api/
```

Prerequisites already established:

```text
lit-vault
lit-services
/opt/littlecastle/secrets/lit-licensing-app.env
```

## Install files

From Windows PowerShell:

```powershell
scp .\LittleInnovationTech_LIT_API_2026-08-16.zip citadel:/tmp/
ssh citadel
```

On Citadel:

```bash
sudo mkdir -p /opt/littlecastle/apps
cd /opt/littlecastle/apps
sudo unzip -o /tmp/LittleInnovationTech_LIT_API_2026-08-16.zip -d /opt/littlecastle/apps/
sudo chown -R root:root /opt/littlecastle/apps/lit-api
sudo chmod +x /opt/littlecastle/apps/lit-api/deploy/*.sh /opt/littlecastle/apps/lit-api/scripts/*.sh
```

## Generate secrets and Ed25519 key

```bash
cd /opt/littlecastle/apps/lit-api
./deploy/create-secrets.sh
```

Back up `/opt/littlecastle/secrets/hilop-signing/` securely. The private signing key must persist across normal API rebuilds/redeployments.

## Build/start API

```bash
cd /opt/littlecastle/apps/lit-api
./deploy/run-lit-api.sh
```

Check:

```bash
docker ps --filter name=lit-api
docker logs --tail 100 lit-api
```

## Connect nginx network

```bash
docker network connect lit-services littlecastle-nginx 2>/dev/null || true
```

Inspect nginx mounts and current server block:

```bash
docker inspect littlecastle-nginx --format '{{range .Mounts}}{{println .Source "->" .Destination}}{{end}}'
docker exec littlecastle-nginx nginx -T 2>&1 | grep -n -A40 -B5 'server_name.*littleinnovation.tech'
```

Add the two `location` blocks from:

```text
/opt/littlecastle/apps/lit-api/deploy/nginx-lit-api.conf
```

inside the existing `littleinnovation.tech` `server { ... }` block in the persistent host nginx config.

Validate/reload:

```bash
docker exec littlecastle-nginx nginx -t
docker exec littlecastle-nginx nginx -s reload
```

## Smoke test

```bash
cd /opt/littlecastle/apps/lit-api
./scripts/smoke-test.sh
```

Then verify container health:

```bash
docker inspect lit-api --format '{{.State.Health.Status}}'
```
