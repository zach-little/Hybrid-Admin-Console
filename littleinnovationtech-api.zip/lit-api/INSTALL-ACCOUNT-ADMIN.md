# Platform-admin account migration

The internal licensing console now uses the normal Little Innovation Tech account session. Browser access requires `users.is_platform_admin = true`. `ADMIN_API_KEY` remains only as a break-glass/CLI credential.

## 1. Apply migration

```bash
sudo docker exec -i lit-vault psql -U lit_licensing_owner -d lit_licensing -v ON_ERROR_STOP=1 < /opt/littlecastle/apps/lit-api/migrations/2026-08-16-platform-admin.sql
```

## 2. Flag your account

Replace `YOUR_EMAIL@example.com` with the email address you use to sign into the Little Innovation Tech customer portal.

```bash
sudo docker exec lit-vault \
  psql -U lit_licensing_owner -d lit_licensing -v ON_ERROR_STOP=1 \
  -c "UPDATE users SET is_platform_admin=true, updated_at=now() WHERE email='YOUR_EMAIL@example.com' RETURNING id,email,is_platform_admin;"
```

If the command returns zero rows, register/sign in to the customer portal first so the account exists in `users`.

## 3. Rebuild API

```bash
cd /opt/littlecastle/apps/lit-api
sudo ./deploy/run-lit-api.sh
```

## 4. Verify

Sign in at `https://littleinnovation.tech/internal-admin-login` using your normal account email/password.

To revoke platform-admin access later:

```bash
sudo docker exec lit-vault \
  psql -U lit_licensing_owner -d lit_licensing -v ON_ERROR_STOP=1 \
  -c "UPDATE users SET is_platform_admin=false, updated_at=now() WHERE email='YOUR_EMAIL@example.com' RETURNING email,is_platform_admin;"
```
