from __future__ import annotations

import re
from datetime import timedelta
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Request

from .audit import write_audit
from .db import get_pool
from .dependencies import client_ip, require_admin, require_admin_write
from .licensing import create_activation_key, generate_license_number, set_entitlements
from .schemas import (
    AdminActivationKeyCreate,
    AdminLicenseCreate,
    AdminLicenseRevoke,
    AdminLicenseUpdate,
    AdminOrganizationCreate,
    AdminOrganizationUpdate,
    AdminTrialApprove,
    AdminTrialDecline,
)
from .security import utcnow

router = APIRouter(prefix="/api/v1/admin", tags=["admin"], dependencies=[Depends(require_admin)])


def _slug(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")[:120] or "organization"


def _unique_slug(conn, value: str) -> str:
    base = _slug(value)
    candidate = base
    i = 2
    while conn.execute("SELECT 1 FROM organizations WHERE slug=%s", (candidate,)).fetchone():
        candidate = f"{base[:110]}-{i}"
        i += 1
    return candidate


def _id(value):
    return str(value) if value is not None else None




def _admin_actor(request: Request):
    return getattr(request.state, "admin_user_id", None)

def _audit_rows(rows):
    return [
        {
            **row,
            "actor_user_id": _id(row.get("actor_user_id")),
            "organization_id": _id(row.get("organization_id")),
            "license_id": _id(row.get("license_id")),
            "installation_id": _id(row.get("installation_id")),
        }
        for row in rows
    ]


@router.get("/dashboard")
def dashboard():
    with get_pool().connection() as conn:
        metrics = conn.execute(
            """
            SELECT
              (SELECT count(*) FROM organizations WHERE status='active') AS organizations,
              (SELECT count(*) FROM licenses WHERE status='active') AS active_licenses,
              (SELECT count(*) FROM trial_requests WHERE status='pending') AS pending_trials,
              (SELECT count(*) FROM installations WHERE status='active') AS active_installations,
              (SELECT count(*) FROM licenses WHERE status='active' AND expires_at IS NOT NULL
                 AND expires_at > now() AND expires_at <= now() + interval '30 days') AS expiring_30d
            """
        ).fetchone()
        trials = conn.execute(
            """
            SELECT tr.id,tr.status,tr.requested_edition,tr.use_case,tr.requested_at,
                   o.id AS organization_id,o.name AS organization_name,u.email::text AS requester_email
            FROM trial_requests tr
            JOIN organizations o ON o.id=tr.organization_id
            LEFT JOIN users u ON u.id=tr.requested_by_user_id
            WHERE tr.status='pending'
            ORDER BY tr.requested_at
            LIMIT 10
            """
        ).fetchall()
        licenses = conn.execute(
            """
            SELECT l.id,l.license_number::text AS license_number,l.license_type,l.edition,l.status,
                   l.expires_at,o.id AS organization_id,o.name AS organization_name
            FROM licenses l JOIN organizations o ON o.id=l.organization_id
            ORDER BY l.created_at DESC LIMIT 10
            """
        ).fetchall()
        audits = conn.execute(
            """
            SELECT a.id,a.event_type,a.actor_type,a.actor_user_id,a.organization_id,a.license_id,
                   a.installation_id,a.metadata,a.created_at,o.name AS organization_name,
                   l.license_number::text AS license_number
            FROM audit_events a
            LEFT JOIN organizations o ON o.id=a.organization_id
            LEFT JOIN licenses l ON l.id=a.license_id
            ORDER BY a.created_at DESC LIMIT 12
            """
        ).fetchall()
    return {
        "metrics": dict(metrics),
        "pending_trials": [
            {**row, "id": _id(row["id"]), "organization_id": _id(row["organization_id"])} for row in trials
        ],
        "recent_licenses": [
            {**row, "id": _id(row["id"]), "organization_id": _id(row["organization_id"])} for row in licenses
        ],
        "recent_audit": _audit_rows(audits),
    }


@router.get("/entitlements")
def list_entitlement_definitions():
    with get_pool().connection() as conn:
        rows = conn.execute(
            """
            SELECT ed.id,p.code::text AS product,ed.entitlement_key::text AS entitlement_key,
                   ed.display_name,ed.value_type,ed.description
            FROM entitlement_definitions ed JOIN products p ON p.id=ed.product_id
            WHERE p.status='active'
            ORDER BY p.code,ed.value_type,ed.display_name
            """
        ).fetchall()
    return [{**row, "id": _id(row["id"])} for row in rows]


@router.get("/organizations")
def list_organizations(q: str | None = Query(default=None, max_length=160)):
    params = []
    where = ""
    if q:
        pattern = f"%{q}%"
        where = "WHERE o.name ILIKE %s OR o.slug::text ILIKE %s OR o.licensing_email::text ILIKE %s"
        params = [pattern, pattern, pattern]
    with get_pool().connection() as conn:
        rows = conn.execute(
            f"""
            SELECT o.id,o.name,o.slug::text AS slug,o.licensing_email::text AS licensing_email,o.status,o.created_at,
                   count(DISTINCT om.user_id) FILTER (WHERE om.status='active') AS member_count,
                   count(DISTINCT l.id) AS license_count,
                   count(DISTINCT i.id) FILTER (WHERE i.status='active') AS active_installations
            FROM organizations o
            LEFT JOIN organization_members om ON om.organization_id=o.id
            LEFT JOIN licenses l ON l.organization_id=o.id
            LEFT JOIN installations i ON i.license_id=l.id
            {where}
            GROUP BY o.id
            ORDER BY o.created_at DESC LIMIT 100
            """,
            params,
        ).fetchall()
    return [{**row, "id": _id(row["id"])} for row in rows]


@router.post("/organizations", status_code=201, dependencies=[Depends(require_admin_write)])
def create_organization(payload: AdminOrganizationCreate, request: Request):
    with get_pool().connection() as conn:
        with conn.transaction():
            slug = payload.slug.strip().lower() if payload.slug else _unique_slug(conn, payload.name)
            if conn.execute("SELECT 1 FROM organizations WHERE slug=%s", (slug,)).fetchone():
                raise HTTPException(status_code=409, detail="Organization slug already exists")
            row = conn.execute(
                "INSERT INTO organizations(name,slug,licensing_email) VALUES (%s,%s,%s) RETURNING id,name,slug::text AS slug",
                (payload.name.strip(), slug, str(payload.licensing_email).lower() if payload.licensing_email else None),
            ).fetchone()
            write_audit(conn, "ORGANIZATION_CREATED", actor_type="admin", actor_user_id=_admin_actor(request), organization_id=row["id"], ip_address=client_ip(request))
    return {**row, "id": _id(row["id"])}


@router.get("/organizations/{organization_id}")
def organization_detail(organization_id: UUID):
    with get_pool().connection() as conn:
        org = conn.execute(
            """
            SELECT id,name,slug::text AS slug,licensing_email::text AS licensing_email,status,created_at,updated_at
            FROM organizations WHERE id=%s
            """,
            (organization_id,),
        ).fetchone()
        if not org:
            raise HTTPException(status_code=404, detail="Organization not found")
        members = conn.execute(
            """
            SELECT u.id,u.email::text AS email,u.first_name,u.last_name,u.display_name,u.email_verified_at,
                   u.last_login_at,om.role,om.status,om.joined_at
            FROM organization_members om JOIN users u ON u.id=om.user_id
            WHERE om.organization_id=%s
            ORDER BY CASE om.role WHEN 'owner' THEN 0 WHEN 'admin' THEN 1 ELSE 2 END,u.email
            """,
            (organization_id,),
        ).fetchall()
        licenses = conn.execute(
            """
            SELECT l.id,l.license_number::text AS license_number,l.license_type,l.edition,l.status,
                   l.valid_from,l.expires_at,l.grace_until,l.max_installations,
                   count(i.id) FILTER (WHERE i.status='active') AS active_installations
            FROM licenses l LEFT JOIN installations i ON i.license_id=l.id
            WHERE l.organization_id=%s GROUP BY l.id ORDER BY l.created_at DESC
            """,
            (organization_id,),
        ).fetchall()
        trials = conn.execute(
            """
            SELECT id,requested_edition,status,use_case,requested_at,decided_at,approved_license_id
            FROM trial_requests WHERE organization_id=%s ORDER BY requested_at DESC
            """,
            (organization_id,),
        ).fetchall()
        audits = conn.execute(
            """
            SELECT id,event_type,actor_type,actor_user_id,organization_id,license_id,installation_id,metadata,created_at
            FROM audit_events WHERE organization_id=%s ORDER BY created_at DESC LIMIT 30
            """,
            (organization_id,),
        ).fetchall()
    return {
        "organization": {**org, "id": _id(org["id"])},
        "members": [{**row, "id": _id(row["id"])} for row in members],
        "licenses": [{**row, "id": _id(row["id"])} for row in licenses],
        "trials": [{**row, "id": _id(row["id"]), "approved_license_id": _id(row["approved_license_id"])} for row in trials],
        "audit": _audit_rows(audits),
    }


@router.patch("/organizations/{organization_id}", dependencies=[Depends(require_admin_write)])
def update_organization(organization_id: UUID, payload: AdminOrganizationUpdate, request: Request):
    with get_pool().connection() as conn:
        with conn.transaction():
            current = conn.execute("SELECT * FROM organizations WHERE id=%s FOR UPDATE", (organization_id,)).fetchone()
            if not current:
                raise HTTPException(status_code=404, detail="Organization not found")
            fields = payload.model_fields_set
            name = payload.name.strip() if "name" in fields and payload.name else current["name"]
            licensing_email = str(payload.licensing_email).lower() if "licensing_email" in fields and payload.licensing_email else (None if "licensing_email" in fields else current["licensing_email"])
            org_status = payload.status if "status" in fields and payload.status else current["status"]
            row = conn.execute(
                """
                UPDATE organizations SET name=%s,licensing_email=%s,status=%s,updated_at=now()
                WHERE id=%s RETURNING id,name,slug::text AS slug,licensing_email::text AS licensing_email,status,updated_at
                """,
                (name, licensing_email, org_status, organization_id),
            ).fetchone()
            write_audit(
                conn,
                "ORGANIZATION_UPDATED",
                actor_type="admin", actor_user_id=_admin_actor(request),
                organization_id=organization_id,
                ip_address=client_ip(request),
                metadata={"fields": sorted(fields)},
            )
    return {**row, "id": _id(row["id"])}


@router.get("/licenses")
def list_licenses(
    organization_id: UUID | None = None,
    license_status: str | None = Query(default=None, alias="status"),
    q: str | None = Query(default=None, max_length=160),
):
    clauses = []
    params = []
    if organization_id:
        clauses.append("l.organization_id=%s")
        params.append(organization_id)
    if license_status:
        clauses.append("l.status=%s")
        params.append(license_status)
    if q:
        clauses.append("(l.license_number::text ILIKE %s OR o.name ILIKE %s OR l.edition ILIKE %s)")
        pattern = f"%{q}%"
        params.extend([pattern, pattern, pattern])
    where = " WHERE " + " AND ".join(clauses) if clauses else ""
    with get_pool().connection() as conn:
        rows = conn.execute(
            f"""
            SELECT l.id,l.license_number::text AS license_number,l.license_type,l.edition,l.status,
                   l.valid_from,l.expires_at,l.grace_until,l.max_installations,o.id AS organization_id,o.name AS organization_name,
                   count(i.id) FILTER (WHERE i.status='active') AS active_installations
            FROM licenses l JOIN organizations o ON o.id=l.organization_id
            LEFT JOIN installations i ON i.license_id=l.id
            {where}
            GROUP BY l.id,o.id ORDER BY l.created_at DESC LIMIT 200
            """,
            params,
        ).fetchall()
    return [{**row, "id": _id(row["id"]), "organization_id": _id(row["organization_id"])} for row in rows]


@router.post("/licenses", status_code=201, dependencies=[Depends(require_admin_write)])
def create_license(payload: AdminLicenseCreate, request: Request):
    now = utcnow()
    valid_from = payload.valid_from or now
    with get_pool().connection() as conn:
        with conn.transaction():
            org = conn.execute("SELECT id FROM organizations WHERE id=%s AND status='active'", (payload.organization_id,)).fetchone()
            if not org:
                raise HTTPException(status_code=404, detail="Active organization not found")
            product = conn.execute("SELECT id FROM products WHERE code='HILOP' AND status='active'").fetchone()
            if not product:
                raise HTTPException(status_code=503, detail="HILOP product unavailable")
            if payload.expires_at and payload.expires_at <= valid_from:
                raise HTTPException(status_code=400, detail="expires_at must be after valid_from")
            if payload.grace_until and payload.expires_at and payload.grace_until < payload.expires_at:
                raise HTTPException(status_code=400, detail="grace_until must not be before expires_at")
            license_number = generate_license_number(conn)
            row = conn.execute(
                """
                INSERT INTO licenses(
                    organization_id,product_id,license_number,license_type,edition,status,valid_from,expires_at,
                    grace_until,maintenance_until,max_installations,notes
                )
                VALUES (%s,%s,%s,%s,%s,'active',%s,%s,%s,%s,%s,%s)
                RETURNING id,license_number::text AS license_number
                """,
                (
                    payload.organization_id, product["id"], license_number, payload.license_type, payload.edition,
                    valid_from, payload.expires_at, payload.grace_until, payload.maintenance_until,
                    payload.max_installations, payload.notes,
                ),
            ).fetchone()
            set_entitlements(conn, row["id"], product["id"], payload.entitlements)
            write_audit(conn, "LICENSE_CREATED", actor_type="admin", actor_user_id=_admin_actor(request), organization_id=payload.organization_id, license_id=row["id"], ip_address=client_ip(request))
    return {"id": _id(row["id"]), "license_number": row["license_number"], "status": "active"}


@router.get("/licenses/{license_id}")
def license_detail(license_id: UUID):
    with get_pool().connection() as conn:
        license_row = conn.execute(
            """
            SELECT l.*,l.license_number::text AS license_number,p.code::text AS product,o.name AS organization_name,
                   o.id AS organization_id
            FROM licenses l JOIN products p ON p.id=l.product_id JOIN organizations o ON o.id=l.organization_id
            WHERE l.id=%s
            """,
            (license_id,),
        ).fetchone()
        if not license_row:
            raise HTTPException(status_code=404, detail="License not found")
        entitlements = conn.execute(
            """
            SELECT ed.id,ed.entitlement_key::text AS entitlement_key,ed.display_name,ed.value_type,ed.description,le.value
            FROM entitlement_definitions ed
            LEFT JOIN license_entitlements le ON le.entitlement_definition_id=ed.id AND le.license_id=%s
            WHERE ed.product_id=%s ORDER BY ed.value_type,ed.display_name
            """,
            (license_id, license_row["product_id"]),
        ).fetchall()
        keys = conn.execute(
            """
            SELECT id,key_prefix,last_four,status,max_uses,uses_count,expires_at,created_at,last_used_at,revoked_at
            FROM activation_keys WHERE license_id=%s ORDER BY created_at DESC
            """,
            (license_id,),
        ).fetchall()
        installations = conn.execute(
            """
            SELECT id,installation_id,display_name,hostname,hilop_version,status,activated_at,last_seen_at,deactivated_at,revoked_at
            FROM installations WHERE license_id=%s ORDER BY activated_at DESC
            """,
            (license_id,),
        ).fetchall()
        documents = conn.execute(
            "SELECT count(*) AS total,max(issued_at) AS last_issued_at FROM license_documents WHERE license_id=%s",
            (license_id,),
        ).fetchone()
        audits = conn.execute(
            """
            SELECT id,event_type,actor_type,actor_user_id,organization_id,license_id,installation_id,metadata,created_at
            FROM audit_events WHERE license_id=%s ORDER BY created_at DESC LIMIT 40
            """,
            (license_id,),
        ).fetchall()
    data = dict(license_row)
    for key in ("id", "organization_id", "product_id", "created_by_user_id"):
        data[key] = _id(data.get(key))
    return {
        "license": data,
        "entitlements": [{**row, "id": _id(row["id"])} for row in entitlements],
        "activation_keys": [{**row, "id": _id(row["id"])} for row in keys],
        "installations": [{**row, "id": _id(row["id"])} for row in installations],
        "documents": dict(documents),
        "audit": _audit_rows(audits),
    }


@router.patch("/licenses/{license_id}", dependencies=[Depends(require_admin_write)])
def update_license(license_id: UUID, payload: AdminLicenseUpdate, request: Request):
    fields = payload.model_fields_set
    with get_pool().connection() as conn:
        with conn.transaction():
            current = conn.execute("SELECT * FROM licenses WHERE id=%s FOR UPDATE", (license_id,)).fetchone()
            if not current:
                raise HTTPException(status_code=404, detail="License not found")
            if current["status"] == "revoked":
                raise HTTPException(status_code=409, detail="Revoked licenses cannot be edited")
            valid_from = payload.valid_from if "valid_from" in fields else current["valid_from"]
            if valid_from is None:
                raise HTTPException(status_code=400, detail="valid_from cannot be null")
            expires_at = payload.expires_at if "expires_at" in fields else current["expires_at"]
            grace_until = payload.grace_until if "grace_until" in fields else current["grace_until"]
            maintenance_until = payload.maintenance_until if "maintenance_until" in fields else current["maintenance_until"]
            if expires_at and expires_at <= valid_from:
                raise HTTPException(status_code=400, detail="expires_at must be after valid_from")
            if grace_until and expires_at and grace_until < expires_at:
                raise HTTPException(status_code=400, detail="grace_until must not be before expires_at")
            edition = payload.edition if "edition" in fields and payload.edition else current["edition"]
            license_status = payload.status if "status" in fields and payload.status else current["status"]
            max_installations = payload.max_installations if "max_installations" in fields else current["max_installations"]
            notes = payload.notes if "notes" in fields else current["notes"]
            row = conn.execute(
                """
                UPDATE licenses SET edition=%s,status=%s,valid_from=%s,expires_at=%s,grace_until=%s,
                    maintenance_until=%s,max_installations=%s,notes=%s,updated_at=now()
                WHERE id=%s
                RETURNING id,license_number::text AS license_number,status,updated_at
                """,
                (edition, license_status, valid_from, expires_at, grace_until, maintenance_until, max_installations, notes, license_id),
            ).fetchone()
            if payload.entitlements is not None:
                set_entitlements(conn, license_id, current["product_id"], payload.entitlements)
            write_audit(
                conn, "LICENSE_UPDATED", actor_type="admin", actor_user_id=_admin_actor(request), organization_id=current["organization_id"],
                license_id=license_id, ip_address=client_ip(request), metadata={"fields": sorted(fields)},
            )
    return {**row, "id": _id(row["id"])}


@router.post("/licenses/{license_id}/activation-keys", status_code=201, dependencies=[Depends(require_admin_write)])
def admin_activation_key(license_id: UUID, payload: AdminActivationKeyCreate, request: Request):
    with get_pool().connection() as conn:
        with conn.transaction():
            license_row = conn.execute("SELECT id,organization_id,status FROM licenses WHERE id=%s", (license_id,)).fetchone()
            if not license_row:
                raise HTTPException(status_code=404, detail="License not found")
            if license_row["status"] not in {"active", "draft"}:
                raise HTTPException(status_code=409, detail="License is not eligible for activation keys")
            key = create_activation_key(conn, license_id, max_uses=payload.max_uses, expires_at=payload.expires_at)
            write_audit(conn, "ACTIVATION_KEY_GENERATED", actor_type="admin", actor_user_id=_admin_actor(request), organization_id=license_row["organization_id"], license_id=license_id, ip_address=client_ip(request), metadata={"activation_key_id": key["id"]})
    return {**key, "display_once": True}


@router.post("/licenses/{license_id}/activation-keys/{key_id}/revoke", dependencies=[Depends(require_admin_write)])
def admin_revoke_activation_key(license_id: UUID, key_id: UUID, request: Request):
    with get_pool().connection() as conn:
        with conn.transaction():
            row = conn.execute(
                """
                UPDATE activation_keys ak SET status='revoked',revoked_at=now()
                FROM licenses l
                WHERE ak.id=%s AND ak.license_id=%s AND l.id=ak.license_id AND ak.status='active'
                RETURNING l.organization_id
                """,
                (key_id, license_id),
            ).fetchone()
            if not row:
                raise HTTPException(status_code=404, detail="Active activation key not found")
            write_audit(conn, "ACTIVATION_KEY_REVOKED", actor_type="admin", actor_user_id=_admin_actor(request), organization_id=row["organization_id"], license_id=license_id, ip_address=client_ip(request), metadata={"activation_key_id": str(key_id)})
    return {"revoked": True}


@router.post("/licenses/{license_id}/installations/{installation_id}/deactivate", dependencies=[Depends(require_admin_write)])
def admin_deactivate_installation(license_id: UUID, installation_id: UUID, request: Request):
    with get_pool().connection() as conn:
        with conn.transaction():
            row = conn.execute(
                """
                SELECT i.id,l.organization_id FROM installations i JOIN licenses l ON l.id=i.license_id
                WHERE i.id=%s AND i.license_id=%s FOR UPDATE
                """,
                (installation_id, license_id),
            ).fetchone()
            if not row:
                raise HTTPException(status_code=404, detail="Installation not found")
            conn.execute("UPDATE installations SET status='deactivated',deactivated_at=now(),updated_at=now() WHERE id=%s", (installation_id,))
            conn.execute("UPDATE installation_credentials SET status='revoked',revoked_at=now() WHERE installation_id=%s AND status='active'", (installation_id,))
            write_audit(conn, "INSTALLATION_DEACTIVATED", actor_type="admin", actor_user_id=_admin_actor(request), organization_id=row["organization_id"], license_id=license_id, installation_id=installation_id, ip_address=client_ip(request))
    return {"deactivated": True}


@router.post("/licenses/{license_id}/revoke", dependencies=[Depends(require_admin_write)])
def revoke_license(license_id: UUID, payload: AdminLicenseRevoke, request: Request):
    with get_pool().connection() as conn:
        with conn.transaction():
            row = conn.execute(
                """
                UPDATE licenses SET status='revoked',revoked_at=now(),revoked_reason=%s,updated_at=now()
                WHERE id=%s AND status<>'revoked' RETURNING organization_id
                """,
                (payload.reason, license_id),
            ).fetchone()
            if not row:
                raise HTTPException(status_code=404, detail="Active license not found")
            conn.execute("UPDATE activation_keys SET status='revoked',revoked_at=now() WHERE license_id=%s AND status='active'", (license_id,))
            conn.execute("UPDATE installations SET status='revoked',revoked_at=now(),updated_at=now() WHERE license_id=%s AND status='active'", (license_id,))
            conn.execute(
                """
                UPDATE installation_credentials ic SET status='revoked',revoked_at=now()
                FROM installations i WHERE ic.installation_id=i.id AND i.license_id=%s AND ic.status='active'
                """,
                (license_id,),
            )
            write_audit(conn, "LICENSE_REVOKED", actor_type="admin", actor_user_id=_admin_actor(request), organization_id=row["organization_id"], license_id=license_id, ip_address=client_ip(request), metadata={"reason": payload.reason})
    return {"revoked": True}


@router.get("/trials")
def list_trials(trial_status: str = Query(default="pending", alias="status")):
    with get_pool().connection() as conn:
        rows = conn.execute(
            """
            SELECT tr.id,tr.status,tr.requested_edition,tr.use_case,tr.requested_at,tr.decided_at,tr.approved_license_id,
                   o.id AS organization_id,o.name AS organization_name,u.email::text AS requester_email
            FROM trial_requests tr
            JOIN organizations o ON o.id=tr.organization_id
            LEFT JOIN users u ON u.id=tr.requested_by_user_id
            WHERE tr.status=%s ORDER BY tr.requested_at DESC
            """,
            (trial_status,),
        ).fetchall()
    return [{**row, "id": _id(row["id"]), "organization_id": _id(row["organization_id"]), "approved_license_id": _id(row["approved_license_id"])} for row in rows]


@router.post("/trials/{trial_id}/approve", status_code=201, dependencies=[Depends(require_admin_write)])
def approve_trial(trial_id: UUID, payload: AdminTrialApprove, request: Request):
    now = utcnow()
    expires = now + timedelta(days=payload.duration_days)
    grace_until = expires + timedelta(days=payload.grace_days) if payload.grace_days else expires
    with get_pool().connection() as conn:
        with conn.transaction():
            trial = conn.execute("SELECT * FROM trial_requests WHERE id=%s FOR UPDATE", (trial_id,)).fetchone()
            if not trial:
                raise HTTPException(status_code=404, detail="Trial request not found")
            if trial["status"] != "pending":
                raise HTTPException(status_code=409, detail="Trial request is not pending")
            edition = payload.edition or trial["requested_edition"]
            license_number = generate_license_number(conn)
            license_row = conn.execute(
                """
                INSERT INTO licenses(
                    organization_id,product_id,license_number,license_type,edition,status,valid_from,expires_at,
                    grace_until,max_installations,notes
                )
                VALUES (%s,%s,%s,'trial',%s,'active',%s,%s,%s,%s,%s)
                RETURNING id,license_number::text AS license_number
                """,
                (trial["organization_id"], trial["product_id"], license_number, edition, now, expires, grace_until, payload.max_installations, f"Approved from trial request {trial_id}"),
            ).fetchone()
            set_entitlements(conn, license_row["id"], trial["product_id"], payload.entitlements)
            conn.execute("UPDATE trial_requests SET status='approved',approved_license_id=%s,decided_at=now() WHERE id=%s", (license_row["id"], trial_id))
            key = create_activation_key(conn, license_row["id"], max_uses=1)
            write_audit(conn, "TRIAL_APPROVED", actor_type="admin", actor_user_id=_admin_actor(request), organization_id=trial["organization_id"], license_id=license_row["id"], ip_address=client_ip(request), metadata={"trial_request_id": str(trial_id)})
            write_audit(conn, "ACTIVATION_KEY_GENERATED", actor_type="admin", actor_user_id=_admin_actor(request), organization_id=trial["organization_id"], license_id=license_row["id"], ip_address=client_ip(request), metadata={"activation_key_id": key["id"]})
    return {"trial_id": str(trial_id), "license_id": _id(license_row["id"]), "license_number": license_row["license_number"], "expires_at": expires, "activation": {**key, "display_once": True}}


@router.post("/trials/{trial_id}/decline", dependencies=[Depends(require_admin_write)])
def decline_trial(trial_id: UUID, payload: AdminTrialDecline, request: Request):
    with get_pool().connection() as conn:
        with conn.transaction():
            row = conn.execute(
                """
                UPDATE trial_requests SET status='declined',decided_at=now()
                WHERE id=%s AND status='pending' RETURNING organization_id
                """,
                (trial_id,),
            ).fetchone()
            if not row:
                raise HTTPException(status_code=404, detail="Pending trial request not found")
            write_audit(conn, "TRIAL_DECLINED", actor_type="admin", actor_user_id=_admin_actor(request), organization_id=row["organization_id"], ip_address=client_ip(request), metadata={"trial_request_id": str(trial_id), "reason": payload.reason})
    return {"declined": True}


@router.get("/audit")
def list_audit(
    organization_id: UUID | None = None,
    license_id: UUID | None = None,
    event_type: str | None = Query(default=None, max_length=120),
    limit: int = Query(default=100, ge=1, le=500),
):
    clauses = []
    params = []
    if organization_id:
        clauses.append("a.organization_id=%s")
        params.append(organization_id)
    if license_id:
        clauses.append("a.license_id=%s")
        params.append(license_id)
    if event_type:
        clauses.append("a.event_type=%s")
        params.append(event_type)
    where = " WHERE " + " AND ".join(clauses) if clauses else ""
    params.append(limit)
    with get_pool().connection() as conn:
        rows = conn.execute(
            f"""
            SELECT a.id,a.event_type,a.actor_type,a.actor_user_id,a.organization_id,a.license_id,a.installation_id,
                   a.ip_address::text AS ip_address,a.metadata,a.created_at,o.name AS organization_name,
                   l.license_number::text AS license_number,u.email::text AS actor_email
            FROM audit_events a
            LEFT JOIN organizations o ON o.id=a.organization_id
            LEFT JOIN licenses l ON l.id=a.license_id
            LEFT JOIN users u ON u.id=a.actor_user_id
            {where} ORDER BY a.created_at DESC LIMIT %s
            """,
            params,
        ).fetchall()
    return _audit_rows(rows)
