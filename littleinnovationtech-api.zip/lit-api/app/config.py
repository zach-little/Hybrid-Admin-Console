from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache


def _bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _int(name: str, default: int) -> int:
    value = os.getenv(name)
    return int(value) if value is not None else default


def _csv(name: str, default: str = "") -> tuple[str, ...]:
    value = os.getenv(name, default)
    return tuple(item.strip().rstrip("/") for item in value.split(",") if item.strip())


@dataclass(frozen=True)
class Settings:
    environment: str
    public_base_url: str
    allowed_origins: tuple[str, ...]

    db_host: str
    db_port: int
    db_name: str
    db_user: str
    db_password: str
    db_pool_min: int
    db_pool_max: int

    session_cookie_name: str
    session_ttl_hours: int
    session_cookie_secure: bool
    require_email_verification: bool

    admin_api_key: str
    admin_session_cookie_name: str
    admin_session_ttl_hours: int
    activation_key_pepper: str

    signing_key_id: str
    signing_private_key_file: str

    smtp_mode: str
    smtp_host: str
    smtp_port: int
    smtp_username: str
    smtp_password: str
    smtp_from: str
    smtp_starttls: bool

    @property
    def database_dsn(self) -> str:
        return (
            f"host={self.db_host} port={self.db_port} dbname={self.db_name} "
            f"user={self.db_user} password={self.db_password}"
        )

    def validate(self) -> None:
        required = {
            "DB_HOST": self.db_host,
            "DB_NAME": self.db_name,
            "DB_USER": self.db_user,
            "DB_PASSWORD": self.db_password,
            "ADMIN_API_KEY": self.admin_api_key,
            "ACTIVATION_KEY_PEPPER": self.activation_key_pepper,
            "SIGNING_KEY_ID": self.signing_key_id,
            "SIGNING_PRIVATE_KEY_FILE": self.signing_private_key_file,
        }
        missing = [name for name, value in required.items() if not value]
        if missing:
            raise RuntimeError(f"Missing required configuration: {', '.join(missing)}")
        if len(self.admin_api_key) < 32:
            raise RuntimeError("ADMIN_API_KEY must be at least 32 characters")
        if len(self.activation_key_pepper) < 32:
            raise RuntimeError("ACTIVATION_KEY_PEPPER must be at least 32 characters")
        if self.admin_session_ttl_hours < 1 or self.admin_session_ttl_hours > 168:
            raise RuntimeError("ADMIN_SESSION_TTL_HOURS must be between 1 and 168")
        if self.smtp_mode not in {"disabled", "smtp"}:
            raise RuntimeError("SMTP_MODE must be 'disabled' or 'smtp'")
        if self.require_email_verification and self.smtp_mode != "smtp":
            raise RuntimeError("REQUIRE_EMAIL_VERIFICATION=true requires SMTP_MODE=smtp")
        if self.smtp_mode == "smtp" and (not self.smtp_host or not self.smtp_from):
            raise RuntimeError("SMTP_HOST and SMTP_FROM are required when SMTP_MODE=smtp")


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    settings = Settings(
        environment=os.getenv("ENVIRONMENT", "production").strip().lower(),
        public_base_url=os.getenv("PUBLIC_BASE_URL", "https://littleinnovation.tech").strip().rstrip("/"),
        allowed_origins=_csv(
            "ALLOWED_ORIGINS",
            "https://littleinnovation.tech,https://www.littleinnovation.tech",
        ),
        db_host=os.getenv("DB_HOST", ""),
        db_port=_int("DB_PORT", 5432),
        db_name=os.getenv("DB_NAME", ""),
        db_user=os.getenv("DB_USER", ""),
        db_password=os.getenv("DB_PASSWORD", ""),
        db_pool_min=_int("DB_POOL_MIN", 1),
        db_pool_max=_int("DB_POOL_MAX", 10),
        session_cookie_name=os.getenv("SESSION_COOKIE_NAME", "lit_session"),
        session_ttl_hours=_int("SESSION_TTL_HOURS", 168),
        session_cookie_secure=_bool("SESSION_COOKIE_SECURE", True),
        require_email_verification=_bool("REQUIRE_EMAIL_VERIFICATION", False),
        admin_api_key=os.getenv("ADMIN_API_KEY", ""),
        admin_session_cookie_name=os.getenv("ADMIN_SESSION_COOKIE_NAME", "lit_admin_session"),
        admin_session_ttl_hours=_int("ADMIN_SESSION_TTL_HOURS", 8),
        activation_key_pepper=os.getenv("ACTIVATION_KEY_PEPPER", ""),
        signing_key_id=os.getenv("SIGNING_KEY_ID", ""),
        signing_private_key_file=os.getenv("SIGNING_PRIVATE_KEY_FILE", ""),
        smtp_mode=os.getenv("SMTP_MODE", "disabled").strip().lower(),
        smtp_host=os.getenv("SMTP_HOST", ""),
        smtp_port=_int("SMTP_PORT", 587),
        smtp_username=os.getenv("SMTP_USERNAME", ""),
        smtp_password=os.getenv("SMTP_PASSWORD", ""),
        smtp_from=os.getenv("SMTP_FROM", ""),
        smtp_starttls=_bool("SMTP_STARTTLS", True),
    )
    settings.validate()
    return settings
