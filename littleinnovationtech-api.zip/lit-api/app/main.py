from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .config import get_settings
from .db import close_pool, open_pool
from .licensing import register_signing_key, signing_key_document
from .routes_account import router as account_router
from .routes_admin import router as admin_router
from .routes_admin_auth import router as admin_auth_router
from .routes_hilop import router as hilop_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    pool = open_pool()
    with pool.connection() as conn:
        with conn.transaction():
            register_signing_key(conn)
    app.state.settings = settings
    yield
    close_pool()


settings = get_settings()
app = FastAPI(
    title="Little Innovation Tech Account & Licensing API",
    version="1.0.0",
    docs_url="/api/docs" if settings.environment != "production" else None,
    redoc_url=None,
    openapi_url="/api/openapi.json" if settings.environment != "production" else None,
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=list(settings.allowed_origins),
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "X-Organization-ID", "X-LIT-Admin-Key"],
)

app.include_router(account_router)
app.include_router(hilop_router)
app.include_router(admin_auth_router)
app.include_router(admin_router)


@app.get("/api/v1/health/live", tags=["health"])
def health_live():
    return {"status": "ok", "service": "lit-api"}


@app.get("/api/v1/health/ready", tags=["health"])
def health_ready():
    pool = open_pool()
    with pool.connection() as conn:
        db_ok = conn.execute("SELECT 1 AS ok").fetchone()["ok"] == 1
    key = signing_key_document()
    return {"status": "ready" if db_ok else "not-ready", "database": db_ok, "signing_key_id": key["key_id"]}


@app.get("/.well-known/hilop-license-key", tags=["hilop"])
def hilop_public_key():
    return signing_key_document()
