from __future__ import annotations

from fastapi import APIRouter, Header, HTTPException, Request, status

from .audit import write_audit
from .db import get_pool
from .dependencies import client_ip
from .licensing import issue_license_document
from .schemas import ActivationRequest, RefreshRequest
from .security import hash_activation_key, hash_token, random_token, utcnow

router = APIRouter(prefix="/api/v1/hilop", tags=["hilop"])


def _bearer(authorization: str | None) -> str:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Installation credential required")
    token = authorization[7:].strip()
    if not token:
        raise HTTPException(status_code=401, detail="Installation credential required")
    return token


def _credential_row(conn, token: str, *, for_update: bool = False):
    suffix = " FOR UPDATE" if for_update else ""
    return conn.execute(
        f"""
        SELECT c.id AS credential_id,c.installation_id AS installation_db_id,c.expires_at AS credential_expires_at,
               i.installation_id AS external_installation_id,i.license_id,i.status AS installation_status,
               l.organization_id,l.status AS license_db_status,p.code::text AS product_code
        FROM installation_credentials c
        JOIN installations i ON i.id=c.installation_id
        JOIN licenses l ON l.id=i.license_id
        JOIN products p ON p.id=l.product_id
        WHERE c.token_hash=%s AND c.status='active'
          AND (c.expires_at IS NULL OR c.expires_at>now())
        {suffix}
        """,
        (hash_token(token),),
    ).fetchone()


@router.post("/activate", status_code=201)
def activate(payload: ActivationRequest, request: Request):
    key_hash = hash_activation_key(payload.activation_key)
    ip = client_ip(request)
    with get_pool().connection() as conn:
        with conn.transaction():
            key = conn.execute(
                """
                SELECT ak.*,ak.expires_at AS activation_expires_at,l.organization_id,l.product_id,l.status AS license_status,l.valid_from,
                       l.expires_at AS license_expires_at,l.max_installations,p.code::text AS product_code
                FROM activation_keys ak
                JOIN licenses l ON l.id=ak.license_id
                JOIN products p ON p.id=l.product_id
                WHERE ak.key_hash=%s
                FOR UPDATE
                """,
                (key_hash,),
            ).fetchone()
            if not key:
                raise HTTPException(status_code=401, detail="Invalid activation key")
            if key["status"] != "active":
                raise HTTPException(status_code=409, detail="Activation key is not active")
            if key["activation_expires_at"] and utcnow() > key["activation_expires_at"]:
                conn.execute("UPDATE activation_keys SET status='expired' WHERE id=%s", (key["id"],))
                raise HTTPException(status_code=409, detail="Activation key has expired")
            if key["uses_count"] >= key["max_uses"]:
                conn.execute("UPDATE activation_keys SET status='expired' WHERE id=%s", (key["id"],))
                raise HTTPException(status_code=409, detail="Activation key usage limit reached")
            if key["product_code"] != "HILOP":
                raise HTTPException(status_code=409, detail="Activation key is not valid for HILOP")
            if key["license_status"] != "active":
                raise HTTPException(status_code=409, detail="License is not active")
            if utcnow() < key["valid_from"]:
                raise HTTPException(status_code=409, detail="License is not yet valid")
            if key["license_expires_at"] and utcnow() > key["license_expires_at"]:
                raise HTTPException(status_code=409, detail="License has expired")

            existing = conn.execute(
                "SELECT * FROM installations WHERE installation_id=%s FOR UPDATE",
                (payload.installation_id,),
            ).fetchone()
            consume_key = False
            if existing:
                if existing["license_id"] != key["license_id"]:
                    raise HTTPException(status_code=409, detail="Installation ID is already assigned to another license")
                if existing["status"] == "revoked":
                    raise HTTPException(status_code=409, detail="Installation has been revoked")
                if existing["status"] == "deactivated":
                    active_count = conn.execute(
                        "SELECT count(*) AS count FROM installations WHERE license_id=%s AND status='active' AND id<>%s",
                        (key["license_id"], existing["id"]),
                    ).fetchone()["count"]
                    if active_count >= key["max_installations"]:
                        raise HTTPException(status_code=409, detail="License installation limit reached")
                    conn.execute(
                        """
                        UPDATE installations SET status='active',deactivated_at=NULL,display_name=%s,hostname=%s,
                            hilop_version=%s,last_seen_at=now(),updated_at=now() WHERE id=%s
                        """,
                        (payload.display_name, payload.hostname, payload.version, existing["id"]),
                    )
                else:
                    conn.execute(
                        "UPDATE installations SET display_name=COALESCE(%s,display_name),hostname=%s,hilop_version=%s,last_seen_at=now(),updated_at=now() WHERE id=%s",
                        (payload.display_name, payload.hostname, payload.version, existing["id"]),
                    )
                installation_db_id = existing["id"]
            else:
                active_count = conn.execute(
                    "SELECT count(*) AS count FROM installations WHERE license_id=%s AND status='active'",
                    (key["license_id"],),
                ).fetchone()["count"]
                if active_count >= key["max_installations"]:
                    raise HTTPException(status_code=409, detail="License installation limit reached")
                installation = conn.execute(
                    """
                    INSERT INTO installations(license_id,installation_id,display_name,hostname,hilop_version,last_seen_at)
                    VALUES (%s,%s,%s,%s,%s,now()) RETURNING id
                    """,
                    (key["license_id"], payload.installation_id, payload.display_name, payload.hostname, payload.version),
                ).fetchone()
                installation_db_id = installation["id"]
                consume_key = True

            if consume_key:
                new_count = key["uses_count"] + 1
                new_status = "expired" if new_count >= key["max_uses"] else "active"
                conn.execute(
                    "UPDATE activation_keys SET uses_count=%s,last_used_at=now(),status=%s WHERE id=%s",
                    (new_count, new_status, key["id"]),
                )

            conn.execute(
                "UPDATE installation_credentials SET status='revoked',revoked_at=now() WHERE installation_id=%s AND status='active'",
                (installation_db_id,),
            )
            raw_credential = random_token("hinst_")
            conn.execute(
                "INSERT INTO installation_credentials(installation_id,token_hash,last_used_at) VALUES (%s,%s,now())",
                (installation_db_id, hash_token(raw_credential)),
            )
            license_document = issue_license_document(conn, key["license_id"], installation_db_id)
            write_audit(
                conn,
                "LICENSE_ACTIVATED",
                actor_type="installation",
                organization_id=key["organization_id"],
                license_id=key["license_id"],
                installation_id=installation_db_id,
                ip_address=ip,
                metadata={"hilop_version": payload.version},
            )

    return {
        "success": True,
        "installation_id": payload.installation_id,
        "installation_token": raw_credential,
        "license": license_document,
    }


@router.post("/license/refresh")
def refresh_license(payload: RefreshRequest, request: Request, authorization: str | None = Header(default=None)):
    token = _bearer(authorization)
    with get_pool().connection() as conn:
        with conn.transaction():
            credential = _credential_row(conn, token, for_update=True)
            if not credential or credential["installation_status"] != "active":
                raise HTTPException(status_code=401, detail="Invalid installation credential")
            if credential["product_code"] != "HILOP":
                raise HTTPException(status_code=403, detail="Credential is not valid for HILOP")

            conn.execute(
                "UPDATE installation_credentials SET last_used_at=now() WHERE id=%s",
                (credential["credential_id"],),
            )
            conn.execute(
                """
                UPDATE installations SET hostname=COALESCE(%s,hostname),hilop_version=COALESCE(%s,hilop_version),
                    last_seen_at=now(),updated_at=now() WHERE id=%s
                """,
                (payload.hostname, payload.version, credential["installation_db_id"]),
            )
            license_document = issue_license_document(conn, credential["license_id"], credential["installation_db_id"])
            write_audit(
                conn,
                "LICENSE_REFRESHED",
                actor_type="installation",
                organization_id=credential["organization_id"],
                license_id=credential["license_id"],
                installation_id=credential["installation_db_id"],
                ip_address=client_ip(request),
                metadata={"hilop_version": payload.version},
            )
    return {"success": True, "license": license_document}


@router.post("/deactivate", status_code=204)
def deactivate(request: Request, authorization: str | None = Header(default=None)):
    token = _bearer(authorization)
    with get_pool().connection() as conn:
        with conn.transaction():
            credential = _credential_row(conn, token, for_update=True)
            if not credential:
                raise HTTPException(status_code=401, detail="Invalid installation credential")
            conn.execute(
                "UPDATE installations SET status='deactivated',deactivated_at=now(),updated_at=now() WHERE id=%s",
                (credential["installation_db_id"],),
            )
            conn.execute(
                "UPDATE installation_credentials SET status='revoked',revoked_at=now() WHERE installation_id=%s AND status='active'",
                (credential["installation_db_id"],),
            )
            write_audit(
                conn,
                "INSTALLATION_DEACTIVATED",
                actor_type="installation",
                organization_id=credential["organization_id"],
                license_id=credential["license_id"],
                installation_id=credential["installation_db_id"],
                ip_address=client_ip(request),
            )
    return None
