from __future__ import annotations

from fastapi import APIRouter, Depends, Request, Response

from .config import get_settings
from .db import get_pool
from .dependencies import require_admin, require_origin
from .security import hash_token

router = APIRouter(prefix="/api/v1/admin", tags=["admin-auth"])


@router.get("/session", dependencies=[Depends(require_admin)])
def admin_session_status(request: Request):
    user_id = getattr(request.state, "admin_user_id", None)
    user = None
    if user_id is not None:
        user = {
            "id": str(user_id),
            "email": getattr(request.state, "admin_email", None),
            "display_name": getattr(request.state, "admin_display_name", None),
            "is_platform_admin": True,
        }
    return {
        "authenticated": True,
        "auth_method": getattr(request.state, "admin_auth_method", "account"),
        "user": user,
    }


@router.delete("/session", dependencies=[Depends(require_admin)])
def admin_session_logout(request: Request, response: Response):
    require_origin(request)
    settings = get_settings()
    token = request.cookies.get(settings.session_cookie_name)
    if token:
        with get_pool().connection() as conn:
            conn.execute(
                "UPDATE user_sessions SET revoked_at=now() WHERE token_hash=%s AND revoked_at IS NULL",
                (hash_token(token),),
            )
    response.delete_cookie(settings.session_cookie_name, path="/")
    return {"authenticated": False}
