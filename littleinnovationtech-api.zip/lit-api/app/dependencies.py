from __future__ import annotations

from dataclasses import dataclass
from uuid import UUID

from fastapi import Header, HTTPException, Request, status

from .config import get_settings
from .db import get_pool
from .security import constant_time_equal, hash_token


@dataclass
class AuthContext:
    user_id: UUID
    email: str
    display_name: str | None
    email_verified: bool
    session_id: UUID
    organization_id: UUID | None
    organization_name: str | None
    organization_slug: str | None
    role: str | None


def client_ip(request: Request) -> str | None:
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",", 1)[0].strip()[:64]
    if request.client:
        return request.client.host
    return None


def require_origin(request: Request) -> None:
    settings = get_settings()
    origin = request.headers.get("origin", "").rstrip("/")
    if origin and origin in settings.allowed_origins:
        return
    referer = request.headers.get("referer", "")
    if any(referer.startswith(f"{allowed}/") or referer == allowed for allowed in settings.allowed_origins):
        return
    raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Invalid request origin")


def _admin_header_valid(value: str | None) -> bool:
    expected = get_settings().admin_api_key
    return bool(value) and constant_time_equal(value, expected)


def _require_platform_admin_session(request: Request):
    settings = get_settings()
    token = request.cookies.get(settings.session_cookie_name)
    if not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Sign in with a Little Innovation Tech account")

    token_hash = hash_token(token)
    with get_pool().connection() as conn:
        session = conn.execute(
            """
            SELECT s.id AS session_id, u.id AS user_id, u.email::text AS email,
                   u.display_name, u.is_platform_admin, u.disabled_at
            FROM user_sessions s
            JOIN users u ON u.id=s.user_id
            WHERE s.token_hash=%s AND s.revoked_at IS NULL AND s.expires_at > now()
            """,
            (token_hash,),
        ).fetchone()
        if not session or session["disabled_at"] is not None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired account session")
        if not session["is_platform_admin"]:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="This account is not flagged as a Little Innovation Tech platform administrator")
        conn.execute("UPDATE user_sessions SET last_seen_at=now() WHERE id=%s", (session["session_id"],))

    request.state.admin_auth_method = "account"
    request.state.admin_user_id = session["user_id"]
    request.state.admin_email = session["email"]
    request.state.admin_display_name = session["display_name"]
    return session


def require_admin(request: Request, x_lit_admin_key: str | None = Header(default=None)) -> None:
    # Keep the API key only as a break-glass/CLI credential. Browser admin access
    # uses the normal Little Innovation Tech account session plus is_platform_admin.
    if x_lit_admin_key is not None:
        if _admin_header_valid(x_lit_admin_key):
            request.state.admin_auth_method = "api_key"
            request.state.admin_user_id = None
            return
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid admin credential")
    _require_platform_admin_session(request)


def require_admin_write(request: Request, x_lit_admin_key: str | None = Header(default=None)) -> None:
    if x_lit_admin_key is not None:
        if _admin_header_valid(x_lit_admin_key):
            request.state.admin_auth_method = "api_key"
            request.state.admin_user_id = None
            return
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid admin credential")
    _require_platform_admin_session(request)
    require_origin(request)


def _resolve_org(conn, user_id, requested_org: str | None):
    if requested_org:
        try:
            org_id = UUID(requested_org)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail="Invalid organization ID") from exc
        row = conn.execute(
            """
            SELECT o.id, o.name, o.slug, om.role
            FROM organization_members om
            JOIN organizations o ON o.id = om.organization_id
            WHERE om.user_id=%s AND om.organization_id=%s
              AND om.status='active' AND o.status='active'
            """,
            (user_id, org_id),
        ).fetchone()
        if not row:
            raise HTTPException(status_code=403, detail="Organization access denied")
        return row

    return conn.execute(
        """
        SELECT o.id, o.name, o.slug, om.role
        FROM organization_members om
        JOIN organizations o ON o.id = om.organization_id
        WHERE om.user_id=%s AND om.status='active' AND o.status='active'
        ORDER BY CASE om.role WHEN 'owner' THEN 0 WHEN 'admin' THEN 1 ELSE 2 END, om.created_at
        LIMIT 1
        """,
        (user_id,),
    ).fetchone()


def get_auth_context(
    request: Request,
    x_organization_id: str | None = Header(default=None),
) -> AuthContext:
    settings = get_settings()
    token = request.cookies.get(settings.session_cookie_name)
    if not token:
        auth = request.headers.get("authorization", "")
        if auth.lower().startswith("bearer "):
            token = auth[7:].strip()
    if not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required")

    token_hash = hash_token(token)
    pool = get_pool()
    with pool.connection() as conn:
        session = conn.execute(
            """
            SELECT s.id AS session_id, u.id AS user_id, u.email::text AS email,
                   u.display_name, u.email_verified_at, u.disabled_at
            FROM user_sessions s
            JOIN users u ON u.id=s.user_id
            WHERE s.token_hash=%s AND s.revoked_at IS NULL AND s.expires_at > now()
            """,
            (token_hash,),
        ).fetchone()
        if not session or session["disabled_at"] is not None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired session")

        conn.execute("UPDATE user_sessions SET last_seen_at=now() WHERE id=%s", (session["session_id"],))
        org = _resolve_org(conn, session["user_id"], x_organization_id)

    return AuthContext(
        user_id=session["user_id"],
        email=session["email"],
        display_name=session["display_name"],
        email_verified=session["email_verified_at"] is not None,
        session_id=session["session_id"],
        organization_id=org["id"] if org else None,
        organization_name=org["name"] if org else None,
        organization_slug=str(org["slug"]) if org else None,
        role=org["role"] if org else None,
    )


def require_org(ctx: AuthContext) -> None:
    if ctx.organization_id is None:
        raise HTTPException(status_code=403, detail="Organization membership required")


def require_role(ctx: AuthContext, *roles: str) -> None:
    require_org(ctx)
    if ctx.role not in roles:
        raise HTTPException(status_code=403, detail="Insufficient organization permissions")
