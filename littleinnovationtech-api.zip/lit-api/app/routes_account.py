from __future__ import annotations

import re
from datetime import timedelta
from uuid import UUID

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Request, Response, status
from fastapi.responses import RedirectResponse

from .audit import write_audit
from .config import get_settings
from .db import get_pool
from .dependencies import AuthContext, client_ip, get_auth_context, require_org, require_origin, require_role
from .licensing import create_activation_key, effective_license_status
from .mailer import send_organization_invitation, send_password_reset, send_verification
from .rate_limit import limiter
from .schemas import (
    LoginRequest,
    MemberInvitationRequest,
    OrganizationUpdateRequest,
    PasswordResetComplete,
    PasswordResetRequest,
    ProfileUpdateRequest,
    RegisterRequest,
    TokenRequest,
    TrialRequestCreate,
)
from .security import (
    burn_dummy_password_check,
    hash_password,
    hash_token,
    random_token,
    session_expiry,
    utcnow,
    validate_password,
    verify_password,
)

router = APIRouter(prefix="/api/v1/account", tags=["account"])


def _slug_base(name: str) -> str:
    value = re.sub(r"[^a-z0-9]+", "-", name.strip().lower()).strip("-")
    return value[:120] or "organization"


def _unique_slug(conn, name: str) -> str:
    base = _slug_base(name)
    candidate = base
    suffix = 2
    while conn.execute("SELECT 1 FROM organizations WHERE slug=%s", (candidate,)).fetchone():
        candidate = f"{base[:110]}-{suffix}"
        suffix += 1
        if suffix > 9999:
            raise RuntimeError("Unable to generate organization slug")
    return candidate


def _display_name(first_name: str | None, last_name: str | None, email: str) -> str:
    full = " ".join(part.strip() for part in (first_name or "", last_name or "") if part.strip())
    return full or email.split("@", 1)[0]


def _create_session(conn, user_id, request: Request) -> tuple[str, object]:
    raw = random_token("lit_sess_")
    expires = session_expiry()
    conn.execute(
        """
        INSERT INTO user_sessions(user_id,token_hash,ip_address,user_agent,expires_at,last_seen_at)
        VALUES (%s,%s,%s,%s,%s,now())
        """,
        (user_id, hash_token(raw), client_ip(request), request.headers.get("user-agent", "")[:1000], expires),
    )
    return raw, expires


def _set_session_cookie(response: Response, token: str, expires) -> None:
    settings = get_settings()
    max_age = max(0, int((expires - utcnow()).total_seconds()))
    response.set_cookie(
        key=settings.session_cookie_name,
        value=token,
        max_age=max_age,
        expires=expires,
        path="/",
        secure=settings.session_cookie_secure,
        httponly=True,
        samesite="lax",
    )


def _get_invitation(conn, token: str, *, for_update: bool = False):
    lock = " FOR UPDATE" if for_update else ""
    return conn.execute(
        f"""
        SELECT oi.id,oi.organization_id,oi.email::text AS email,oi.role,oi.expires_at,
               oi.accepted_at,oi.revoked_at,o.name AS organization_name,o.slug::text AS organization_slug
        FROM organization_invitations oi
        JOIN organizations o ON o.id=oi.organization_id
        WHERE oi.token_hash=%s AND o.status='active'{lock}
        """,
        (hash_token(token),),
    ).fetchone()


def _valid_invitation(row) -> bool:
    return bool(
        row
        and row["accepted_at"] is None
        and row["revoked_at"] is None
        and row["expires_at"] > utcnow()
    )


def _create_user_token(conn, user_id, token_type: str, ttl: timedelta) -> str:
    conn.execute(
        """
        UPDATE user_tokens SET consumed_at=now()
        WHERE user_id=%s AND token_type=%s AND consumed_at IS NULL
        """,
        (user_id, token_type),
    )
    prefix = "lit_verify_" if token_type == "email_verification" else "lit_reset_"
    raw = random_token(prefix)
    conn.execute(
        """
        INSERT INTO user_tokens(user_id,token_type,token_hash,expires_at)
        VALUES (%s,%s,%s,%s)
        """,
        (user_id, token_type, hash_token(raw), utcnow() + ttl),
    )
    return raw


@router.post("/register", status_code=status.HTTP_201_CREATED)
def register(payload: RegisterRequest, request: Request, response: Response, background: BackgroundTasks):
    require_origin(request)
    ip = client_ip(request) or "unknown"
    if not limiter.allow(f"register:{ip}", 5, 3600):
        raise HTTPException(status_code=429, detail="Too many registration attempts")
    try:
        validate_password(payload.password)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    settings = get_settings()
    email = str(payload.email).strip().lower()
    pool = get_pool()
    verification_token = None
    invitation = None
    with pool.connection() as conn:
        with conn.transaction():
            if conn.execute("SELECT 1 FROM users WHERE email=%s", (email,)).fetchone():
                raise HTTPException(status_code=409, detail="An account with this email already exists")

            if payload.invitation_token:
                invitation = _get_invitation(conn, payload.invitation_token, for_update=True)
                if not _valid_invitation(invitation):
                    raise HTTPException(status_code=400, detail="Invalid or expired organization invitation")
                if invitation["email"].lower() != email:
                    raise HTTPException(status_code=400, detail="This invitation was issued to a different email address")
            elif not payload.organization_name or not payload.organization_name.strip():
                raise HTTPException(status_code=400, detail="Organization name is required")

            display_name = _display_name(payload.first_name, payload.last_name, email)
            user = conn.execute(
                """
                INSERT INTO users(email,password_hash,first_name,last_name,display_name)
                VALUES (%s,%s,%s,%s,%s)
                RETURNING id
                """,
                (email, hash_password(payload.password), payload.first_name, payload.last_name, display_name),
            ).fetchone()

            if invitation:
                org = conn.execute(
                    "SELECT id,name,slug::text AS slug FROM organizations WHERE id=%s",
                    (invitation["organization_id"],),
                ).fetchone()
                conn.execute(
                    """
                    INSERT INTO organization_members(organization_id,user_id,role,status,joined_at)
                    VALUES (%s,%s,%s,'active',now())
                    """,
                    (org["id"], user["id"], invitation["role"]),
                )
                conn.execute("UPDATE organization_invitations SET accepted_at=now() WHERE id=%s", (invitation["id"],))
                write_audit(
                    conn,
                    "ORGANIZATION_INVITATION_ACCEPTED",
                    actor_type="user",
                    actor_user_id=user["id"],
                    organization_id=org["id"],
                    ip_address=ip,
                    metadata={"invitation_id": str(invitation["id"]), "role": invitation["role"]},
                )
            else:
                org = conn.execute(
                    """
                    INSERT INTO organizations(name,slug,licensing_email)
                    VALUES (%s,%s,%s)
                    RETURNING id,name,slug::text AS slug
                    """,
                    (payload.organization_name.strip(), _unique_slug(conn, payload.organization_name), email),
                ).fetchone()
                conn.execute(
                    """
                    INSERT INTO organization_members(organization_id,user_id,role,status,joined_at)
                    VALUES (%s,%s,'owner','active',now())
                    """,
                    (org["id"], user["id"]),
                )
                write_audit(
                    conn,
                    "ORGANIZATION_CREATED",
                    actor_type="user",
                    actor_user_id=user["id"],
                    organization_id=org["id"],
                    ip_address=ip,
                )

            write_audit(
                conn,
                "USER_REGISTERED",
                actor_type="user",
                actor_user_id=user["id"],
                organization_id=org["id"],
                ip_address=ip,
            )

            if settings.smtp_mode == "smtp" or settings.require_email_verification:
                verification_token = _create_user_token(conn, user["id"], "email_verification", timedelta(hours=24))

            if not settings.require_email_verification:
                session_token, expires = _create_session(conn, user["id"], request)
                _set_session_cookie(response, session_token, expires)

    if verification_token and settings.smtp_mode == "smtp":
        background.add_task(send_verification, email, verification_token)

    return {
        "registered": True,
        "verification_required": settings.require_email_verification,
        "organization": {"id": str(org["id"]), "name": org["name"], "slug": str(org["slug"])},
    }


@router.post("/login")
def login(payload: LoginRequest, request: Request, response: Response):
    require_origin(request)
    settings = get_settings()
    email = str(payload.email).strip().lower()
    ip = client_ip(request) or "unknown"
    key = f"login:{ip}:{email}"
    if not limiter.allow(key, 10, 600):
        raise HTTPException(status_code=429, detail="Too many login attempts")

    pool = get_pool()
    with pool.connection() as conn:
        with conn.transaction():
            user = conn.execute(
                "SELECT id,email::text AS email,password_hash,display_name,email_verified_at,disabled_at FROM users WHERE email=%s",
                (email,),
            ).fetchone()
            if not user:
                burn_dummy_password_check(payload.password)
                write_audit(conn, "LOGIN_FAILED", ip_address=ip, metadata={"reason": "invalid_credentials"})
                raise HTTPException(status_code=401, detail="Invalid email or password")

            valid, replacement_hash = verify_password(user["password_hash"], payload.password)
            if not valid:
                write_audit(conn, "LOGIN_FAILED", actor_user_id=user["id"], ip_address=ip, metadata={"reason": "invalid_credentials"})
                raise HTTPException(status_code=401, detail="Invalid email or password")
            if user["disabled_at"] is not None:
                raise HTTPException(status_code=403, detail="Account is disabled")
            if settings.require_email_verification and user["email_verified_at"] is None:
                raise HTTPException(status_code=403, detail="Email verification is required")

            if replacement_hash:
                conn.execute("UPDATE users SET password_hash=%s, updated_at=now() WHERE id=%s", (replacement_hash, user["id"]))
            conn.execute("UPDATE users SET last_login_at=now(), updated_at=now() WHERE id=%s", (user["id"],))
            session_token, expires = _create_session(conn, user["id"], request)
            write_audit(conn, "LOGIN_SUCCEEDED", actor_type="user", actor_user_id=user["id"], ip_address=ip)

    _set_session_cookie(response, session_token, expires)
    return {"authenticated": True, "display_name": user["display_name"]}


@router.post("/logout", status_code=204)
def logout(request: Request, response: Response):
    require_origin(request)
    settings = get_settings()
    token = request.cookies.get(settings.session_cookie_name)
    if token:
        with get_pool().connection() as conn:
            with conn.transaction():
                row = conn.execute(
                    "UPDATE user_sessions SET revoked_at=now() WHERE token_hash=%s AND revoked_at IS NULL RETURNING user_id",
                    (hash_token(token),),
                ).fetchone()
                if row:
                    write_audit(conn, "LOGOUT", actor_type="user", actor_user_id=row["user_id"], ip_address=client_ip(request))
    response.delete_cookie(settings.session_cookie_name, path="/")
    response.status_code = 204
    return None


@router.get("/me")
def me(ctx: AuthContext = Depends(get_auth_context)):
    with get_pool().connection() as conn:
        memberships = conn.execute(
            """
            SELECT o.id,o.name,o.slug::text AS slug,om.role
            FROM organization_members om
            JOIN organizations o ON o.id=om.organization_id
            WHERE om.user_id=%s AND om.status='active' AND o.status='active'
            ORDER BY o.name
            """,
            (ctx.user_id,),
        ).fetchall()
        user = conn.execute("SELECT first_name,last_name,is_platform_admin FROM users WHERE id=%s", (ctx.user_id,)).fetchone()
    return {
        "user": {
            "id": str(ctx.user_id),
            "email": ctx.email,
            "display_name": ctx.display_name,
            "first_name": user["first_name"],
            "last_name": user["last_name"],
            "email_verified": ctx.email_verified,
            "is_platform_admin": bool(user["is_platform_admin"]),
        },
        "active_organization_id": str(ctx.organization_id) if ctx.organization_id else None,
        "memberships": [
            {"organization_id": str(row["id"]), "name": row["name"], "slug": row["slug"], "role": row["role"]}
            for row in memberships
        ],
    }


@router.patch("/profile")
def update_profile(payload: ProfileUpdateRequest, request: Request, ctx: AuthContext = Depends(get_auth_context)):
    require_origin(request)
    if payload.first_name is None and payload.last_name is None:
        raise HTTPException(status_code=400, detail="No changes supplied")
    with get_pool().connection() as conn:
        with conn.transaction():
            row = conn.execute("SELECT first_name,last_name,email::text AS email FROM users WHERE id=%s FOR UPDATE", (ctx.user_id,)).fetchone()
            first_name = payload.first_name.strip() if payload.first_name is not None else row["first_name"]
            last_name = payload.last_name.strip() if payload.last_name is not None else row["last_name"]
            display_name = _display_name(first_name, last_name, row["email"])
            conn.execute(
                "UPDATE users SET first_name=%s,last_name=%s,display_name=%s,updated_at=now() WHERE id=%s",
                (first_name or None, last_name or None, display_name, ctx.user_id),
            )
            write_audit(conn, "PROFILE_UPDATED", actor_type="user", actor_user_id=ctx.user_id, organization_id=ctx.organization_id, ip_address=client_ip(request))
    return {"updated": True, "display_name": display_name}


@router.get("/organization")
def get_organization(ctx: AuthContext = Depends(get_auth_context)):
    require_org(ctx)
    with get_pool().connection() as conn:
        org = conn.execute(
            "SELECT id,name,slug::text AS slug,licensing_email::text AS licensing_email,status,created_at FROM organizations WHERE id=%s",
            (ctx.organization_id,),
        ).fetchone()
    return {**org, "id": str(org["id"]), "role": ctx.role}


@router.patch("/organization")
def update_organization(payload: OrganizationUpdateRequest, request: Request, ctx: AuthContext = Depends(get_auth_context)):
    require_origin(request)
    require_role(ctx, "owner", "admin")
    if payload.name is None and payload.licensing_email is None:
        raise HTTPException(status_code=400, detail="No changes supplied")
    with get_pool().connection() as conn:
        with conn.transaction():
            if payload.name is not None:
                conn.execute("UPDATE organizations SET name=%s,updated_at=now() WHERE id=%s", (payload.name.strip(), ctx.organization_id))
            if payload.licensing_email is not None:
                conn.execute(
                    "UPDATE organizations SET licensing_email=%s,updated_at=now() WHERE id=%s",
                    (str(payload.licensing_email).lower(), ctx.organization_id),
                )
            write_audit(
                conn,
                "ORGANIZATION_UPDATED",
                actor_type="user",
                actor_user_id=ctx.user_id,
                organization_id=ctx.organization_id,
                ip_address=client_ip(request),
            )
    return {"updated": True}


@router.get("/members")
def members(ctx: AuthContext = Depends(get_auth_context)):
    require_org(ctx)
    with get_pool().connection() as conn:
        rows = conn.execute(
            """
            SELECT u.id,u.email::text AS email,u.display_name,om.role,om.status,om.joined_at
            FROM organization_members om JOIN users u ON u.id=om.user_id
            WHERE om.organization_id=%s ORDER BY u.display_name NULLS LAST,u.email
            """,
            (ctx.organization_id,),
        ).fetchall()
    return [{**row, "id": str(row["id"])} for row in rows]


@router.get("/members/invitations")
def member_invitations(ctx: AuthContext = Depends(get_auth_context)):
    require_role(ctx, "owner", "admin")
    with get_pool().connection() as conn:
        rows = conn.execute(
            """
            SELECT id,email::text AS email,role,expires_at,created_at
            FROM organization_invitations
            WHERE organization_id=%s AND accepted_at IS NULL AND revoked_at IS NULL AND expires_at>now()
            ORDER BY created_at DESC
            """,
            (ctx.organization_id,),
        ).fetchall()
    return [{**row, "id": str(row["id"])} for row in rows]


@router.post("/members/invitations", status_code=201)
def create_member_invitation(payload: MemberInvitationRequest, request: Request, background: BackgroundTasks, ctx: AuthContext = Depends(get_auth_context)):
    require_origin(request)
    require_role(ctx, "owner", "admin")
    email = str(payload.email).strip().lower()
    raw = random_token("lit_invite_")
    expires = utcnow() + timedelta(hours=72)
    with get_pool().connection() as conn:
        with conn.transaction():
            existing_member = conn.execute(
                """SELECT 1 FROM organization_members om JOIN users u ON u.id=om.user_id
                   WHERE om.organization_id=%s AND u.email=%s AND om.status='active'""",
                (ctx.organization_id, email),
            ).fetchone()
            if existing_member:
                raise HTTPException(status_code=409, detail="This user is already a member of the organization")
            conn.execute(
                """UPDATE organization_invitations SET revoked_at=now()
                   WHERE organization_id=%s AND email=%s AND accepted_at IS NULL AND revoked_at IS NULL""",
                (ctx.organization_id, email),
            )
            row = conn.execute(
                """INSERT INTO organization_invitations(organization_id,email,role,token_hash,invited_by_user_id,expires_at)
                   VALUES (%s,%s,%s,%s,%s,%s) RETURNING id,created_at""",
                (ctx.organization_id, email, payload.role, hash_token(raw), ctx.user_id, expires),
            ).fetchone()
            org = conn.execute("SELECT name FROM organizations WHERE id=%s", (ctx.organization_id,)).fetchone()
            write_audit(
                conn, "ORGANIZATION_INVITATION_CREATED", actor_type="user", actor_user_id=ctx.user_id,
                organization_id=ctx.organization_id, ip_address=client_ip(request),
                metadata={"invitation_id": str(row["id"]), "role": payload.role},
            )
    if get_settings().smtp_mode == "smtp":
        background.add_task(send_organization_invitation, email, org["name"], payload.role, raw)
        return {"id": str(row["id"]), "email": email, "role": payload.role, "expires_at": expires, "delivery": "email"}
    url = f"{get_settings().public_base_url}/account-register?invite={raw}"
    return {"id": str(row["id"]), "email": email, "role": payload.role, "expires_at": expires, "delivery": "display_once", "invitation_url": url}


@router.get("/invitations/inspect")
def inspect_invitation(token: str):
    with get_pool().connection() as conn:
        row = _get_invitation(conn, token)
    if not _valid_invitation(row):
        raise HTTPException(status_code=404, detail="Invitation is invalid or expired")
    return {
        "email": row["email"], "role": row["role"],
        "organization": {"id": str(row["organization_id"]), "name": row["organization_name"], "slug": row["organization_slug"]},
        "expires_at": row["expires_at"],
    }


@router.post("/invitations/accept")
def accept_invitation(payload: TokenRequest, request: Request, ctx: AuthContext = Depends(get_auth_context)):
    require_origin(request)
    with get_pool().connection() as conn:
        with conn.transaction():
            row = _get_invitation(conn, payload.token, for_update=True)
            if not _valid_invitation(row):
                raise HTTPException(status_code=400, detail="Invalid or expired organization invitation")
            if row["email"].lower() != ctx.email.lower():
                raise HTTPException(status_code=403, detail="This invitation was issued to a different email address")
            conn.execute(
                """INSERT INTO organization_members(organization_id,user_id,role,status,joined_at)
                   VALUES (%s,%s,%s,'active',now())
                   ON CONFLICT(organization_id,user_id) DO UPDATE SET role=EXCLUDED.role,status='active',joined_at=COALESCE(organization_members.joined_at,now()),updated_at=now()""",
                (row["organization_id"], ctx.user_id, row["role"]),
            )
            conn.execute("UPDATE organization_invitations SET accepted_at=now() WHERE id=%s", (row["id"],))
            write_audit(conn, "ORGANIZATION_INVITATION_ACCEPTED", actor_type="user", actor_user_id=ctx.user_id, organization_id=row["organization_id"], ip_address=client_ip(request), metadata={"invitation_id": str(row["id"]), "role": row["role"]})
    return {"accepted": True, "organization_id": str(row["organization_id"])}


@router.get("/licenses")
def licenses(ctx: AuthContext = Depends(get_auth_context)):
    require_org(ctx)
    with get_pool().connection() as conn:
        rows = conn.execute(
            """
            SELECT l.*,p.code::text AS product_code,p.name AS product_name
            FROM licenses l JOIN products p ON p.id=l.product_id
            WHERE l.organization_id=%s ORDER BY l.created_at DESC
            """,
            (ctx.organization_id,),
        ).fetchall()
    return [
        {
            "id": str(row["id"]),
            "license_number": str(row["license_number"]),
            "product": row["product_code"],
            "product_name": row["product_name"],
            "license_type": row["license_type"],
            "edition": row["edition"],
            "status": effective_license_status(row),
            "valid_from": row["valid_from"],
            "expires_at": row["expires_at"],
            "grace_until": row["grace_until"],
            "max_installations": row["max_installations"],
        }
        for row in rows
    ]


@router.get("/licenses/{license_id}")
def license_detail(license_id: UUID, ctx: AuthContext = Depends(get_auth_context)):
    require_org(ctx)
    with get_pool().connection() as conn:
        license_row = conn.execute(
            """
            SELECT l.*,p.code::text AS product_code,p.name AS product_name
            FROM licenses l JOIN products p ON p.id=l.product_id
            WHERE l.id=%s AND l.organization_id=%s
            """,
            (license_id, ctx.organization_id),
        ).fetchone()
        if not license_row:
            raise HTTPException(status_code=404, detail="License not found")
        entitlements = conn.execute(
            """
            SELECT ed.entitlement_key::text AS entitlement_key,ed.display_name,ed.value_type,le.value
            FROM license_entitlements le JOIN entitlement_definitions ed ON ed.id=le.entitlement_definition_id
            WHERE le.license_id=%s ORDER BY ed.display_name
            """,
            (license_id,),
        ).fetchall()
        installations = conn.execute(
            """
            SELECT id,installation_id,display_name,hostname,hilop_version,status,activated_at,last_seen_at
            FROM installations WHERE license_id=%s ORDER BY activated_at DESC
            """,
            (license_id,),
        ).fetchall()
        keys = conn.execute(
            """
            SELECT id,key_prefix,last_four,status,max_uses,uses_count,expires_at,created_at,last_used_at
            FROM activation_keys WHERE license_id=%s ORDER BY created_at DESC
            """,
            (license_id,),
        ).fetchall()
    return {
        "license": {
            "id": str(license_row["id"]),
            "license_number": str(license_row["license_number"]),
            "product": license_row["product_code"],
            "product_name": license_row["product_name"],
            "license_type": license_row["license_type"],
            "edition": license_row["edition"],
            "status": effective_license_status(license_row),
            "valid_from": license_row["valid_from"],
            "expires_at": license_row["expires_at"],
            "grace_until": license_row["grace_until"],
            "maintenance_until": license_row["maintenance_until"],
            "max_installations": license_row["max_installations"],
        },
        "entitlements": [dict(row) for row in entitlements],
        "installations": [{**row, "id": str(row["id"])} for row in installations],
        "activation_keys": [{**row, "id": str(row["id"])} for row in keys],
    }


@router.post("/licenses/{license_id}/activation-keys", status_code=201)
def account_create_activation_key(license_id: UUID, request: Request, ctx: AuthContext = Depends(get_auth_context)):
    require_origin(request)
    require_role(ctx, "owner", "admin")
    with get_pool().connection() as conn:
        with conn.transaction():
            license_row = conn.execute(
                "SELECT id,status,expires_at FROM licenses WHERE id=%s AND organization_id=%s FOR UPDATE",
                (license_id, ctx.organization_id),
            ).fetchone()
            if not license_row:
                raise HTTPException(status_code=404, detail="License not found")
            if license_row["status"] != "active" or (license_row["expires_at"] and utcnow() > license_row["expires_at"]):
                raise HTTPException(status_code=409, detail="License is not eligible for new activations")
            key = create_activation_key(conn, license_id, max_uses=1, created_by_user_id=ctx.user_id)
            write_audit(
                conn,
                "ACTIVATION_KEY_GENERATED",
                actor_type="user",
                actor_user_id=ctx.user_id,
                organization_id=ctx.organization_id,
                license_id=license_id,
                ip_address=client_ip(request),
                metadata={"activation_key_id": key["id"]},
            )
    return {**key, "display_once": True}


@router.post("/licenses/{license_id}/activation-keys/{key_id}/revoke")
def account_revoke_activation_key(license_id: UUID, key_id: UUID, request: Request, ctx: AuthContext = Depends(get_auth_context)):
    require_origin(request)
    require_role(ctx, "owner", "admin")
    with get_pool().connection() as conn:
        with conn.transaction():
            row = conn.execute(
                """
                UPDATE activation_keys ak SET status='revoked',revoked_at=now()
                FROM licenses l
                WHERE ak.id=%s AND ak.license_id=%s AND l.id=ak.license_id AND l.organization_id=%s
                  AND ak.status='active'
                RETURNING ak.id
                """,
                (key_id, license_id, ctx.organization_id),
            ).fetchone()
            if not row:
                raise HTTPException(status_code=404, detail="Active activation key not found")
            write_audit(
                conn,
                "ACTIVATION_KEY_REVOKED",
                actor_type="user",
                actor_user_id=ctx.user_id,
                organization_id=ctx.organization_id,
                license_id=license_id,
                ip_address=client_ip(request),
                metadata={"activation_key_id": str(key_id)},
            )
    return {"revoked": True}


@router.post("/licenses/{license_id}/installations/{installation_db_id}/deactivate")
def account_deactivate_installation(
    license_id: UUID,
    installation_db_id: UUID,
    request: Request,
    ctx: AuthContext = Depends(get_auth_context),
):
    require_origin(request)
    require_role(ctx, "owner", "admin")
    with get_pool().connection() as conn:
        with conn.transaction():
            installation = conn.execute(
                """
                SELECT i.id FROM installations i JOIN licenses l ON l.id=i.license_id
                WHERE i.id=%s AND i.license_id=%s AND l.organization_id=%s FOR UPDATE
                """,
                (installation_db_id, license_id, ctx.organization_id),
            ).fetchone()
            if not installation:
                raise HTTPException(status_code=404, detail="Installation not found")
            conn.execute(
                "UPDATE installations SET status='deactivated',deactivated_at=now(),updated_at=now() WHERE id=%s",
                (installation_db_id,),
            )
            conn.execute(
                "UPDATE installation_credentials SET status='revoked',revoked_at=now() WHERE installation_id=%s AND status='active'",
                (installation_db_id,),
            )
            write_audit(
                conn,
                "INSTALLATION_DEACTIVATED",
                actor_type="user",
                actor_user_id=ctx.user_id,
                organization_id=ctx.organization_id,
                license_id=license_id,
                installation_id=installation_db_id,
                ip_address=client_ip(request),
            )
    return {"deactivated": True}


@router.get("/trials")
def list_trials(ctx: AuthContext = Depends(get_auth_context)):
    require_org(ctx)
    with get_pool().connection() as conn:
        rows = conn.execute(
            """
            SELECT tr.id,tr.requested_edition,tr.status,tr.use_case,tr.requested_at,tr.decided_at,
                   tr.approved_license_id,p.code::text AS product
            FROM trial_requests tr JOIN products p ON p.id=tr.product_id
            WHERE tr.organization_id=%s ORDER BY tr.requested_at DESC
            """,
            (ctx.organization_id,),
        ).fetchall()
    return [{**row, "id": str(row["id"]), "approved_license_id": str(row["approved_license_id"]) if row["approved_license_id"] else None} for row in rows]


@router.post("/trials", status_code=201)
def request_trial(payload: TrialRequestCreate, request: Request, ctx: AuthContext = Depends(get_auth_context)):
    require_origin(request)
    require_role(ctx, "owner", "admin", "billing")
    with get_pool().connection() as conn:
        with conn.transaction():
            product = conn.execute("SELECT id FROM products WHERE code='HILOP' AND status='active'").fetchone()
            if not product:
                raise HTTPException(status_code=503, detail="HILOP product is unavailable")
            existing = conn.execute(
                """
                SELECT id FROM trial_requests
                WHERE organization_id=%s AND product_id=%s AND status='pending'
                """,
                (ctx.organization_id, product["id"]),
            ).fetchone()
            if existing:
                raise HTTPException(status_code=409, detail="A HILOP trial request is already pending")
            trial = conn.execute(
                """
                INSERT INTO trial_requests(organization_id,requested_by_user_id,product_id,requested_edition,use_case)
                VALUES (%s,%s,%s,%s,%s) RETURNING id,requested_at
                """,
                (ctx.organization_id, ctx.user_id, product["id"], payload.requested_edition, payload.use_case),
            ).fetchone()
            write_audit(
                conn,
                "TRIAL_REQUESTED",
                actor_type="user",
                actor_user_id=ctx.user_id,
                organization_id=ctx.organization_id,
                ip_address=client_ip(request),
                metadata={"trial_request_id": str(trial["id"])},
            )
    return {"id": str(trial["id"]), "status": "pending", "requested_at": trial["requested_at"]}


@router.post("/email-verification/request", status_code=202)
def request_verification(request: Request, background: BackgroundTasks, ctx: AuthContext = Depends(get_auth_context)):
    require_origin(request)
    if ctx.email_verified:
        return {"accepted": True}
    if get_settings().smtp_mode != "smtp":
        raise HTTPException(status_code=503, detail="Email delivery is not configured")
    with get_pool().connection() as conn:
        with conn.transaction():
            token = _create_user_token(conn, ctx.user_id, "email_verification", timedelta(hours=24))
    background.add_task(send_verification, ctx.email, token)
    return {"accepted": True}


@router.post("/email-verification/verify")
def verify_email_post(payload: TokenRequest):
    return _verify_email_token(payload.token)


@router.get("/email-verification/verify")
def verify_email_get(token: str):
    _verify_email_token(token)
    return RedirectResponse(url=f"{get_settings().public_base_url}/account-login?verified=1", status_code=303)


def _verify_email_token(token: str):
    with get_pool().connection() as conn:
        with conn.transaction():
            row = conn.execute(
                """
                SELECT id,user_id FROM user_tokens
                WHERE token_type='email_verification' AND token_hash=%s
                  AND consumed_at IS NULL AND expires_at>now()
                FOR UPDATE
                """,
                (hash_token(token),),
            ).fetchone()
            if not row:
                raise HTTPException(status_code=400, detail="Invalid or expired verification token")
            conn.execute("UPDATE user_tokens SET consumed_at=now() WHERE id=%s", (row["id"],))
            conn.execute("UPDATE users SET email_verified_at=COALESCE(email_verified_at,now()),updated_at=now() WHERE id=%s", (row["user_id"],))
            write_audit(conn, "EMAIL_VERIFIED", actor_type="user", actor_user_id=row["user_id"])
    return {"verified": True}


@router.post("/password-reset/request", status_code=202)
def password_reset_request(payload: PasswordResetRequest, request: Request, background: BackgroundTasks):
    require_origin(request)
    ip = client_ip(request) or "unknown"
    if not limiter.allow(f"password-reset:{ip}", 5, 3600):
        raise HTTPException(status_code=429, detail="Too many password reset attempts")
    email = str(payload.email).strip().lower()
    token = None
    with get_pool().connection() as conn:
        with conn.transaction():
            user = conn.execute("SELECT id,email::text AS email FROM users WHERE email=%s AND disabled_at IS NULL", (email,)).fetchone()
            if user:
                token = _create_user_token(conn, user["id"], "password_reset", timedelta(hours=1))
                write_audit(conn, "PASSWORD_RESET_REQUESTED", actor_user_id=user["id"], ip_address=ip)
    if token and get_settings().smtp_mode == "smtp":
        background.add_task(send_password_reset, email, token)
    return {"accepted": True}


@router.post("/password-reset/complete")
def password_reset_complete(payload: PasswordResetComplete, request: Request):
    require_origin(request)
    try:
        validate_password(payload.new_password)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    with get_pool().connection() as conn:
        with conn.transaction():
            row = conn.execute(
                """
                SELECT id,user_id FROM user_tokens
                WHERE token_type='password_reset' AND token_hash=%s
                  AND consumed_at IS NULL AND expires_at>now()
                FOR UPDATE
                """,
                (hash_token(payload.token),),
            ).fetchone()
            if not row:
                raise HTTPException(status_code=400, detail="Invalid or expired reset token")
            conn.execute("UPDATE user_tokens SET consumed_at=now() WHERE id=%s", (row["id"],))
            conn.execute("UPDATE users SET password_hash=%s,updated_at=now() WHERE id=%s", (hash_password(payload.new_password), row["user_id"]))
            conn.execute("UPDATE user_sessions SET revoked_at=now() WHERE user_id=%s AND revoked_at IS NULL", (row["user_id"],))
            write_audit(conn, "PASSWORD_RESET_COMPLETED", actor_type="user", actor_user_id=row["user_id"], ip_address=client_ip(request))
    return {"reset": True}
