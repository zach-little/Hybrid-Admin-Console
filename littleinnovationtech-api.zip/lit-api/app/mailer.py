from __future__ import annotations

import smtplib
from email.message import EmailMessage
from urllib.parse import quote

from .config import get_settings


def _send(to_address: str, subject: str, text: str) -> None:
    settings = get_settings()
    if settings.smtp_mode != "smtp":
        return

    message = EmailMessage()
    message["From"] = settings.smtp_from
    message["To"] = to_address
    message["Subject"] = subject
    message.set_content(text)

    with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=15) as smtp:
        if settings.smtp_starttls:
            smtp.starttls()
        if settings.smtp_username:
            smtp.login(settings.smtp_username, settings.smtp_password)
        smtp.send_message(message)


def send_verification(to_address: str, token: str) -> None:
    settings = get_settings()
    url = f"{settings.public_base_url}/api/v1/account/email-verification/verify?token={quote(token)}"
    _send(
        to_address,
        "Verify your Little Innovation Tech account",
        f"Verify your account by opening this link:\n\n{url}\n\nIf you did not create this account, ignore this message.",
    )


def send_password_reset(to_address: str, token: str) -> None:
    settings = get_settings()
    url = f"{settings.public_base_url}/account-login?reset_token={quote(token)}"
    _send(
        to_address,
        "Reset your Little Innovation Tech password",
        f"Use this password reset token from the account portal:\n\n{token}\n\nPortal: {url}\n\nIf you did not request a reset, ignore this message.",
    )


def send_organization_invitation(to_address: str, organization_name: str, role: str, token: str) -> None:
    settings = get_settings()
    url = f"{settings.public_base_url}/account-register?invite={quote(token)}"
    _send(
        to_address,
        f"Invitation to {organization_name} on Little Innovation Tech",
        (
            f"You have been invited to join {organization_name} as {role}.\n\n"
            f"Accept the invitation here:\n\n{url}\n\n"
            "If you were not expecting this invitation, ignore this message."
        ),
    )
