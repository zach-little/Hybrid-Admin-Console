from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import string
from datetime import datetime, timedelta, timezone

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError

from .config import get_settings

_password_hasher = PasswordHasher()
_dummy_password_hash = _password_hasher.hash("not-a-real-user-password")
_activation_alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def hash_password(password: str) -> str:
    return _password_hasher.hash(password)


def verify_password(password_hash: str, password: str) -> tuple[bool, str | None]:
    try:
        _password_hasher.verify(password_hash, password)
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        return False, None
    if _password_hasher.check_needs_rehash(password_hash):
        return True, _password_hasher.hash(password)
    return True, None


def burn_dummy_password_check(password: str) -> None:
    try:
        _password_hasher.verify(_dummy_password_hash, password)
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        pass


def validate_password(password: str) -> None:
    if len(password) < 12:
        raise ValueError("Password must be at least 12 characters")
    if len(password) > 128:
        raise ValueError("Password must be at most 128 characters")


def random_token(prefix: str, nbytes: int = 32) -> str:
    raw = base64.urlsafe_b64encode(secrets.token_bytes(nbytes)).decode("ascii").rstrip("=")
    return f"{prefix}{raw}"


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def hash_activation_key(key: str) -> str:
    pepper = get_settings().activation_key_pepper.encode("utf-8")
    normalized = key.strip().upper().encode("utf-8")
    return hmac.new(pepper, normalized, hashlib.sha256).hexdigest()


def generate_activation_key() -> tuple[str, str, str, str]:
    groups = ["".join(secrets.choice(_activation_alphabet) for _ in range(4)) for _ in range(4)]
    key = "HILOP-" + "-".join(groups)
    prefix = f"HILOP-{groups[0]}"
    last_four = groups[-1]
    return key, prefix, last_four, hash_activation_key(key)


def session_expiry() -> datetime:
    return utcnow() + timedelta(hours=get_settings().session_ttl_hours)


def b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def constant_time_equal(left: str, right: str) -> bool:
    return hmac.compare_digest(left.encode("utf-8"), right.encode("utf-8"))


def create_admin_session_token() -> tuple[str, datetime]:
    settings = get_settings()
    expires = utcnow() + timedelta(hours=settings.admin_session_ttl_hours)
    expires_unix = int(expires.timestamp())
    nonce = secrets.token_urlsafe(18)
    payload = f"v1.{expires_unix}.{nonce}"
    signature = hmac.new(
        settings.admin_api_key.encode("utf-8"),
        payload.encode("utf-8"),
        hashlib.sha256,
    ).digest()
    return f"{payload}.{b64url(signature)}", expires


def validate_admin_session_token(token: str) -> bool:
    try:
        version, expires_raw, nonce, signature = token.split(".", 3)
        if version != "v1" or not nonce or int(expires_raw) <= int(utcnow().timestamp()):
            return False
        payload = f"{version}.{expires_raw}.{nonce}"
        expected = b64url(
            hmac.new(
                get_settings().admin_api_key.encode("utf-8"),
                payload.encode("utf-8"),
                hashlib.sha256,
            ).digest()
        )
        return constant_time_equal(signature, expected)
    except (ValueError, TypeError):
        return False
