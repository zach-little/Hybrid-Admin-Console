from __future__ import annotations

from datetime import datetime
from typing import Any, Literal
from uuid import UUID

from pydantic import BaseModel, EmailStr, Field, field_validator


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=12, max_length=128)
    first_name: str | None = Field(default=None, max_length=100)
    last_name: str | None = Field(default=None, max_length=100)
    organization_name: str | None = Field(default=None, min_length=2, max_length=160)
    invitation_token: str | None = Field(default=None, min_length=20, max_length=512)


class ProfileUpdateRequest(BaseModel):
    first_name: str | None = Field(default=None, max_length=100)
    last_name: str | None = Field(default=None, max_length=100)


class MemberInvitationRequest(BaseModel):
    email: EmailStr
    role: Literal["admin", "billing", "member", "viewer"] = "member"


class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=128)


class OrganizationUpdateRequest(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=160)
    licensing_email: EmailStr | None = None


class TrialRequestCreate(BaseModel):
    requested_edition: str = Field(default="professional", min_length=2, max_length=64)
    use_case: str | None = Field(default=None, max_length=3000)


class TokenRequest(BaseModel):
    token: str = Field(min_length=20, max_length=512)


class PasswordResetRequest(BaseModel):
    email: EmailStr


class PasswordResetComplete(BaseModel):
    token: str = Field(min_length=20, max_length=512)
    new_password: str = Field(min_length=12, max_length=128)


class ActivationRequest(BaseModel):
    activation_key: str = Field(min_length=20, max_length=128)
    installation_id: str = Field(min_length=8, max_length=200)
    hostname: str | None = Field(default=None, max_length=255)
    version: str | None = Field(default=None, max_length=100)
    display_name: str | None = Field(default=None, max_length=200)

    @field_validator("activation_key")
    @classmethod
    def normalize_key(cls, value: str) -> str:
        return value.strip().upper()


class RefreshRequest(BaseModel):
    hostname: str | None = Field(default=None, max_length=255)
    version: str | None = Field(default=None, max_length=100)


class AdminSessionCreate(BaseModel):
    api_key: str = Field(min_length=32, max_length=512)


class AdminOrganizationCreate(BaseModel):
    name: str = Field(min_length=2, max_length=160)
    slug: str | None = Field(default=None, max_length=160)
    licensing_email: EmailStr | None = None


class AdminOrganizationUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=160)
    licensing_email: EmailStr | None = None
    status: Literal["active", "suspended", "closed"] | None = None


LicenseType = Literal["trial", "subscription", "perpetual", "nfr", "development", "partner", "beta"]
LicenseStatusEditable = Literal["draft", "active", "suspended", "expired", "converted"]


class AdminLicenseCreate(BaseModel):
    organization_id: UUID
    license_type: LicenseType
    edition: str = Field(min_length=2, max_length=64)
    valid_from: datetime | None = None
    expires_at: datetime | None = None
    grace_until: datetime | None = None
    maintenance_until: datetime | None = None
    max_installations: int = Field(default=1, ge=0, le=10000)
    notes: str | None = Field(default=None, max_length=5000)
    entitlements: dict[str, Any] = Field(default_factory=dict)


class AdminLicenseUpdate(BaseModel):
    edition: str | None = Field(default=None, min_length=2, max_length=64)
    status: LicenseStatusEditable | None = None
    valid_from: datetime | None = None
    expires_at: datetime | None = None
    grace_until: datetime | None = None
    maintenance_until: datetime | None = None
    max_installations: int | None = Field(default=None, ge=0, le=10000)
    notes: str | None = Field(default=None, max_length=5000)
    entitlements: dict[str, Any] | None = None


class AdminActivationKeyCreate(BaseModel):
    max_uses: int = Field(default=1, ge=1, le=1000)
    expires_at: datetime | None = None


class AdminLicenseRevoke(BaseModel):
    reason: str = Field(min_length=2, max_length=1000)


class AdminTrialApprove(BaseModel):
    duration_days: int = Field(default=30, ge=1, le=3650)
    grace_days: int = Field(default=3, ge=0, le=365)
    edition: str | None = Field(default=None, min_length=2, max_length=64)
    max_installations: int = Field(default=1, ge=1, le=1000)
    entitlements: dict[str, Any] = Field(default_factory=dict)


class AdminTrialDecline(BaseModel):
    reason: str | None = Field(default=None, max_length=1000)
