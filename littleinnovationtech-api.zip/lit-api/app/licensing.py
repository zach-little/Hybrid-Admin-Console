from __future__ import annotations

import json
import secrets
import string
from datetime import datetime, timezone
from typing import Any

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from fastapi import HTTPException

from .config import get_settings
from .security import b64url, generate_activation_key, utcnow

_private_key: Ed25519PrivateKey | None = None


def _iso(value: datetime | None) -> str | None:
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    value = value.astimezone(timezone.utc)
    return value.isoformat(timespec="seconds").replace("+00:00", "Z")


def load_signing_key() -> Ed25519PrivateKey:
    global _private_key
    if _private_key is not None:
        return _private_key
    settings = get_settings()
    with open(settings.signing_private_key_file, "rb") as handle:
        key = serialization.load_pem_private_key(handle.read(), password=None)
    if not isinstance(key, Ed25519PrivateKey):
        raise RuntimeError("Configured signing key is not Ed25519")
    _private_key = key
    return key


def public_key_b64() -> str:
    key = load_signing_key().public_key()
    raw = key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    return b64url(raw)


def register_signing_key(conn) -> None:
    settings = get_settings()
    public_key = public_key_b64()
    existing = conn.execute(
        "SELECT public_key,algorithm FROM signing_keys WHERE key_id=%s",
        (settings.signing_key_id,),
    ).fetchone()
    if existing:
        if existing["algorithm"] != "Ed25519" or existing["public_key"] != public_key:
            raise RuntimeError(
                "SIGNING_KEY_ID already exists with different key material; use a new key_id for rotation"
            )
        conn.execute(
            "UPDATE signing_keys SET secret_reference=%s WHERE key_id=%s",
            (settings.signing_private_key_file, settings.signing_key_id),
        )
        return
    conn.execute(
        """
        INSERT INTO signing_keys(key_id, algorithm, public_key, status, secret_reference)
        VALUES (%s,'Ed25519',%s,'active',%s)
        """,
        (settings.signing_key_id, public_key, settings.signing_private_key_file),
    )


def signing_key_document() -> dict[str, Any]:
    settings = get_settings()
    return {
        "schema": "hilop-license-key/v1",
        "algorithm": "Ed25519",
        "key_id": settings.signing_key_id,
        "public_key_b64": public_key_b64(),
    }


def effective_license_status(license_row, now: datetime | None = None) -> str:
    now = now or utcnow()
    state = license_row["status"]
    if state in {"revoked", "suspended", "expired", "draft", "converted"}:
        return state
    if now < license_row["valid_from"]:
        return "not_yet_valid"
    expires_at = license_row["expires_at"]
    grace_until = license_row["grace_until"]
    if expires_at and now > expires_at:
        if grace_until and now <= grace_until:
            return "grace_period"
        return "expired"
    return "active"


def _entitlements(conn, license_id) -> dict[str, Any]:
    rows = conn.execute(
        """
        SELECT ed.entitlement_key::text AS entitlement_key, le.value
        FROM license_entitlements le
        JOIN entitlement_definitions ed ON ed.id=le.entitlement_definition_id
        WHERE le.license_id=%s
        ORDER BY ed.entitlement_key
        """,
        (license_id,),
    ).fetchall()
    result: dict[str, Any] = {}
    for row in rows:
        value = row["value"]
        result[row["entitlement_key"]] = value
    return result


def set_entitlements(conn, license_id, product_id, entitlements: dict[str, Any]) -> None:
    definitions = conn.execute(
        """
        SELECT id, entitlement_key::text AS entitlement_key, value_type
        FROM entitlement_definitions
        WHERE product_id=%s
        """,
        (product_id,),
    ).fetchall()
    by_key = {row["entitlement_key"]: row for row in definitions}
    unknown = sorted(set(entitlements) - set(by_key))
    if unknown:
        raise HTTPException(status_code=400, detail=f"Unknown entitlements: {', '.join(unknown)}")

    for key, value in entitlements.items():
        definition = by_key[key]
        value_type = definition["value_type"]
        valid = (
            (value_type == "boolean" and type(value) is bool)
            or (value_type == "integer" and type(value) is int and value >= 0)
            or (value_type == "string" and isinstance(value, str))
        )
        if not valid:
            raise HTTPException(status_code=400, detail=f"Invalid value for entitlement '{key}'")
        conn.execute(
            """
            INSERT INTO license_entitlements(license_id, entitlement_definition_id, value)
            VALUES (%s,%s,%s::jsonb)
            ON CONFLICT(license_id, entitlement_definition_id)
            DO UPDATE SET value=EXCLUDED.value, updated_at=now()
            """,
            (license_id, definition["id"], json.dumps(value)),
        )


def issue_license_document(conn, license_id, installation_db_id) -> dict[str, Any]:
    settings = get_settings()
    row = conn.execute(
        """
        SELECT l.*, p.code::text AS product_code, o.name AS organization_name,
               i.installation_id AS external_installation_id
        FROM licenses l
        JOIN products p ON p.id=l.product_id
        JOIN organizations o ON o.id=l.organization_id
        JOIN installations i ON i.id=%s AND i.license_id=l.id
        WHERE l.id=%s
        """,
        (installation_db_id, license_id),
    ).fetchone()
    if not row:
        raise RuntimeError("License or installation not found while issuing license document")

    issued_at = utcnow()
    payload = {
        "schema": "hilop-license/v1",
        "license_id": str(row["id"]),
        "license_number": str(row["license_number"]),
        "installation_id": row["external_installation_id"],
        "product": row["product_code"],
        "organization": row["organization_name"],
        "license_type": row["license_type"],
        "edition": row["edition"],
        "status": effective_license_status(row, issued_at),
        "issued_at": _iso(issued_at),
        "not_before": _iso(row["valid_from"]),
        "expires_at": _iso(row["expires_at"]),
        "grace_until": _iso(row["grace_until"]),
        "maintenance_until": _iso(row["maintenance_until"]),
        "entitlements": _entitlements(conn, license_id),
        "signing": {"algorithm": "Ed25519", "key_id": settings.signing_key_id},
    }
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    canonical_bytes = canonical.encode("utf-8")
    signature = load_signing_key().sign(canonical_bytes)
    signature_b64 = b64url(signature)
    payload_b64 = b64url(canonical_bytes)
    document_expiry = row["grace_until"] or row["expires_at"]

    conn.execute(
        """
        UPDATE license_documents
        SET superseded_at=now()
        WHERE installation_id=%s AND superseded_at IS NULL
        """,
        (installation_db_id,),
    )
    document = conn.execute(
        """
        INSERT INTO license_documents(
            license_id, installation_id, schema_version, signing_key_id,
            payload, canonical_payload, signature, issued_at, expires_at
        )
        VALUES (%s,%s,'hilop-license/v1',%s,%s::jsonb,%s,%s,%s,%s)
        RETURNING id
        """,
        (
            license_id,
            installation_db_id,
            settings.signing_key_id,
            canonical,
            canonical,
            signature_b64,
            issued_at,
            document_expiry,
        ),
    ).fetchone()

    return {
        "document_id": str(document["id"]),
        "payload": payload,
        "payload_b64": payload_b64,
        "signature": signature_b64,
        "algorithm": "Ed25519",
        "key_id": settings.signing_key_id,
    }


def generate_license_number(conn, product_code: str = "HIL") -> str:
    year = utcnow().year
    alphabet = string.ascii_uppercase + string.digits
    for _ in range(20):
        suffix = "".join(secrets.choice(alphabet) for _ in range(8))
        candidate = f"{product_code}-{year}-{suffix}"
        exists = conn.execute("SELECT 1 FROM licenses WHERE license_number=%s", (candidate,)).fetchone()
        if not exists:
            return candidate
    raise RuntimeError("Unable to generate unique license number")


def create_activation_key(conn, license_id, *, max_uses: int = 1, expires_at=None, created_by_user_id=None):
    for _ in range(10):
        raw, prefix, last_four, key_hash = generate_activation_key()
        try:
            row = conn.execute(
                """
                INSERT INTO activation_keys(
                    license_id,key_prefix,key_hash,last_four,max_uses,expires_at,created_by_user_id
                )
                VALUES (%s,%s,%s,%s,%s,%s,%s)
                RETURNING id, created_at
                """,
                (license_id, prefix, key_hash, last_four, max_uses, expires_at, created_by_user_id),
            ).fetchone()
            return {
                "id": str(row["id"]),
                "activation_key": raw,
                "key_prefix": prefix,
                "last_four": last_four,
                "max_uses": max_uses,
                "expires_at": _iso(expires_at),
                "created_at": _iso(row["created_at"]),
            }
        except Exception as exc:
            if getattr(exc, "sqlstate", None) == "23505":
                continue
            raise
    raise RuntimeError("Unable to generate unique activation key")
