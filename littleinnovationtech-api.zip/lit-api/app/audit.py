from __future__ import annotations

from typing import Any


def write_audit(
    conn,
    event_type: str,
    *,
    actor_type: str = "system",
    actor_user_id=None,
    organization_id=None,
    license_id=None,
    installation_id=None,
    ip_address: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> None:
    conn.execute(
        """
        INSERT INTO audit_events(
            event_type, actor_type, actor_user_id, organization_id,
            license_id, installation_id, ip_address, metadata
        )
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s::jsonb)
        """,
        (
            event_type,
            actor_type,
            actor_user_id,
            organization_id,
            license_id,
            installation_id,
            ip_address,
            __import__("json").dumps(metadata or {}, separators=(",", ":")),
        ),
    )
