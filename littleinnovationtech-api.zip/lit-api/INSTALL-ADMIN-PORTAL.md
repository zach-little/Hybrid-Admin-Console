# Little Innovation Tech Internal Licensing Admin Portal

This patch adds the internal licensing operations UI and supporting `lit-api` endpoints.

## Database

No database migration is required. It uses the existing HILOP licensing schema.

## Install

Back up the current site and API, then unzip the patch into `/opt/littlecastle/apps/` and rebuild `lit-api`:

```bash
sudo mkdir -p /opt/littlecastle/backups
sudo tar -czf /opt/littlecastle/backups/lil-before-admin-portal-$(date +%Y%m%d-%H%M%S).tar.gz -C /opt/littlecastle/apps lil
sudo tar -czf /opt/littlecastle/backups/lit-api-before-admin-portal-$(date +%Y%m%d-%H%M%S).tar.gz -C /opt/littlecastle/apps lit-api
sudo unzip -o /tmp/LittleInnovationTech_Internal_Licensing_Admin_Patch_2026-08-16.zip -d /opt/littlecastle/apps/
cd /opt/littlecastle/apps/lit-api
sudo ./deploy/run-lit-api.sh
```

## Verify

```bash
sudo docker ps --filter name=lit-api
sudo docker logs --tail 100 lit-api
curl -sS https://littleinnovation.tech/api/v1/health/ready
```

The readiness response should report the database ready and the HILOP signing key ID.

The public website does not link to the internal console. Open:

`https://littleinnovation.tech/internal-admin-login`

Use the existing `ADMIN_API_KEY` from `/opt/littlecastle/secrets/lit-api.env`. The browser sends it once to the API; the API returns a short-lived HttpOnly/Secure/SameSite=Strict signed admin-session cookie. The key is not saved in JavaScript storage.

## New internal API functions

- Admin session create/status/delete
- Dashboard metrics and recent activity
- Organization list/detail/create/update
- License list/detail/create/update/revoke
- Entitlement definition catalog
- Activation-key create/revoke
- Installation deactivation
- Trial list/approve/decline
- Audit listing

Header-based `X-LIT-Admin-Key` access remains supported for CLI workflows.
