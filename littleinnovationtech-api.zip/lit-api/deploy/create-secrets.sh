#!/usr/bin/env sh
set -eu

SECRETS_DIR="/opt/littlecastle/secrets"
API_ENV="$SECRETS_DIR/lit-api.env"
SIGN_DIR="$SECRETS_DIR/hilop-signing"
PRIVATE_KEY="$SIGN_DIR/lit-hilop-2026-01-private.pem"
PUBLIC_KEY="$SIGN_DIR/lit-hilop-2026-01-public.pem"

sudo install -d -m 700 "$SECRETS_DIR" "$SIGN_DIR"

if [ ! -f "$PRIVATE_KEY" ]; then
  sudo openssl genpkey -algorithm ED25519 -out "$PRIVATE_KEY"
fi
if [ ! -f "$PUBLIC_KEY" ]; then
  sudo openssl pkey -in "$PRIVATE_KEY" -pubout -out "$PUBLIC_KEY"
fi
sudo chown 10001:10001 "$PRIVATE_KEY"
sudo chmod 400 "$PRIVATE_KEY"
sudo chmod 644 "$PUBLIC_KEY"

if [ ! -f "$API_ENV" ]; then
  ADMIN_API_KEY=$(openssl rand -hex 32)
  ACTIVATION_KEY_PEPPER=$(openssl rand -hex 32)
  sudo sh -c "umask 077; cat > '$API_ENV'" <<EOF
ENVIRONMENT=production
PUBLIC_BASE_URL=https://littleinnovation.tech
ALLOWED_ORIGINS=https://littleinnovation.tech,https://www.littleinnovation.tech
DB_POOL_MIN=1
DB_POOL_MAX=10
SESSION_COOKIE_NAME=lit_session
SESSION_TTL_HOURS=168
SESSION_COOKIE_SECURE=true
REQUIRE_EMAIL_VERIFICATION=false
ADMIN_API_KEY=$ADMIN_API_KEY
ACTIVATION_KEY_PEPPER=$ACTIVATION_KEY_PEPPER
SIGNING_KEY_ID=lit-hilop-2026-01
SIGNING_PRIVATE_KEY_FILE=/run/secrets/hilop_ed25519_private.pem
SMTP_MODE=disabled
SMTP_HOST=
SMTP_PORT=587
SMTP_USERNAME=
SMTP_PASSWORD=
SMTP_FROM=
SMTP_STARTTLS=true
EOF
  sudo chmod 600 "$API_ENV"
fi

printf '%s\n' "Secrets ready:"
printf '  %s\n' "$API_ENV" "$PRIVATE_KEY" "$PUBLIC_KEY"
