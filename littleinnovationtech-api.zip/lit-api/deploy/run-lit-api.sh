#!/usr/bin/env sh
set -eu

APP_DIR="/opt/littlecastle/apps/lit-api"
DB_ENV="/opt/littlecastle/secrets/lit-licensing-app.env"
API_ENV="/opt/littlecastle/secrets/lit-api.env"
PRIVATE_KEY="/opt/littlecastle/secrets/hilop-signing/lit-hilop-2026-01-private.pem"

for path in "$APP_DIR/Dockerfile" "$DB_ENV" "$API_ENV" "$PRIVATE_KEY"; do
  if [ ! -e "$path" ]; then
    echo "Missing required path: $path" >&2
    exit 1
  fi
done

docker network inspect lit-services >/dev/null 2>&1 || docker network create lit-services

docker build -t littleinnovation/lit-api:1.0.0 "$APP_DIR"

docker rm -f lit-api >/dev/null 2>&1 || true

docker run -d \
  --name lit-api \
  --restart unless-stopped \
  --network lit-services \
  --env-file "$DB_ENV" \
  --env-file "$API_ENV" \
  --mount type=bind,src="$PRIVATE_KEY",dst=/run/secrets/hilop_ed25519_private.pem,readonly \
  --read-only \
  --tmpfs /tmp:rw,noexec,nosuid,size=32m \
  --security-opt no-new-privileges:true \
  --cap-drop ALL \
  --health-cmd="python -c 'import urllib.request; urllib.request.urlopen(\"http://127.0.0.1:8080/api/v1/health/live\", timeout=3)'" \
  --health-interval=10s \
  --health-timeout=5s \
  --health-retries=12 \
  littleinnovation/lit-api:1.0.0

echo "lit-api started."
docker ps --filter name=lit-api
