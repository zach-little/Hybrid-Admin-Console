#region Module Information
# Name: Application.HybridUserAggregationService
# Purpose: Milestone 7 Phase 7 orchestration layer that aggregates user verticals into one composite profile.
# Dependencies: Application.HybridUserService exported commands.
# Exports: Initialize-HybridUserAggregationService, Get-HybridUserAggregateProfile, Get-HybridUserAggregationServiceHealth, Clear-HybridUserAggregationService
#endregion

Set-StrictMode -Version Latest

$script:HybridUserAggregationState = @{
    Initialized = $false
    Cache = @{}
    LastIdentity = $null
    LastError = $null
}

function Get-HybridAggregationValue {
    [CmdletBinding()]
    param(
        [AllowNull()][object]$InputObject,
        [Parameter(Mandatory=$true)][string[]]$Names,
        [AllowNull()][object]$Default = $null
    )

    foreach ($name in $Names) {
        if ($null -ne $InputObject -and $InputObject.PSObject.Properties.Name -contains $name) {
            $value = $InputObject.$name
            if ($null -ne $value -and -not [string]::IsNullOrWhiteSpace([string]$value)) { return $value }
        }
    }
    return $Default
}

function New-HybridAggregationVerticalStatus {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Name,
        [AllowNull()][object]$Data,
        [AllowNull()][string]$ErrorMessage = $null
    )

    [pscustomobject]@{
        PSTypeName = 'Hybrid.Aggregation.VerticalStatus'
        Name = $Name
        Loaded = ($null -ne $Data -and [string]::IsNullOrWhiteSpace($ErrorMessage))
        Error = $ErrorMessage
        DataType = if ($null -ne $Data) { ($Data.PSObject.TypeNames | Select-Object -First 1) } else { $null }
        RetrievedOn = [datetime]::UtcNow
    }
}

function Invoke-HybridAggregationStep {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Name,
        [Parameter(Mandatory=$true)][scriptblock]$ScriptBlock
    )

    try {
        $data = & $ScriptBlock
        [pscustomobject]@{
            Data = $data
            Status = (New-HybridAggregationVerticalStatus -Name $Name -Data $data)
        }
    }
    catch {
        [pscustomobject]@{
            Data = $null
            Status = (New-HybridAggregationVerticalStatus -Name $Name -Data $null -ErrorMessage $_.Exception.Message)
        }
    }
}

function Initialize-HybridUserAggregationService {
    [CmdletBinding()]
    param()

    $script:HybridUserAggregationState.Initialized = $true
    $script:HybridUserAggregationState.Cache.Clear()
    $script:HybridUserAggregationState.LastIdentity = $null
    $script:HybridUserAggregationState.LastError = $null

    $service = [pscustomobject]@{
        Name = 'HybridUserAggregationService'
        Initialized = $true
        GetAggregateProfile = ({ param([string]$Identity) Get-HybridUserAggregateProfile -Identity $Identity }).GetNewClosure()
        GetHealth = ({ Get-HybridUserAggregationServiceHealth }).GetNewClosure()
    }
    $service.PSObject.TypeNames.Insert(0, 'Hybrid.UserAggregationService')
    $service | Add-Member -MemberType NoteProperty -Name PSTypeName -Value 'Hybrid.UserAggregationService' -Force
    return $service
}

function Get-HybridUserAggregateProfile {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Identity,
        [switch]$Refresh
    )

    if (-not $script:HybridUserAggregationState.Initialized) {
        Initialize-HybridUserAggregationService | Out-Null
    }
    if ([string]::IsNullOrWhiteSpace($Identity)) { throw 'User identity cannot be empty.' }

    $cacheKey = $Identity.ToLowerInvariant()
    if (-not $Refresh -and $script:HybridUserAggregationState.Cache.ContainsKey($cacheKey)) {
        return $script:HybridUserAggregationState.Cache[$cacheKey]
    }

    try {
        $script:HybridUserAggregationState.LastIdentity = $Identity

        $baseStep = Invoke-HybridAggregationStep -Name 'BaseUser' -ScriptBlock { Get-HybridUser -Identity $Identity }
        $detailStep = Invoke-HybridAggregationStep -Name 'ActiveDirectoryDetails' -ScriptBlock { Get-HybridUserDetails -Identity $Identity }
        $exchangeStep = Invoke-HybridAggregationStep -Name 'ExchangeMailbox' -ScriptBlock { Get-HybridUserMailboxDetails -Identity $Identity }
        $graphStep = Invoke-HybridAggregationStep -Name 'MicrosoftGraph' -ScriptBlock { Get-HybridUserGraphProfile -Identity $Identity }
        $authStep = Invoke-HybridAggregationStep -Name 'AuthenticationPosture' -ScriptBlock { Get-HybridUserAuthenticationProfile -Identity $Identity }

        $primaryUser = $detailStep.Data
        if ($null -eq $primaryUser) { $primaryUser = $baseStep.Data }

        $verticals = @($baseStep.Status, $detailStep.Status, $exchangeStep.Status, $graphStep.Status, $authStep.Status)
        $loadedCount = @($verticals | Where-Object { $_.Loaded }).Count

        $aggregate = [pscustomobject]@{
            Identity = $Identity
            DisplayName = [string](Get-HybridAggregationValue -InputObject $primaryUser -Names @('DisplayName','Name') -Default $Identity)
            UserPrincipalName = [string](Get-HybridAggregationValue -InputObject $primaryUser -Names @('UserPrincipalName','UPN','Mail') -Default $Identity)
            User = $primaryUser
            BaseUser = $baseStep.Data
            Details = $detailStep.Data
            MailboxDetails = if ($null -ne $exchangeStep.Data -and $exchangeStep.Data.PSObject.Properties.Name -contains 'MailboxDetails') { $exchangeStep.Data.MailboxDetails } else { $null }
            GraphProfile = $graphStep.Data
            AuthenticationProfile = $authStep.Data
            Verticals = $verticals
            LoadedVerticalCount = $loadedCount
            TotalVerticalCount = $verticals.Count
            Complete = ($loadedCount -eq $verticals.Count)
            RetrievedOn = [datetime]::UtcNow
            Source = 'HybridUserAggregationService'
        }
        $aggregate.PSObject.TypeNames.Insert(0, 'Hybrid.UserAggregateProfile')
        $aggregate.PSObject.TypeNames.Insert(0, 'Hybrid.UserAggregateProfile.Milestone7Phase7')
        $aggregate | Add-Member -MemberType NoteProperty -Name PSTypeName -Value 'Hybrid.UserAggregateProfile' -Force

        $script:HybridUserAggregationState.Cache[$cacheKey] = $aggregate
        return $aggregate
    }
    catch {
        $script:HybridUserAggregationState.LastError = $_.Exception.Message
        throw
    }
}

function Get-HybridUserAggregationServiceHealth {
    [CmdletBinding()]
    param()

    $health = [pscustomobject]@{
        Initialized = [bool]$script:HybridUserAggregationState.Initialized
        CacheEntries = $script:HybridUserAggregationState.Cache.Count
        LastIdentity = $script:HybridUserAggregationState.LastIdentity
        LastError = $script:HybridUserAggregationState.LastError
    }
    $health.PSObject.TypeNames.Insert(0, 'Hybrid.UserAggregationServiceHealth')
    $health | Add-Member -MemberType NoteProperty -Name PSTypeName -Value 'Hybrid.UserAggregationServiceHealth' -Force
    return $health
}

function Clear-HybridUserAggregationService {
    [CmdletBinding()]
    param()

    $script:HybridUserAggregationState.Initialized = $false
    $script:HybridUserAggregationState.Cache.Clear()
    $script:HybridUserAggregationState.LastIdentity = $null
    $script:HybridUserAggregationState.LastError = $null
    return $true
}

Export-ModuleMember -Function @(
    'Initialize-HybridUserAggregationService',
    'Get-HybridUserAggregateProfile',
    'Get-HybridUserAggregationServiceHealth',
    'Clear-HybridUserAggregationService'
)
