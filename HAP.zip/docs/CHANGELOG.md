## v0.8.5 — Active Directory Service Runtime Binding Hotfix

- Aligns launch-page AD status with registered provider health.
- Initializes live AD through the service/provider path instead of leaving it deferred.
- Adds persistent runtime and AD diagnostic logs.
- Fixes strict-mode theme and legacy service locator noise.


## v0.8.2 — Milestone 8.2 Branding & Theme System

- Added Runtime Home Branding & Theme action.
- Added runtime profile theme editor overlay with preview.
- Added profile/organization brand package support.
- Added dynamic window title, color token, logo, icon, and splash path theme model fields.
- Added `New-HybridUiBrandPackage` and `Get-HybridUiBrandingPackagePath`.
- Renamed XAML token application to approved PowerShell verb `Set-HybridUiThemeToXaml`.
- Added Milestone 8.2 branding/theme validation tests.

# Changelog

## v0.8.9 — Live Runtime UX & Vertical Stabilization

- Preserved Active Directory Distinguished Name and Organizational Unit as direct AD provider properties and in the Attributes bag.
- Updated HybridUserService value resolution to read hashtable-backed Attributes values.
- Added service/UI diagnostics for DN/OU object-shape tracing.
- Added a Back/Start button to reopen Runtime Home from the main console.
- Added staged bottom search progress for Search, Base User, Active Directory Details, Microsoft Graph, Exchange Online, Authentication Posture, Aggregation, and Complete.
- Clarified Exchange Online UI state so AD mail attributes are not treated as loaded Exchange mailbox data.
- Added duplicate user search handling with an operator chooser before hydration.
- Added `Infrastructure.ExchangeOnPremises` as a separate provider slice for hybrid local Exchange recipient data.
- Added tests for duplicate-user handling and the on-premises Exchange provider boundary.
- Completed runtime/start-page provider display so enabled providers are rendered dynamically from the selected profile/runtime registry, including Exchange On-Premises.
- Completed Exchange On-Premises mailbox hydration fallback for remote mailbox, forwarding, distribution groups, and aggregation source reporting.
- Replaced the static Bootstrap Preview with a profile-aware Runtime Preview and dynamic Provider Status pre-launch validation on Runtime Home.
- Simplified delegated authentication in the Runtime Profile Wizard to an on/off setting, with delegated client details inherited from app-only settings for compatibility.
- Added lazy live Microsoft Graph runtime registration so Graph Profile and Authentication Posture services receive a provider without authenticating during bootstrap.
- Added Exchange Online tenant-domain passthrough for `Connect-ExchangeOnline -Organization` while preserving tenant ID fallback behavior.


## v0.8.2 - Runtime Platform Hardening

- Aligned root launcher to the runtime/profile WPF entry point.
- Added UI modules for runtime home, profile manager, profile wizard, launch button behavior, dashboard helpers, status bar helpers, and dynamic themes.
- Improved responsive startup layout and action footer behavior for smaller screens and RDP sessions.
- Updated Launch button to wrap full profile names instead of truncating them.
- Added dynamic theme support from runtime profile branding, organization branding, and optional repository theme overrides.
- Normalized runtime hardening version labels to v0.8.2.
- Added cumulative Milestone 8.1 hardening tests.

## v0.8.0

- Completed Milestone 8 Runtime Platform.
- Added Runtime Profile Foundation.
- Added Runtime Bootstrap Engine.
- Added Runtime Provider Modes.
- Added Startup Diagnostics Engine.
- Added Startup Shell and dashboard layout foundation.
- Added Runtime Profile Wizard and improved multi-step UX.
- Added Deployment and Packaging support.
- Added Runtime Profile Manager with discovery, cards, profile operations, launch workflow, and persistent status.
- Maintained no Device Code authentication policy.

## v0.8.2 - Final Brand Polish

- Added the HAP application icon asset and wired it into the Runtime Home, main console header, summary tile, and window icon.
- Refined Runtime Home footer button sizing, selected profile highlighting, dynamic Launch profile labeling, and colorized runtime status values.

## Milestone 8 Final Icon Startup Fix

- Fixed WPF startup failure caused by declaring a PNG file as the `Window.Icon` in XAML.
- Centralized HAP brand asset resolution.
- Uses PNG branding inside the UI and ICO branding for the native window/taskbar icon.

## v0.9C - Workflow Framework and New User Wizard Shell

- Added post-runtime workflow selection so a launched profile can open either User Lookup or New User Wizard.
- Added service-backed New User Wizard shell based on legacy NewUserWizard mappings and validation logic.
- Added validated preview plan for account creation, OU targeting, group assignment, remote mailbox routing, and onboarding notice intent.
- Added confirmed, provider-backed New User creation through the application service after the preview plan is verified.

## Milestone 10 - Device Management Foundation

- Added `Application.DeviceManagementService.psm1` for read-only user device lookup and compliance summary.
- Registered the Device Management application service during runtime bootstrap.
- Added Device Management to the post-launch workflow selector.
- Added a read-only Device Management workflow view for identity lookup, device count, non-compliant device count, stale check-in count, and managed-device details.
- Widened the Device Management workflow panel and shortened provider source labels in the device grid.

## v0.10.x - Identity Platform Completion

- Fixed User Lookup Graph profile parity so the preferred `Get-HybridUserGraphProfile` path preserves licenses, assigned licenses, license assignment states, license diagnostics, PIM roles, directory roles, PIM diagnostics, authentication method details, and richer risk fields.
- Expanded the canonical Graph profile model and Graph profile service to preserve the same richer identity fields.
- Added Milestone 10 identity-platform regression tests to keep license facts inside the User Lookup workflow and prevent a standalone Licensing display workflow from reappearing.
- Expanded Authentication Posture parity so method details, separate sign-in/user risk states, risk level, risk detail records, and Conditional Access details survive service conversion and display inside the existing User Lookup authentication card.
