#region Module Information
# Name: Infrastructure.DirectorySimulator
# Purpose: Deterministic mock directory simulator for service-layer and UI development.
# Exports: New-HybridDirectorySimulator, New-HybridDirectorySimulatorProviders, Get-HybridDirectorySimulatorUser, Search-HybridDirectorySimulatorUser
#endregion

Set-StrictMode -Version Latest

$script:HybridDirectorySimulatorState = @{
    Users = @{}
    Devices = @{}
}

function New-HybridDirectorySimulatorDevice {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Id,
        [Parameter(Mandatory=$true)][string]$Name,
        [Parameter(Mandatory=$true)][string]$PrimaryUser,
        [string]$OperatingSystem = 'Windows 11 Enterprise',
        [string]$ComplianceState = 'Compliant',
        [int]$LastCheckInHoursAgo = 2
    )

    [pscustomobject]@{
        PSTypeName = 'Hybrid.Device'
        Id = $Id
        Name = $Name
        OperatingSystem = $OperatingSystem
        ComplianceState = $ComplianceState
        PrimaryUser = $PrimaryUser
        LastCheckInUtc = ([datetime]::UtcNow.AddHours(-1 * $LastCheckInHoursAgo))
        Source = 'DirectorySimulator.MicrosoftGraph.Devices'
        Attributes = @{ Simulator = $true }
        CreatedUtc = [datetime]::UtcNow
    }
}

function New-HybridSimulatorUser {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$FirstName,
        [Parameter(Mandatory=$true)][string]$LastName,
        [Parameter(Mandatory=$true)][string]$SamAccountName,
        [Parameter(Mandatory=$true)][string]$Department,
        [Parameter(Mandatory=$true)][string]$Title,
        [AllowNull()][string]$ManagerSamAccountName,
        [string[]]$DirectReportSamAccountNames = @(),
        [string[]]$Groups = @(),
        [string]$Office = 'Charleston'
    )

    $displayName = "$FirstName $LastName"
    $managerDn = if ([string]::IsNullOrWhiteSpace($ManagerSamAccountName)) { $null } else { "CN=$ManagerSamAccountName,OU=Users,OU=Atlas,DC=atlas-tech,DC=com" }

    [pscustomobject]@{
        PSTypeName = 'Hybrid.DirectorySimulator.User'
        DisplayName = $displayName
        Name = $displayName
        GivenName = $FirstName
        Surname = $LastName
        SamAccountName = $SamAccountName
        UserPrincipalName = "$SamAccountName@atlas-tech.com"
        Mail = "$SamAccountName@atlas-tech.com"
        Department = $Department
        Title = $Title
        JobTitle = $Title
        Company = 'Atlas'
        Office = $Office
        EmployeeId = ('E{0:00000}' -f ([Math]::Abs($SamAccountName.GetHashCode()) % 99999))
        DistinguishedName = "CN=$displayName,OU=Users,OU=$Department,OU=Atlas,DC=atlas-tech,DC=com"
        Manager = $managerDn
        ManagerSamAccountName = $ManagerSamAccountName
        DirectReportSamAccountNames = @($DirectReportSamAccountNames | Where-Object { $_ -and $_ -ne $SamAccountName })
        Groups = @($Groups | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique)
        Enabled = $true
        LockedOut = $false
        Source = 'DirectorySimulator'
    }
}

function Initialize-HybridDirectorySimulatorRecords {
    $records = @(
        New-HybridSimulatorUser -FirstName 'Robert' -LastName 'Williams' -SamAccountName 'rwilliams' -Department 'Information Technology' -Title 'Director of Infrastructure' -ManagerSamAccountName $null -DirectReportSamAccountNames @('treed') -Groups @('GG-IT-Leadership','GG-Change-Approvers','GG-VPN')
        New-HybridSimulatorUser -FirstName 'Taylor' -LastName 'Reed' -SamAccountName 'treed' -Department 'Information Technology' -Title 'IT Manager' -ManagerSamAccountName 'rwilliams' -DirectReportSamAccountNames @('amorgan','jlee') -Groups @('GG-IT-Managers','GG-RemoteDesktopUsers','GG-LAPS','GG-VPN')
        New-HybridSimulatorUser -FirstName 'Alex' -LastName 'Morgan' -SamAccountName 'amorgan' -Department 'Information Technology' -Title 'Systems Administrator' -ManagerSamAccountName 'treed' -DirectReportSamAccountNames @() -Groups @('Domain Users','GG-IT-Administrators','GG-RemoteDesktopUsers','GG-LAPS','GG-VPN')
        New-HybridSimulatorUser -FirstName 'Jordan' -LastName 'Lee' -SamAccountName 'jlee' -Department 'Operations' -Title 'Operations Analyst' -ManagerSamAccountName 'treed' -DirectReportSamAccountNames @() -Groups @('Domain Users','GG-Operations','GG-ReportReaders','GG-VPN')
    )

    $script:HybridDirectorySimulatorState.Users.Clear()
    foreach ($record in $records) {
        $script:HybridDirectorySimulatorState.Users[$record.SamAccountName.ToLowerInvariant()] = $record
    }

    $script:HybridDirectorySimulatorState.Devices.Clear()
    $script:HybridDirectorySimulatorState.Devices['rwilliams'] = @(
        New-HybridDirectorySimulatorDevice -Id 'sim-device-rwilliams-01' -Name 'SIM-RWILLIAMS-PAW' -PrimaryUser 'rwilliams@atlas-tech.com' -ComplianceState 'Compliant' -LastCheckInHoursAgo 3
    )
    $script:HybridDirectorySimulatorState.Devices['treed'] = @(
        New-HybridDirectorySimulatorDevice -Id 'sim-device-treed-01' -Name 'SIM-TREED-LT01' -PrimaryUser 'treed@atlas-tech.com' -ComplianceState 'Compliant' -LastCheckInHoursAgo 6
        New-HybridDirectorySimulatorDevice -Id 'sim-device-treed-02' -Name 'SIM-TREED-TAB01' -PrimaryUser 'treed@atlas-tech.com' -OperatingSystem 'Windows 11 Enterprise' -ComplianceState 'Unknown' -LastCheckInHoursAgo 36
    )
    $script:HybridDirectorySimulatorState.Devices['amorgan'] = @(
        New-HybridDirectorySimulatorDevice -Id 'sim-device-amorgan-01' -Name 'SIM-AMORGAN-LT01' -PrimaryUser 'amorgan@atlas-tech.com' -ComplianceState 'Compliant' -LastCheckInHoursAgo 2
        New-HybridDirectorySimulatorDevice -Id 'sim-device-amorgan-02' -Name 'SIM-AMORGAN-PAW01' -PrimaryUser 'amorgan@atlas-tech.com' -ComplianceState 'Compliant' -LastCheckInHoursAgo 5
    )
    $script:HybridDirectorySimulatorState.Devices['jlee'] = @(
        New-HybridDirectorySimulatorDevice -Id 'sim-device-jlee-01' -Name 'SIM-JLEE-LT01' -PrimaryUser 'jlee@atlas-tech.com' -ComplianceState 'Compliant' -LastCheckInHoursAgo 8
    )

}

function Resolve-HybridDirectorySimulatorKey {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Query)

    $clean = $Query.Trim().ToLowerInvariant()
    if ($clean -like '*@*') { $clean = ($clean -split '@')[0] }
    $clean = $clean -replace '[^a-z0-9 ]',' '
    $clean = ($clean -replace '\s+',' ').Trim()

    foreach ($key in $script:HybridDirectorySimulatorState.Users.Keys) {
        $user = $script:HybridDirectorySimulatorState.Users[$key]
        $aliases = @(
            $user.SamAccountName.ToLowerInvariant(),
            $user.DisplayName.ToLowerInvariant(),
            $user.UserPrincipalName.ToLowerInvariant(),
            (($user.GivenName + ' ' + $user.Surname).ToLowerInvariant())
        )

        foreach ($alias in $aliases) {
            if ($alias -eq $clean -or $alias -like "*$clean*") { return $key }
        }
    }

    return $null
}

function New-HybridDirectorySimulatorGeneratedUser {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Query)

    $parts = @($Query -split '[\s\._@-]+' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    $textInfo = (Get-Culture).TextInfo
    $first = if ($parts.Count -ge 1) { $textInfo.ToTitleCase($parts[0].ToLowerInvariant()) } else { 'Sample' }
    $last = if ($parts.Count -ge 2) { $textInfo.ToTitleCase($parts[1].ToLowerInvariant()) } else { 'User' }
    $sam = (($first.Substring(0,1) + $last) -replace '[^a-zA-Z0-9]','').ToLowerInvariant()
    if ([string]::IsNullOrWhiteSpace($sam)) { $sam = 'sampleuser' }

    $deptOptions = @('Information Technology','Operations','Finance','Human Resources')
    $titleOptions = @{
        'Information Technology' = 'Systems Specialist'
        'Operations' = 'Operations Coordinator'
        'Finance' = 'Financial Analyst'
        'Human Resources' = 'HR Generalist'
    }
    $department = $deptOptions[[Math]::Abs($sam.GetHashCode()) % $deptOptions.Count]
    $managerSam = if ($sam -eq 'treed') { 'rwilliams' } elseif ($sam -eq 'rwilliams') { $null } else { 'treed' }

    New-HybridSimulatorUser -FirstName $first -LastName $last -SamAccountName $sam -Department $department -Title $titleOptions[$department] -ManagerSamAccountName $managerSam -DirectReportSamAccountNames @() -Groups @('Domain Users',"GG-$($department -replace ' ','')",'GG-VPN')
}

function Get-HybridDirectorySimulatorUser {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Identity)

    if ($script:HybridDirectorySimulatorState.Users.Count -eq 0) { Initialize-HybridDirectorySimulatorRecords }
    $key = Resolve-HybridDirectorySimulatorKey -Query $Identity
    if ($null -ne $key) { return $script:HybridDirectorySimulatorState.Users[$key].PSObject.Copy() }
    return New-HybridDirectorySimulatorGeneratedUser -Query $Identity
}

function Search-HybridDirectorySimulatorUser {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Query)

    @(Get-HybridDirectorySimulatorUser -Identity $Query)
}

function Get-HybridDirectorySimulatorManager {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Identity)

    $user = Get-HybridDirectorySimulatorUser -Identity $Identity
    if ([string]::IsNullOrWhiteSpace($user.ManagerSamAccountName)) { return $null }
    if ($user.ManagerSamAccountName -eq $user.SamAccountName) { return $null }
    return Get-HybridDirectorySimulatorUser -Identity $user.ManagerSamAccountName
}

function Get-HybridDirectorySimulatorGroups {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Identity)

    $user = Get-HybridDirectorySimulatorUser -Identity $Identity
    @($user.Groups | Select-Object -Unique)
}

function Get-HybridDirectorySimulatorDirectReports {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Identity)

    $user = Get-HybridDirectorySimulatorUser -Identity $Identity
    foreach ($reportSam in @($user.DirectReportSamAccountNames)) {
        if ($reportSam -and $reportSam -ne $user.SamAccountName) { Get-HybridDirectorySimulatorUser -Identity $reportSam }
    }
}

function Get-HybridDirectorySimulatorDevices {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Identity)

    if ($script:HybridDirectorySimulatorState.Users.Count -eq 0) { Initialize-HybridDirectorySimulatorRecords }
    $key = Resolve-HybridDirectorySimulatorKey -Query $Identity
    if ($null -ne $key -and $script:HybridDirectorySimulatorState.Devices.ContainsKey($key)) {
        return @($script:HybridDirectorySimulatorState.Devices[$key])
    }

    $user = Get-HybridDirectorySimulatorUser -Identity $Identity
    if ($null -eq $user) { return @() }
    $sam = [string]$user.SamAccountName
    if ([string]::IsNullOrWhiteSpace($sam)) { return @() }
    $hash = [Math]::Abs($sam.GetHashCode())
    if ($hash % 4 -eq 0) { return @() }

    return @(
        New-HybridDirectorySimulatorDevice -Id "sim-device-$sam-01" -Name ("SIM-{0}-LT01" -f $sam.ToUpperInvariant()) -PrimaryUser $user.UserPrincipalName -ComplianceState $(if ($hash % 5 -eq 0) { 'NonCompliant' } else { 'Compliant' }) -LastCheckInHoursAgo (($hash % 96) + 1)
    )
}

function Search-HybridDirectorySimulatorDevices {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Query)

    if ($script:HybridDirectorySimulatorState.Users.Count -eq 0) { Initialize-HybridDirectorySimulatorRecords }
    $needle = $Query.Trim()
    $devices = @()
    foreach ($deviceSet in @($script:HybridDirectorySimulatorState.Devices.Values)) {
        foreach ($device in @($deviceSet)) {
            $name = if ($device.PSObject.Properties.Name -contains 'Name') { [string]$device.Name } elseif ($device.PSObject.Properties.Name -contains 'DisplayName') { [string]$device.DisplayName } else { '' }
            $id = if ($device.PSObject.Properties.Name -contains 'Id') { [string]$device.Id } elseif ($device.PSObject.Properties.Name -contains 'DeviceId') { [string]$device.DeviceId } else { '' }
            $primaryUser = if ($device.PSObject.Properties.Name -contains 'PrimaryUser') { [string]$device.PrimaryUser } elseif ($device.PSObject.Properties.Name -contains 'UserPrincipalName') { [string]$device.UserPrincipalName } else { '' }
            if ($name -like "*$needle*" -or $id -like "*$needle*" -or $primaryUser -like "*$needle*") {
                $devices += $device
            }
        }
    }
    return @($devices)
}

function Get-HybridDirectorySimulatorMailbox {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Identity)

    $user = Get-HybridDirectorySimulatorUser -Identity $Identity
    [pscustomobject]@{
        PSTypeName = 'Hybrid.Mailbox'
        DisplayName = $user.DisplayName
        PrimarySmtpAddress = $user.Mail
        UserPrincipalName = $user.UserPrincipalName
        RecipientTypeDetails = 'UserMailbox'
        ExchangeGuid = ([guid]::NewGuid()).Guid
        HiddenFromAddressListsEnabled = $false
        LitigationHoldEnabled = $false
        DeliverToMailboxAndForward = $false
        ForwardingSmtpAddress = $null
        Source = 'ExchangeOnline'
    }
}

function Get-HybridDirectorySimulatorMailboxStatistics {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Identity)

    $user = Get-HybridDirectorySimulatorUser -Identity $Identity
    [pscustomobject]@{
        PSTypeName = 'Hybrid.MailboxStatistics'
        DisplayName = $user.DisplayName
        TotalItemSize = '1.8 GB'
        ItemCount = 18432
        LastLogonTime = (Get-Date).AddDays(-2)
    }
}

function Get-HybridDirectorySimulatorMailboxDelegations {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Identity)

    $user = Get-HybridDirectorySimulatorUser -Identity $Identity
    @(
        [pscustomobject]@{ Trustee = 'IT Service Desk'; AccessRights = 'FullAccess'; Inherited = $false; Identity = $user.Mail }
        [pscustomobject]@{ Trustee = 'Taylor Reed'; AccessRights = 'SendAs'; Inherited = $false; Identity = $user.Mail }
    )
}

function Get-HybridDirectorySimulatorDistributionGroups {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Identity)

    $user = Get-HybridDirectorySimulatorUser -Identity $Identity
    @(
        "DL-$($user.Department -replace ' ','')-Announcements",
        "DL-$($user.Office)-Staff"
    )
}

function Get-HybridDirectorySimulatorExchangeHealth {
    [CmdletBinding()]
    param()

    [pscustomobject]@{
        PSTypeName = 'Hybrid.ProviderHealth.ExchangeSimulator'
        Initialized = $true
        Available = $true
        Connected = $true
        LastError = $null
        Provider = 'DirectorySimulator.ExchangeOnline'
    }
}


function New-HybridDirectorySimulatorGraphObjectId {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Identity)

    $bytes = [System.Text.Encoding]::UTF8.GetBytes($Identity.ToLowerInvariant())
    $hash = [System.Security.Cryptography.SHA256]::Create().ComputeHash($bytes)
    $guidBytes = New-Object byte[] 16
    [Array]::Copy($hash, 0, $guidBytes, 0, 16)
    return ([guid]::new($guidBytes)).ToString()
}

function Get-HybridDirectorySimulatorGraphProfile {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Identity)

    Initialize-HybridDirectorySimulatorRecords
    $user = Get-HybridDirectorySimulatorUser -Identity $Identity
    if ($null -eq $user) { return $null }

    $sam = [string]$user.SamAccountName
    $upn = [string]$user.UserPrincipalName
    $methods = switch ($sam.ToLowerInvariant()) {
        'amorgan' { @('password','microsoftAuthenticatorPush','softwareOath'); break }
        'jlee' { @('password','sms'); break }
        'treed' { @('password','fido2','microsoftAuthenticatorPush'); break }
        default { @('password') }
    }
    $mfaRegistered = @($methods | Where-Object { $_ -ne 'password' }).Count -gt 0
    $signInOffset = ([Math]::Abs($sam.GetHashCode()) % 5) + 1
    $passwordOffset = ([Math]::Abs($upn.GetHashCode()) % 80) + 14

    [pscustomobject]@{
        PSTypeName = 'Hybrid.DirectorySimulator.GraphProfile'
        ObjectId = New-HybridDirectorySimulatorGraphObjectId -Identity $upn
        Id = New-HybridDirectorySimulatorGraphObjectId -Identity $upn
        SamAccountName = $sam
        DisplayName = [string]$user.DisplayName
        UserPrincipalName = $upn
        UserType = 'Member'
        PreferredLanguage = 'en-US'
        UsageLocation = 'US'
        LastSignInDateTime = ([datetime]::UtcNow.Date.AddDays(-1 * $signInOffset).AddHours(13))
        LastNonInteractiveSignInDateTime = ([datetime]::UtcNow.Date.AddDays(-1 * ($signInOffset + 1)).AddHours(4))
        PasswordLastChangedDateTime = ([datetime]::UtcNow.Date.AddDays(-1 * $passwordOffset).AddHours(9))
        AuthenticationMethods = @($methods)
        MfaRegistered = [bool]$mfaRegistered
        MfaCapable = [bool]$mfaRegistered
        RiskState = 'none'
        Source = 'DirectorySimulator.MicrosoftGraph'
    }
}


function Get-HybridDirectorySimulatorAuthenticationProfile {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Identity)

    $user = Get-HybridDirectorySimulatorUser -Identity $Identity
    $seed = $user.SamAccountName.ToLowerInvariant()
    $hash = [Math]::Abs($seed.GetHashCode())
    $methodSets = @(
        @('password','microsoftAuthenticatorPush','fido2SecurityKey'),
        @('password','microsoftAuthenticatorPush','softwareOath'),
        @('password','sms','voiceMobile'),
        @('password')
    )
    $methods = @($methodSets[$hash % $methodSets.Count])
    $strongMethodCount = @($methods | Where-Object { $_ -ne 'password' -and $_ -ne 'sms' -and $_ -ne 'voiceMobile' }).Count
    $mfaMethodCount = @($methods | Where-Object { $_ -ne 'password' }).Count
    $passwordlessMethodCount = @($methods | Where-Object { $_ -in @('fido2SecurityKey','windowsHelloForBusiness','temporaryAccessPass') }).Count

    [pscustomobject]@{
        PSTypeName = 'Hybrid.AuthenticationProfile'
        UserPrincipalName = $user.UserPrincipalName
        DisplayName = $user.DisplayName
        DefaultMethod = if ($methods.Count -gt 1) { [string]$methods[1] } else { 'password' }
        AuthenticationMethods = @($methods)
        MfaRegistered = [bool]($mfaMethodCount -gt 0)
        MfaCapable = [bool]($mfaMethodCount -gt 0)
        PasswordlessRegistered = [bool]($passwordlessMethodCount -gt 0)
        TemporaryAccessPassEligible = [bool]($hash % 3 -ne 0)
        AuthenticationStrength = if ($strongMethodCount -gt 0) { 'Phishing-resistant capable' } elseif ($mfaMethodCount -gt 0) { 'Multifactor capable' } else { 'Single-factor only' }
        ConditionalAccessState = if ($mfaMethodCount -gt 0) { 'Satisfied' } else { 'Requires registration' }
        SignInRiskState = @('none','low','none','none','medium')[$hash % 5]
        LastMfaRegistrationDateTime = if ($mfaMethodCount -gt 0) { (Get-Date).Date.AddDays(-1 * (($hash % 120) + 3)) } else { $null }
        LastSuccessfulSignInDateTime = (Get-Date).AddHours(-1 * (($hash % 72) + 1))
        PasswordLastChangedDateTime = (Get-Date).Date.AddDays(-1 * (($hash % 90) + 10))
        Source = 'DirectorySimulator.MicrosoftGraph.Authentication'
        RetrievedOn = [datetime]::UtcNow
    }
}

function New-HybridDirectorySimulatorProviders {
    [CmdletBinding()]
    param()

    Initialize-HybridDirectorySimulatorRecords

    $ad = [pscustomobject]@{
        SearchUser = { param([string]$Query) Search-HybridDirectorySimulatorUser -Query $Query }.GetNewClosure()
        GetUser = { param([string]$Identity) Get-HybridDirectorySimulatorUser -Identity $Identity }.GetNewClosure()
        GetManager = { param([string]$Identity) Get-HybridDirectorySimulatorManager -Identity $Identity }.GetNewClosure()
        GetGroups = { param([string]$Identity) Get-HybridDirectorySimulatorGroups -Identity $Identity }.GetNewClosure()
        GetDirectReports = { param([string]$Identity) @(Get-HybridDirectorySimulatorDirectReports -Identity $Identity) }.GetNewClosure()
        GetUserDevices = { param([string]$Identity) @(Get-HybridDirectorySimulatorDevices -Identity $Identity) }.GetNewClosure()
        GetManagedDevices = { param([string]$Identity) @(Get-HybridDirectorySimulatorDevices -Identity $Identity) }.GetNewClosure()
        SearchDevices = { param([string]$Query) @(Search-HybridDirectorySimulatorDevices -Query $Query) }.GetNewClosure()
        GetDevice = { param([string]$Identity) @(Search-HybridDirectorySimulatorDevices -Query $Identity) }.GetNewClosure()
        GetHealth = { [pscustomobject]@{ PSTypeName = 'Hybrid.ProviderHealth.DirectorySimulator'; Initialized = $true; Available = $true; Connected = $true; LastError = $null; Provider = 'DirectorySimulator.ActiveDirectory' } }.GetNewClosure()
    }

    $graph = [pscustomobject]@{
        SearchUser = { param([string]$Query) Search-HybridDirectorySimulatorUser -Query $Query }.GetNewClosure()
        GetUser = { param([string]$Identity) Get-HybridDirectorySimulatorUser -Identity $Identity }.GetNewClosure()
        GetGraphProfile = { param([string]$Identity) Get-HybridDirectorySimulatorGraphProfile -Identity $Identity }.GetNewClosure()
        GetUserGraphProfile = { param([string]$Identity) Get-HybridDirectorySimulatorGraphProfile -Identity $Identity }.GetNewClosure()
        GetAuthenticationProfile = { param([string]$Identity) Get-HybridDirectorySimulatorAuthenticationProfile -Identity $Identity }.GetNewClosure()
        GetUserAuthenticationProfile = { param([string]$Identity) Get-HybridDirectorySimulatorAuthenticationProfile -Identity $Identity }.GetNewClosure()
        GetGraphAuthenticationProfile = { param([string]$Identity) Get-HybridDirectorySimulatorAuthenticationProfile -Identity $Identity }.GetNewClosure()
        GetUserDevices = { param([string]$Identity) @(Get-HybridDirectorySimulatorDevices -Identity $Identity) }.GetNewClosure()
        GetManagedDevices = { param([string]$Identity) @(Get-HybridDirectorySimulatorDevices -Identity $Identity) }.GetNewClosure()
        GetIntuneDevices = { param([string]$Identity) @(Get-HybridDirectorySimulatorDevices -Identity $Identity) }.GetNewClosure()
        SearchDevices = { param([string]$Query) @(Search-HybridDirectorySimulatorDevices -Query $Query) }.GetNewClosure()
        GetDevice = { param([string]$Identity) @(Search-HybridDirectorySimulatorDevices -Query $Identity) }.GetNewClosure()
        GetHealth = { [pscustomobject]@{ PSTypeName = 'Hybrid.ProviderHealth.DirectorySimulator'; Initialized = $true; Available = $true; Connected = $true; LastError = $null; Provider = 'DirectorySimulator.MicrosoftGraph' } }.GetNewClosure()
    }

    $exchange = [pscustomobject]@{
        GetMailbox = { param([string]$Identity) Get-HybridDirectorySimulatorMailbox -Identity $Identity }.GetNewClosure()
        GetMailboxStatistics = { param([string]$Identity) Get-HybridDirectorySimulatorMailboxStatistics -Identity $Identity }.GetNewClosure()
        GetMailboxDelegations = { param([string]$Identity) @(Get-HybridDirectorySimulatorMailboxDelegations -Identity $Identity) }.GetNewClosure()
        GetDistributionGroups = { param([string]$Identity) @(Get-HybridDirectorySimulatorDistributionGroups -Identity $Identity) }.GetNewClosure()
        GetMailboxForwarding = { param([string]$Identity) $mailbox = Get-HybridDirectorySimulatorMailbox -Identity $Identity; [pscustomobject]@{ ForwardingSmtpAddress = $mailbox.ForwardingSmtpAddress; DeliverToMailboxAndForward = $mailbox.DeliverToMailboxAndForward } }.GetNewClosure()
        GetHealth = { Get-HybridDirectorySimulatorExchangeHealth }.GetNewClosure()
    }

    [pscustomobject]@{
        PSTypeName = 'Hybrid.DirectorySimulator.Providers'
        ActiveDirectory = $ad
        MicrosoftGraph = $graph
        ExchangeOnline = $exchange
    }
}

function New-HybridDirectorySimulator {
    [CmdletBinding()]
    param()

    Initialize-HybridDirectorySimulatorRecords
    [pscustomobject]@{
        PSTypeName = 'Hybrid.DirectorySimulator'
        Users = $script:HybridDirectorySimulatorState.Users
        Providers = (New-HybridDirectorySimulatorProviders)
    }
}

Export-ModuleMember -Function @(
    'New-HybridDirectorySimulator',
    'New-HybridDirectorySimulatorProviders',
    'Get-HybridDirectorySimulatorGraphProfile',
    'Get-HybridDirectorySimulatorUser',
    'Search-HybridDirectorySimulatorUser',
    'Get-HybridDirectorySimulatorManager',
    'Get-HybridDirectorySimulatorGroups',
    'Get-HybridDirectorySimulatorDirectReports',
    'Get-HybridDirectorySimulatorDevices',
    'Search-HybridDirectorySimulatorDevices',
    'Get-HybridDirectorySimulatorMailbox',
    'Get-HybridDirectorySimulatorMailboxStatistics',
    'Get-HybridDirectorySimulatorMailboxDelegations',
    'Get-HybridDirectorySimulatorDistributionGroups',
    'Get-HybridDirectorySimulatorExchangeHealth',
    'Get-HybridDirectorySimulatorAuthenticationProfile'
)
