#region Module Information
# Name: Application.HybridUserService
# Purpose: Vertical-slice service layer for unified Hybrid.User search and enriched user details.
# Dependencies: Provider services supplied by caller.
# Exports: Initialize-HybridUserService, Search-HybridUser, Get-HybridUser, Get-HybridUserDetails, Get-HybridUserMailboxDetails, Get-HybridUserServiceHealth, Clear-HybridUserService
#endregion

Set-StrictMode -Version Latest

$script:HybridUserServiceState = @{
    Initialized      = $false
    ActiveDirectory  = $null
    MicrosoftGraph   = $null
    ExchangeOnline   = $null
    ExchangeOnPremises = $null
    Cache            = @{}
    DetailCache      = @{}
    MailboxCache     = @{}
    LastQuery        = $null
    LastResult       = $null
    LastError        = $null
}

function Write-HybridUserHydrationDiagnostic {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Stage,
        [Parameter(Mandatory=$true)][string]$Message,
        [ValidateSet('INFO','WARN','ERROR','SUCCESS')][string]$Level = 'INFO',
        [AllowNull()][object]$Data = $null
    )

    try {
        $moduleRoot = Split-Path -Parent $PSScriptRoot
        $repoRoot = Split-Path -Parent $moduleRoot
        $logRoot = Join-Path $repoRoot 'logs'
        if (-not (Test-Path -LiteralPath $logRoot)) { New-Item -Path $logRoot -ItemType Directory -Force | Out-Null }
        $logPath = Join-Path $logRoot 'hydration-diagnostics.log'
        $line = '[{0:u}] [{1}] [Application.HybridUserService:{2}] {3}' -f ([datetime]::UtcNow), $Level, $Stage, $Message
        Add-Content -LiteralPath $logPath -Value $line -Encoding UTF8
        if ($null -ne $Data) {
            Add-Content -LiteralPath $logPath -Value ('    Data: ' + ($Data | ConvertTo-Json -Depth 6 -Compress)) -Encoding UTF8
        }
    }
    catch { }
}

function Get-HybridObjectValue {
    [CmdletBinding()]
    param(
        [AllowNull()][object]$InputObject,
        [Parameter(Mandatory=$true)][string[]]$Names,
        [AllowNull()][object]$Default = $null
    )

    foreach ($name in $Names) {
        if ($null -eq $InputObject) { continue }

        if ($InputObject -is [System.Collections.IDictionary] -and $InputObject.Contains($name)) {
            $value = $InputObject[$name]
            if ($null -eq $value) { continue }
            if ($value -is [string] -and [string]::IsNullOrWhiteSpace($value)) { continue }
            if ($value -is [System.Collections.IEnumerable] -and $value -isnot [string]) {
                if (@($value).Count -eq 0) { continue }
                return $value
            }
            if (-not [string]::IsNullOrWhiteSpace([string]$value)) {
                return $value
            }
        }

        if ($InputObject.PSObject.Properties.Name -contains $name) {
            $value = $InputObject.$name
            if ($null -eq $value) { continue }
            if ($value -is [string] -and [string]::IsNullOrWhiteSpace($value)) { continue }
            if ($value -is [System.Collections.IEnumerable] -and $value -isnot [string]) {
                if (@($value).Count -eq 0) { continue }
                return $value
            }
            if (-not [string]::IsNullOrWhiteSpace([string]$value)) {
                return $value
            }
        }
    }

    return $Default
}


function Get-HybridCollectionCount {
    [CmdletBinding()]
    param([AllowNull()][object]$Value)

    if ($null -eq $Value) { return 0 }
    if ($Value -is [string]) {
        if ([string]::IsNullOrWhiteSpace($Value)) { return 0 }
        return 1
    }
    try {
        if ($Value.PSObject.Properties.Name -contains 'Count') {
            $countValue = $Value.Count
            if ($null -ne $countValue) { return [int]$countValue }
        }
    }
    catch { }
    try { return @($Value).Count } catch { return 1 }
}

function Test-HybridExchangeMailboxObject {
    [CmdletBinding()]
    param([AllowNull()][object]$Mailbox)

    if ($null -eq $Mailbox) { return $false }
    $primary = [string](Get-HybridObjectValue -InputObject $Mailbox -Names @('PrimarySmtpAddress','WindowsEmailAddress','UserPrincipalName','Mail','EmailAddress') -Default '')
    $recipientType = [string](Get-HybridObjectValue -InputObject $Mailbox -Names @('RecipientTypeDetails','RecipientType','MailboxType') -Default '')
    $externalId = [string](Get-HybridObjectValue -InputObject $Mailbox -Names @('ExternalDirectoryObjectId','ExchangeGuid','Guid','MailboxGuid') -Default '')

    if (-not [string]::IsNullOrWhiteSpace($recipientType) -and $recipientType -match 'Mailbox|MailUser|RemoteUserMailbox|UserMailbox|SharedMailbox|RoomMailbox|EquipmentMailbox') { return $true }
    if (-not [string]::IsNullOrWhiteSpace($primary) -and $primary -match '@') { return $true }
    if (-not [string]::IsNullOrWhiteSpace($externalId) -and $externalId -notmatch '^(0{8}-0{4}-0{4}-0{4}-0{12})$') { return $true }
    return $false
}

function Get-HybridActiveDirectoryStableIdentity {
    [CmdletBinding()]
    param(
        [AllowNull()][object]$User,
        [AllowNull()][object]$ActiveDirectoryUser
    )

    $candidateSources = @($ActiveDirectoryUser, $User)

    foreach ($source in $candidateSources) {
        $candidate = Get-HybridObjectValue -InputObject $source -Names @('DistinguishedName','DN') -Default $null
        if (-not [string]::IsNullOrWhiteSpace([string]$candidate)) { return [string]$candidate }

        $attributes = Get-HybridObjectValue -InputObject $source -Names @('Attributes') -Default $null
        $candidate = Get-HybridObjectValue -InputObject $attributes -Names @('DistinguishedName','DN') -Default $null
        if (-not [string]::IsNullOrWhiteSpace([string]$candidate)) { return [string]$candidate }

        $candidate = Get-HybridObjectValue -InputObject $source -Names @('ObjectGuid','ObjectGUID','Guid','Id') -Default $null
        if (-not [string]::IsNullOrWhiteSpace([string]$candidate)) { return [string]$candidate }

        $candidate = Get-HybridObjectValue -InputObject $attributes -Names @('ObjectGuid','ObjectGUID','Guid') -Default $null
        if (-not [string]::IsNullOrWhiteSpace([string]$candidate)) { return [string]$candidate }

        $candidate = Get-HybridObjectValue -InputObject $source -Names @('ObjectSid','SID','Sid') -Default $null
        if (-not [string]::IsNullOrWhiteSpace([string]$candidate)) { return [string]$candidate }

        $candidate = Get-HybridObjectValue -InputObject $attributes -Names @('ObjectSid','SID','Sid') -Default $null
        if (-not [string]::IsNullOrWhiteSpace([string]$candidate)) { return [string]$candidate }

        $candidate = Get-HybridObjectValue -InputObject $source -Names @('SamAccountName','SAMAccountName','sAMAccountName') -Default $null
        if (-not [string]::IsNullOrWhiteSpace([string]$candidate)) { return [string]$candidate }

        $candidate = Get-HybridObjectValue -InputObject $attributes -Names @('SamAccountName','SAMAccountName','sAMAccountName') -Default $null
        if (-not [string]::IsNullOrWhiteSpace([string]$candidate)) { return [string]$candidate }
    }

    $fallback = Get-HybridObjectValue -InputObject $User -Names @('UserPrincipalName','Identity','Mail') -Default $null
    if (-not [string]::IsNullOrWhiteSpace([string]$fallback)) { return [string]$fallback }

    return ''
}

function Add-HybridUniqueIdentityCandidate {
    param(
        [System.Collections.Generic.List[string]]$Candidates,
        [AllowNull()][object]$Value
    )

    if ($null -eq $Value) { return }
    $candidate = [string]$Value
    if ([string]::IsNullOrWhiteSpace($candidate)) { return }
    $candidate = $candidate.Trim()
    if ($candidate -match '^CN=|^OU=|^DC=') { return }
    foreach ($existing in @($Candidates)) {
        if ([string]::Equals($existing, $candidate, [System.StringComparison]::OrdinalIgnoreCase)) { return }
    }
    [void]$Candidates.Add($candidate)
}

function Get-HybridGraphIdentityCandidates {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Identity,
        [AllowNull()][object]$ActiveDirectoryUser = $null,
        [AllowNull()][object]$GraphUser = $null
    )

    $candidates = [System.Collections.Generic.List[string]]::new()
    Add-HybridUniqueIdentityCandidate -Candidates $candidates -Value $Identity

    foreach ($source in @($ActiveDirectoryUser, $GraphUser)) {
        foreach ($propertyName in @(
            'UserPrincipalName','UPN','Mail','EmailAddress',
            'AzureAdObjectId','AzureADObjectId','ExternalDirectoryObjectId','GraphObjectId','ObjectId',
            'SamAccountName','SAMAccountName','sAMAccountName','OnPremisesSamAccountName','MailNickname','Alias'
        )) {
            Add-HybridUniqueIdentityCandidate -Candidates $candidates -Value (Get-HybridObjectValue -InputObject $source -Names @($propertyName) -Default $null)
        }

        $attributes = Get-HybridObjectValue -InputObject $source -Names @('Attributes') -Default $null
        foreach ($propertyName in @(
            'UserPrincipalName','UPN','Mail','EmailAddress',
            'AzureAdObjectId','AzureADObjectId','ExternalDirectoryObjectId','GraphObjectId','ObjectId',
            'SamAccountName','SAMAccountName','sAMAccountName','OnPremisesSamAccountName','MailNickname','Alias'
        )) {
            Add-HybridUniqueIdentityCandidate -Candidates $candidates -Value (Get-HybridObjectValue -InputObject $attributes -Names @($propertyName) -Default $null)
        }
    }

    return @($candidates.ToArray())
}

function Invoke-HybridGraphUserProviderLookup {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Identity,
        [Parameter(Mandatory=$true)][string[]]$OperationNames,
        [AllowNull()][object]$ActiveDirectoryUser = $null
    )

    if ($null -eq $script:HybridUserServiceState.MicrosoftGraph) { return @() }

    $adUser = $ActiveDirectoryUser
    if ($null -eq $adUser -and $null -ne $script:HybridUserServiceState.ActiveDirectory) {
        $adUser = @(Invoke-HybridServiceOperationSafe -Service $script:HybridUserServiceState.ActiveDirectory -OperationNames @('GetUser','GetADUser','Get') -Arguments @($Identity) -ProviderName 'ActiveDirectory' | Select-Object -First 1)
        if ((Get-HybridCollectionCount $adUser) -gt 0) { $adUser = $adUser[0] } else { $adUser = $null }
    }

    foreach ($candidate in (Get-HybridGraphIdentityCandidates -Identity $Identity -ActiveDirectoryUser $adUser)) {
        $result = @(Invoke-HybridServiceOperationSafe -Service $script:HybridUserServiceState.MicrosoftGraph -OperationNames $OperationNames -Arguments @($candidate) -ProviderName 'MicrosoftGraph' | Select-Object -First 1)
        if ((Get-HybridCollectionCount $result) -gt 0 -and $null -ne $result[0]) {
            if (-not [string]::Equals($candidate, $Identity, [System.StringComparison]::OrdinalIgnoreCase)) {
                Write-HybridUserHydrationDiagnostic -Stage 'MicrosoftGraph' -Message "Resolved Graph identity '$Identity' using AD-derived candidate '$candidate'." -Level SUCCESS
            }
            return @($result[0])
        }
    }

    return @()
}

function Add-HybridUserActiveDirectoryIdentityMetadata {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][object]$User,
        [AllowNull()][object]$ActiveDirectoryUser
    )

    $stableIdentity = Get-HybridActiveDirectoryStableIdentity -User $User -ActiveDirectoryUser $ActiveDirectoryUser
    $distinguishedName = [string](Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('DistinguishedName','DN') -Default (Get-HybridObjectValue -InputObject $User -Names @('DistinguishedName','DN') -Default ''))
    $samAccountName = [string](Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('SamAccountName','SAMAccountName','sAMAccountName') -Default (Get-HybridObjectValue -InputObject $User -Names @('SamAccountName','SAMAccountName','sAMAccountName') -Default ''))

    if ($User.PSObject.Properties.Name -notcontains 'ActiveDirectoryIdentity') {
        Add-Member -InputObject $User -NotePropertyName ActiveDirectoryIdentity -NotePropertyValue $stableIdentity
    }
    else {
        $User.ActiveDirectoryIdentity = $stableIdentity
    }

    if ($User.PSObject.Properties.Name -notcontains 'ActiveDirectoryDistinguishedName') {
        Add-Member -InputObject $User -NotePropertyName ActiveDirectoryDistinguishedName -NotePropertyValue $distinguishedName
    }
    else {
        $User.ActiveDirectoryDistinguishedName = $distinguishedName
    }

    if ($User.PSObject.Properties.Name -notcontains 'ActiveDirectorySamAccountName') {
        Add-Member -InputObject $User -NotePropertyName ActiveDirectorySamAccountName -NotePropertyValue $samAccountName
    }
    else {
        $User.ActiveDirectorySamAccountName = $samAccountName
    }

    return $User
}


function Invoke-HybridServiceOperation {
    [CmdletBinding()]
    param(
        [AllowNull()][object]$Service,
        [Parameter(Mandatory=$true)][string[]]$OperationNames,
        [object[]]$Arguments = @()
    )

    if ($null -eq $Service) {
        Write-HybridUserHydrationDiagnostic -Stage 'ProviderOperation' -Message 'Skipped provider operation because service was null.' -Level WARN -Data ([pscustomobject]@{
            OperationNames = $OperationNames
        })
        return @()
    }

    foreach ($operationName in $OperationNames) {
        if ($Service.PSObject.Properties.Name -contains $operationName) {
            $operation = $Service.$operationName
            if ($operation -is [scriptblock]) {
                try {
                    Write-HybridUserHydrationDiagnostic -Stage 'ProviderOperation' -Message "Invoking $operationName."
                    $result = @(& $operation @Arguments)
                    Write-HybridUserHydrationDiagnostic -Stage 'ProviderOperation' -Message "Completed $operationName. Returned $($result.Count) item(s)." -Level SUCCESS
                    return @($result)
                }
                catch {
                    Write-HybridUserHydrationDiagnostic -Stage 'ProviderOperation' -Message "Failed $operationName - $($_.Exception.Message)" -Level ERROR -Data ([pscustomobject]@{
                        Operation = $operationName
                        Arguments = @($Arguments)
                        ExceptionType = $_.Exception.GetType().FullName
                        FullyQualifiedErrorId = $_.FullyQualifiedErrorId
                        ScriptStackTrace = $_.ScriptStackTrace
                    })
                    throw
                }
            }
            if ($null -ne $operation -and $operation.PSObject.Methods.Name -contains 'Invoke') {
                try {
                    Write-HybridUserHydrationDiagnostic -Stage 'ProviderOperation' -Message "Invoking $operationName."
                    $result = @($operation.Invoke($Arguments))
                    Write-HybridUserHydrationDiagnostic -Stage 'ProviderOperation' -Message "Completed $operationName. Returned $($result.Count) item(s)." -Level SUCCESS
                    return @($result)
                }
                catch {
                    Write-HybridUserHydrationDiagnostic -Stage 'ProviderOperation' -Message "Failed $operationName - $($_.Exception.Message)" -Level ERROR -Data ([pscustomobject]@{
                        Operation = $operationName
                        Arguments = @($Arguments)
                        ExceptionType = $_.Exception.GetType().FullName
                        FullyQualifiedErrorId = $_.FullyQualifiedErrorId
                        ScriptStackTrace = $_.ScriptStackTrace
                    })
                    throw
                }
            }
        }
    }

    Write-HybridUserHydrationDiagnostic -Stage 'ProviderOperation' -Message 'No matching provider operation found.' -Level WARN -Data ([pscustomobject]@{
        RequestedOperations = $OperationNames
        ServiceTypeNames = @($Service.PSObject.TypeNames)
        ServiceProperties = @($Service.PSObject.Properties.Name)
    })
    return @()
}

function Invoke-HybridServiceOperationSafe {
    [CmdletBinding()]
    param(
        [AllowNull()][object]$Service,
        [Parameter(Mandatory=$true)][string[]]$OperationNames,
        [object[]]$Arguments = @(),
        [string]$ProviderName = 'Provider'
    )

    try {
        return @(Invoke-HybridServiceOperation -Service $Service -OperationNames $OperationNames -Arguments $Arguments)
    }
    catch {
        Write-HybridUserHydrationDiagnostic -Stage 'ProviderOperation' -Message "$ProviderName provider operation skipped after failure - $($_.Exception.Message)" -Level WARN -Data ([pscustomobject]@{
            Provider = $ProviderName
            OperationNames = @($OperationNames)
            Arguments = @($Arguments)
            ExceptionType = $_.Exception.GetType().FullName
            FullyQualifiedErrorId = $_.FullyQualifiedErrorId
        })
        return @()
    }
}

function Get-HybridProviderHealthSnapshot {
    [CmdletBinding()]
    param([AllowNull()][object]$Service)

    $health = @(Invoke-HybridServiceOperation -Service $Service -OperationNames @('GetHealth','GetProviderHealth') -Arguments @() | Select-Object -First 1)
    if ((Get-HybridCollectionCount $health) -gt 0) { return $health[0] }

    if ($null -eq $Service) {
        return [pscustomobject]@{
            PSTypeName = 'Hybrid.ProviderHealth.ApplicationSnapshot'
            Initialized = $false
            Available = $false
            Connected = $false
            LastError = $null
        }
    }

    return [pscustomobject]@{
        PSTypeName = 'Hybrid.ProviderHealth.ApplicationSnapshot'
        Initialized = $true
        Available = [bool](Get-HybridObjectValue -InputObject $Service -Names @('ProviderAvailable','Available') -Default $true)
        Connected = [bool](Get-HybridObjectValue -InputObject $Service -Names @('ProviderConnected','Connected','ProviderAvailable','Available') -Default $true)
        LastError = Get-HybridObjectValue -InputObject $Service -Names @('LastError','Error','ErrorMessage') -Default $null
    }
}

function ConvertTo-HybridSourceStatus {
    [CmdletBinding()]
    param(
        [string]$Name,
        [AllowNull()][object]$Object,
        [AllowNull()][object]$ProviderHealth
    )

    $available = ($null -ne $Object)
    $connected = $available
    $lastError = $null

    if ($null -ne $ProviderHealth) {
        $available = [bool](Get-HybridObjectValue -InputObject $ProviderHealth -Names @('Available','ProviderAvailable','Initialized') -Default $available)
        $connected = [bool](Get-HybridObjectValue -InputObject $ProviderHealth -Names @('Connected','ProviderConnected','Available') -Default $available)
        $lastError = Get-HybridObjectValue -InputObject $ProviderHealth -Names @('LastError','Error','ErrorMessage') -Default $null
    }

    [pscustomobject]@{
        PSTypeName = 'Hybrid.UserSourceStatus'
        Name       = $Name
        Available  = $available
        Connected  = $connected
        LastError  = $lastError
        Object     = $Object
        Health     = $ProviderHealth
    }
}

function New-HybridAdMailAttributeSnapshot {
    [CmdletBinding()]
    param([AllowNull()][object]$User)

    [pscustomobject]@{
        PSTypeName = 'Hybrid.AdMailAttributes'
        Mail = Get-HybridObjectValue -InputObject $User -Names @('Mail','EmailAddress') -Default $null
        ProxyAddresses = @((Get-HybridObjectValue -InputObject $User -Names @('ProxyAddresses','EmailAddresses') -Default @()))
        TargetAddress = Get-HybridObjectValue -InputObject $User -Names @('TargetAddress') -Default $null
        MailNickname = Get-HybridObjectValue -InputObject $User -Names @('MailNickname','Alias') -Default $null
        Source = 'ActiveDirectory'
    }
}

function Test-HybridAdMailAttributeSnapshotHasMailSignal {
    [CmdletBinding()]
    param([AllowNull()][object]$Snapshot)

    if ($null -eq $Snapshot) { return $false }

    # Do not treat MailNickname/Alias as mailbox proof. ADM/admin accounts may have
    # alias-like values but no mailbox. Require SMTP-bearing attributes before any
    # Exchange mailbox lookup to avoid long Exchange Online timeout/hang behavior.
    foreach ($name in @('Mail','TargetAddress')) {
        $value = [string](Get-HybridObjectValue -InputObject $Snapshot -Names @($name) -Default '')
        if ($value -match '@') { return $true }
    }

    $proxyAddresses = @(Get-HybridObjectValue -InputObject $Snapshot -Names @('ProxyAddresses') -Default @())
    return (@($proxyAddresses | Where-Object { [string]$_ -match '^(?i:smtp):' -or [string]$_ -match '@' }).Count -gt 0)
}

function New-HybridMailboxSourceEnvelope {
    [CmdletBinding()]
    param(
        [AllowNull()][object]$AdMailAttributes,
        [AllowNull()][object]$ExchangeOnPremises,
        [AllowNull()][object]$ExchangeOnline
    )

    $sourcePriority = 'ActiveDirectory'
    $primary = [string](Get-HybridObjectValue -InputObject $AdMailAttributes -Names @('Mail') -Default '')
    $recipientType = ''

    if ($null -ne $ExchangeOnline) {
        $sourcePriority = 'ExchangeOnline'
        $primary = [string](Get-HybridObjectValue -InputObject $ExchangeOnline -Names @('PrimarySmtpAddress','Mail','EmailAddress') -Default $primary)
        $recipientType = [string](Get-HybridObjectValue -InputObject $ExchangeOnline -Names @('RecipientTypeDetails','RecipientType','MailboxType') -Default '')
    }
    elseif ($null -ne $ExchangeOnPremises) {
        $sourcePriority = 'ExchangeOnPremises'
        $primary = [string](Get-HybridObjectValue -InputObject $ExchangeOnPremises -Names @('PrimarySmtpAddress','WindowsEmailAddress','Mail','EmailAddress') -Default $primary)
        $recipientType = [string](Get-HybridObjectValue -InputObject $ExchangeOnPremises -Names @('RecipientTypeDetails','RecipientType','Type') -Default '')
    }

    [pscustomobject]@{
        PSTypeName = 'Hybrid.UserMailboxSources'
        AdMailAttributes = $AdMailAttributes
        ExchangeOnPremises = $ExchangeOnPremises
        ExchangeOnline = $ExchangeOnline
        Summary = [pscustomobject]@{
            PSTypeName = 'Hybrid.UserMailboxSummary'
            HasExchangeData = ($null -ne $ExchangeOnPremises -or $null -ne $ExchangeOnline)
            PrimarySmtpAddress = $primary
            RecipientType = $recipientType
            SourcePriority = $sourcePriority
        }
    }
}

function ConvertTo-HybridUserOrganizationalUnit {
    [CmdletBinding()]
    param([AllowNull()][string]$DistinguishedName)

    if ([string]::IsNullOrWhiteSpace($DistinguishedName)) { return '' }

    $ouParts = @($DistinguishedName -split ',' | Where-Object { $_ -like 'OU=*' } | ForEach-Object { $_.Substring(3) })
    if ((Get-HybridCollectionCount $ouParts) -eq 0) { return '' }

    [array]::Reverse($ouParts)
    return ($ouParts -join ' / ')
}

function ConvertTo-HybridDisplayNameFromDn {
    [CmdletBinding()]
    param([AllowNull()][string]$DistinguishedName)

    if ([string]::IsNullOrWhiteSpace($DistinguishedName)) { return '' }
    $firstPart = ($DistinguishedName -split ',' | Select-Object -First 1)
    if ($firstPart -like 'CN=*') { return $firstPart.Substring(3) }
    return $DistinguishedName
}

function New-HybridCompositeUser {
    [CmdletBinding()]
    param(
        [string]$Identity,
        [AllowNull()][object]$ActiveDirectoryUser,
        [AllowNull()][object]$GraphUser,
        [AllowNull()][object]$Mailbox,
        [AllowNull()][object]$ActiveDirectoryHealth,
        [AllowNull()][object]$GraphHealth,
        [AllowNull()][object]$ExchangeHealth,
        [AllowNull()][object]$ExchangeOnPremisesHealth
    )

    $displayName = Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('DisplayName','Name') -Default $null
    if ($null -eq $displayName) {
        $displayName = Get-HybridObjectValue -InputObject $GraphUser -Names @('DisplayName','Name') -Default $Identity
    }

    $upn = Get-HybridObjectValue -InputObject $GraphUser -Names @('UserPrincipalName','UPN') -Default $null
    if ($null -eq $upn) {
        $upn = Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('UserPrincipalName','UPN') -Default $Identity
    }

    $mail = Get-HybridObjectValue -InputObject $Mailbox -Names @('PrimarySmtpAddress','Mail','EmailAddress') -Default $null
    if ($null -eq $mail) { $mail = Get-HybridObjectValue -InputObject $GraphUser -Names @('Mail','EmailAddress') -Default $null }
    if ($null -eq $mail) { $mail = Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('Mail','EmailAddress') -Default $null }

    $distinguishedName = [string](Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('DistinguishedName','DN') -Default '')
    if ([string]::IsNullOrWhiteSpace($distinguishedName)) {
        $activeDirectoryAttributes = Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('Attributes') -Default $null
        $distinguishedName = [string](Get-HybridObjectValue -InputObject $activeDirectoryAttributes -Names @('DistinguishedName','DN') -Default '')
    }
    $manager = Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('Manager') -Default $null

    $user = [pscustomobject]@{
        PSTypeName            = 'Hybrid.User'
        Identity              = $Identity
        DisplayName           = [string]$displayName
        UserPrincipalName     = [string]$upn
        SamAccountName        = [string](Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('SamAccountName','SAMAccountName') -Default '')
        Mail                  = [string]$mail
        Department            = [string](Get-HybridObjectValue -InputObject $GraphUser -Names @('Department') -Default (Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('Department') -Default ''))
        Title                 = [string](Get-HybridObjectValue -InputObject $GraphUser -Names @('JobTitle','Title') -Default (Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('Title') -Default ''))
        Company               = [string](Get-HybridObjectValue -InputObject $GraphUser -Names @('CompanyName','Company') -Default (Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('Company','CompanyName') -Default ''))
        Office                = [string](Get-HybridObjectValue -InputObject $GraphUser -Names @('OfficeLocation','Office') -Default (Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('Office','PhysicalDeliveryOfficeName','OfficeLocation') -Default ''))
        EmployeeId            = [string](Get-HybridObjectValue -InputObject $GraphUser -Names @('EmployeeId','EmployeeID') -Default (Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('EmployeeId','EmployeeID') -Default ''))
        BadgeId               = [string](Get-HybridObjectValue -InputObject $GraphUser -Names @('BadgeId','BadgeID','EmployeeNumber','employeeNumber','extensionAttribute1') -Default (Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('BadgeId','BadgeID','EmployeeNumber','employeeNumber','extensionAttribute1') -Default ''))
        State                 = [string](Get-HybridObjectValue -InputObject $GraphUser -Names @('State','state') -Default (Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('State','st','StateOrProvince') -Default (Get-HybridObjectValue -InputObject (Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('Attributes') -Default $null) -Names @('State','st') -Default '')))
        PhoneNumber           = [string](Get-HybridObjectValue -InputObject $GraphUser -Names @('PhoneNumber','TelephoneNumber','OfficePhone') -Default (Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('PhoneNumber','TelephoneNumber','telephoneNumber','OfficePhone') -Default (Get-HybridObjectValue -InputObject (Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('Attributes') -Default $null) -Names @('PhoneNumber','TelephoneNumber','telephoneNumber') -Default '')))
        MobilePhone           = [string](Get-HybridObjectValue -InputObject $GraphUser -Names @('MobilePhone','mobilePhone') -Default (Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('MobilePhone','mobile') -Default (Get-HybridObjectValue -InputObject (Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('Attributes') -Default $null) -Names @('MobilePhone','mobile') -Default '')))
        Manager               = $manager
        ManagerDisplayName    = ConvertTo-HybridDisplayNameFromDn -DistinguishedName ([string]$manager)
        DistinguishedName     = $distinguishedName
        ActiveDirectoryIdentity = Get-HybridActiveDirectoryStableIdentity -User $null -ActiveDirectoryUser $ActiveDirectoryUser
        ActiveDirectoryDistinguishedName = $distinguishedName
        ActiveDirectorySamAccountName = [string](Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('SamAccountName','SAMAccountName','sAMAccountName') -Default '')
        OrganizationalUnit    = ConvertTo-HybridUserOrganizationalUnit -DistinguishedName $distinguishedName
        Enabled               = Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('Enabled','AccountEnabled') -Default $null
        LockedOut             = Get-HybridObjectValue -InputObject $ActiveDirectoryUser -Names @('LockedOut','IsLockedOut') -Default $null
        Groups                = @()
        DirectReports         = @()
        Devices               = @()
        Licenses              = @(Get-HybridObjectValue -InputObject $GraphUser -Names @('Licenses','AssignedLicenses') -Default @())
        AssignedLicenses      = @(Get-HybridObjectValue -InputObject $GraphUser -Names @('AssignedLicenses','assignedLicenses','Licenses') -Default @())
        LicenseAssignmentStates = @(Get-HybridObjectValue -InputObject $GraphUser -Names @('LicenseAssignmentStates','licenseAssignmentStates') -Default @())
        LicenseDiagnostic     = [string](Get-HybridObjectValue -InputObject $GraphUser -Names @('LicenseDiagnostic','LicenseDiagnostics') -Default '')
        LicenseDiagnostics    = [string](Get-HybridObjectValue -InputObject $GraphUser -Names @('LicenseDiagnostic','LicenseDiagnostics') -Default '')
        PimRoles              = @(Get-HybridObjectValue -InputObject $GraphUser -Names @('PimRoles','PIMRoles','PrivilegedIdentityRoles','DirectoryRoles','AzureRoles') -Default @())
        DirectoryRoles        = @(Get-HybridObjectValue -InputObject $GraphUser -Names @('DirectoryRoles','AzureRoles','PimRoles','PIMRoles') -Default @())
        PimRoleDiagnostic     = [string](Get-HybridObjectValue -InputObject $GraphUser -Names @('PimRoleDiagnostic','PimRoleDiagnostics','PimDiagnostics','RoleDiagnostic','RoleDiagnostics') -Default '')
        PimRoleDiagnostics    = [string](Get-HybridObjectValue -InputObject $GraphUser -Names @('PimRoleDiagnostic','PimRoleDiagnostics','PimDiagnostics','RoleDiagnostic','RoleDiagnostics') -Default '')
        PimDiagnostics        = [string](Get-HybridObjectValue -InputObject $GraphUser -Names @('PimRoleDiagnostic','PimRoleDiagnostics','PimDiagnostics','RoleDiagnostic','RoleDiagnostics') -Default '')
        AuthenticationMethods = @(Get-HybridObjectValue -InputObject $GraphUser -Names @('AuthenticationMethods','Methods') -Default @())
        AuthenticationMethodDetails = @(Get-HybridObjectValue -InputObject $GraphUser -Names @('AuthenticationMethodDetails','AuthMethodDetails','MethodDetails') -Default @())
        RiskState             = [string](Get-HybridObjectValue -InputObject $GraphUser -Names @('RiskState','UserRiskState','SignInRiskState','riskState') -Default 'none')
        UserRiskState         = [string](Get-HybridObjectValue -InputObject $GraphUser -Names @('UserRiskState','RiskState','riskState') -Default 'none')
        SignInRiskState       = [string](Get-HybridObjectValue -InputObject $GraphUser -Names @('SignInRiskState','RiskState','riskState') -Default 'none')
        RiskDetails           = @(Get-HybridObjectValue -InputObject $GraphUser -Names @('RiskDetails','RiskDetections','RiskySignIns') -Default @())
        Mailbox               = New-HybridMailboxSourceEnvelope -AdMailAttributes (New-HybridAdMailAttributeSnapshot -User $ActiveDirectoryUser) -ExchangeOnPremises $null -ExchangeOnline $Mailbox
        MailboxDetails        = $null
        ExchangeLoaded        = $false
        ExchangeRetrievedOn   = $null
        Sources               = @(
            ConvertTo-HybridSourceStatus -Name 'ActiveDirectory' -Object $ActiveDirectoryUser -ProviderHealth $ActiveDirectoryHealth
            ConvertTo-HybridSourceStatus -Name 'MicrosoftGraph' -Object $GraphUser -ProviderHealth $GraphHealth
            ConvertTo-HybridSourceStatus -Name 'ExchangeOnline' -Object $Mailbox -ProviderHealth $ExchangeHealth
            ConvertTo-HybridSourceStatus -Name 'ExchangeOnPremises' -Object $null -ProviderHealth $ExchangeOnPremisesHealth
        )
        Source                = 'HybridUserService'
        RetrievedOn           = [datetime]::UtcNow
        DetailsLoaded         = $false
        DetailRetrievedOn     = $null
    }

    $user.PSObject.TypeNames.Insert(0, 'Hybrid.User.VerticalSlice')
    Add-HybridUserActiveDirectoryIdentityMetadata -User $user -ActiveDirectoryUser $ActiveDirectoryUser | Out-Null
    Write-HybridUserHydrationDiagnostic -Stage 'BaseHydration' -Message 'Resolved Active Directory DN and OU metadata for composite user.' -Level INFO -Data ([pscustomobject]@{
        Identity = $Identity
        DistinguishedName = $user.DistinguishedName
        ActiveDirectoryDistinguishedName = $user.ActiveDirectoryDistinguishedName
        OrganizationalUnit = $user.OrganizationalUnit
        ActiveDirectoryIdentity = $user.ActiveDirectoryIdentity
        ActiveDirectoryUserProperties = if ($null -ne $ActiveDirectoryUser) { @($ActiveDirectoryUser.PSObject.Properties.Name) } else { @() }
    })
    return $user
}


function Add-HybridUserDetails {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][object]$User)

    $adIdentity = Get-HybridActiveDirectoryStableIdentity -User $User -ActiveDirectoryUser $null
    if ([string]::IsNullOrWhiteSpace($adIdentity)) {
        throw 'Unable to resolve a stable Active Directory identity for detail hydration.'
    }

    Write-HybridUserHydrationDiagnostic -Stage 'ActiveDirectoryDetails' -Message "Using stable Active Directory identity '$adIdentity' for detail hydration." -Level INFO -Data ([pscustomobject]@{
        InputIdentity = Get-HybridObjectValue -InputObject $User -Names @('Identity','UserPrincipalName','Mail') -Default ''
        ActiveDirectoryIdentity = $adIdentity
        DistinguishedName = Get-HybridObjectValue -InputObject $User -Names @('DistinguishedName','ActiveDirectoryDistinguishedName') -Default ''
        SamAccountName = Get-HybridObjectValue -InputObject $User -Names @('SamAccountName','ActiveDirectorySamAccountName') -Default ''
    })

    $groups = @()
    $directReports = @()
    $managerObject = $null

    try {
        $groups = @(Invoke-HybridServiceOperation -Service $script:HybridUserServiceState.ActiveDirectory -OperationNames @('GetUserGroups','GetGroups','GetADUserGroups') -Arguments @($adIdentity))
    }
    catch {
        Write-HybridUserHydrationDiagnostic -Stage 'ActiveDirectoryDetails' -Message "Group hydration failed for stable AD identity '$adIdentity' - $($_.Exception.Message)" -Level ERROR
    }

    try {
        $directReports = @(Invoke-HybridServiceOperation -Service $script:HybridUserServiceState.ActiveDirectory -OperationNames @('GetUserDirectReports','GetDirectReports','GetADUserDirectReports') -Arguments @($adIdentity))
    }
    catch {
        Write-HybridUserHydrationDiagnostic -Stage 'ActiveDirectoryDetails' -Message "Direct report hydration failed for stable AD identity '$adIdentity' - $($_.Exception.Message)" -Level ERROR
    }

    try {
        $managerObject = @(Invoke-HybridServiceOperation -Service $script:HybridUserServiceState.ActiveDirectory -OperationNames @('GetUserManager','GetManager','GetADUserManager') -Arguments @($adIdentity) | Select-Object -First 1)
    }
    catch {
        Write-HybridUserHydrationDiagnostic -Stage 'ActiveDirectoryDetails' -Message "Manager hydration failed for stable AD identity '$adIdentity' - $($_.Exception.Message)" -Level ERROR
    }

    if ($User.PSObject.Properties.Name -notcontains 'Groups') { Add-Member -InputObject $User -NotePropertyName Groups -NotePropertyValue @() }
    if ($User.PSObject.Properties.Name -notcontains 'DirectReports') { Add-Member -InputObject $User -NotePropertyName DirectReports -NotePropertyValue @() }
    if ($User.PSObject.Properties.Name -notcontains 'ManagerObject') { Add-Member -InputObject $User -NotePropertyName ManagerObject -NotePropertyValue $null }
    if ($User.PSObject.Properties.Name -notcontains 'DetailsLoaded') { Add-Member -InputObject $User -NotePropertyName DetailsLoaded -NotePropertyValue $false }
    if ($User.PSObject.Properties.Name -notcontains 'DetailRetrievedOn') { Add-Member -InputObject $User -NotePropertyName DetailRetrievedOn -NotePropertyValue $null }

    $User.Groups = @($groups)
    $User.DirectReports = @($directReports)
    $User.ManagerObject = ($managerObject | Select-Object -First 1)

    if ($null -ne $User.ManagerObject) {
        $managerName = Get-HybridObjectValue -InputObject $User.ManagerObject -Names @('DisplayName','Name','SamAccountName','UserPrincipalName') -Default $null
        if ($null -ne $managerName -and $User.PSObject.Properties.Name -contains 'ManagerDisplayName') {
            $User.ManagerDisplayName = [string]$managerName
        }
    }

    $User.DetailsLoaded = $true
    $User.DetailRetrievedOn = [datetime]::UtcNow
    return $User
}

function Add-HybridUserMailboxDetails {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][object]$User)

    $identityCandidates = @(
        (Get-HybridObjectValue -InputObject $User -Names @('UserPrincipalName') -Default $null),
        (Get-HybridObjectValue -InputObject $User -Names @('Mail') -Default $null),
        (Get-HybridObjectValue -InputObject $User -Names @('SamAccountName') -Default $null),
        (Get-HybridObjectValue -InputObject $User -Names @('Identity') -Default $null)
    ) | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) }

    $identity = [string]($identityCandidates | Select-Object -First 1)
    if ([string]::IsNullOrWhiteSpace($identity)) { return $User }

    $onPremRecipient = $null
    $onPremRemoteMailbox = $null
    $onPremForwarding = $null
    $onPremDistributionGroups = @()
    $adMailAttributes = New-HybridAdMailAttributeSnapshot -User $User
    $hasAdMailSignal = Test-HybridAdMailAttributeSnapshotHasMailSignal -Snapshot $adMailAttributes

    if ($null -ne $script:HybridUserServiceState.ExchangeOnPremises -and $hasAdMailSignal) {
        try {
            $onPremRemoteMailbox = @(Invoke-HybridServiceOperation -Service $script:HybridUserServiceState.ExchangeOnPremises -OperationNames @('GetRemoteMailbox') -Arguments @($identity) | Select-Object -First 1)
            $onPremRemoteMailbox = ($onPremRemoteMailbox | Select-Object -First 1)
        }
        catch {
            Write-HybridUserHydrationDiagnostic -Stage 'ExchangeOnPremises' -Message "Remote mailbox lookup failed for '$identity' - $($_.Exception.Message)" -Level WARN
        }

        try {
            $onPremRecipient = @(Invoke-HybridServiceOperation -Service $script:HybridUserServiceState.ExchangeOnPremises -OperationNames @('GetRecipient','GetExchangeRecipient','GetMailbox','Get') -Arguments @($identity) | Select-Object -First 1)
            $onPremRecipient = ($onPremRecipient | Select-Object -First 1)
        }
        catch {
            Write-HybridUserHydrationDiagnostic -Stage 'ExchangeOnPremises' -Message "Recipient lookup failed for '$identity' - $($_.Exception.Message)" -Level WARN
        }

        if ($null -ne $onPremRemoteMailbox -or $null -ne $onPremRecipient) {
            try {
                $onPremForwarding = @(Invoke-HybridServiceOperation -Service $script:HybridUserServiceState.ExchangeOnPremises -OperationNames @('GetMailboxForwarding','GetForwarding') -Arguments @($identity) | Select-Object -First 1)
                $onPremForwarding = ($onPremForwarding | Select-Object -First 1)
            }
            catch {
                Write-HybridUserHydrationDiagnostic -Stage 'ExchangeOnPremises' -Message "Forwarding lookup failed for '$identity' - $($_.Exception.Message)" -Level WARN
            }

            try {
                $onPremDistributionGroups = @(Invoke-HybridServiceOperation -Service $script:HybridUserServiceState.ExchangeOnPremises -OperationNames @('GetDistributionGroups','GetOwnedDistributionGroups','GetRecipientGroups') -Arguments @($identity))
            }
            catch {
                Write-HybridUserHydrationDiagnostic -Stage 'ExchangeOnPremises' -Message "Distribution group lookup failed for '$identity' - $($_.Exception.Message)" -Level WARN
                $onPremDistributionGroups = @()
            }
        }
    }
    elseif ($null -ne $script:HybridUserServiceState.ExchangeOnPremises) {
        Write-HybridUserHydrationDiagnostic -Stage 'ExchangeOnPremises' -Message "Skipped on-premises Exchange lookup for '$identity' because the directory record has no mail, proxy, target address, or alias signal." -Level INFO
    }

    $mailbox = $null
    if ($null -ne $script:HybridUserServiceState.ExchangeOnline -and $hasAdMailSignal) {
        try {
            $mailbox = @(Invoke-HybridServiceOperation -Service $script:HybridUserServiceState.ExchangeOnline -OperationNames @('GetMailbox','GetUserMailbox','Get') -Arguments @($identity) | Select-Object -First 1)
            $mailbox = ($mailbox | Select-Object -First 1)
            if (-not (Test-HybridExchangeMailboxObject -Mailbox $mailbox)) {
                Write-HybridUserHydrationDiagnostic -Stage 'ExchangeOnline' -Message "Exchange Online returned no concrete mailbox object for '$identity'; treating as mailboxless/synced-only account." -Level INFO
                $mailbox = $null
            }
        }
        catch {
            Write-HybridUserHydrationDiagnostic -Stage 'ExchangeOnline' -Message "Exchange Online mailbox lookup failed for '$identity' - $($_.Exception.Message)" -Level WARN
        }
    }
    elseif ($null -ne $script:HybridUserServiceState.ExchangeOnline) {
        Write-HybridUserHydrationDiagnostic -Stage 'ExchangeOnline' -Message "Skipped Exchange Online mailbox lookup for '$identity' because the directory record has no mail, proxy, target address, or alias signal. This is expected for ADM/admin-only accounts synced to Azure without mailboxes." -Level INFO
    }

    $effectiveMailbox = if ($null -ne $mailbox) { $mailbox } elseif ($null -ne $onPremRemoteMailbox) { $onPremRemoteMailbox } else { $onPremRecipient }
    $exchangeOnPremisesMailbox = if ($null -ne $onPremRemoteMailbox) { $onPremRemoteMailbox } else { $onPremRecipient }
    $mailboxSources = New-HybridMailboxSourceEnvelope -AdMailAttributes $adMailAttributes -ExchangeOnPremises $exchangeOnPremisesMailbox -ExchangeOnline $mailbox
    if ($null -eq $effectiveMailbox) {
        if ($User.PSObject.Properties.Name -notcontains 'ExchangeLoaded') { Add-Member -InputObject $User -NotePropertyName ExchangeLoaded -NotePropertyValue $false }
        if ($User.PSObject.Properties.Name -notcontains 'MailboxDetails') { Add-Member -InputObject $User -NotePropertyName MailboxDetails -NotePropertyValue $null }
        if ($User.PSObject.Properties.Name -notcontains 'OnPremisesExchangeRecipient') { Add-Member -InputObject $User -NotePropertyName OnPremisesExchangeRecipient -NotePropertyValue $null }
        if ($User.PSObject.Properties.Name -notcontains 'AdMailAttributes') { Add-Member -InputObject $User -NotePropertyName AdMailAttributes -NotePropertyValue $adMailAttributes }
        if ($User.PSObject.Properties.Name -notcontains 'ExchangeOnlineMailbox') { Add-Member -InputObject $User -NotePropertyName ExchangeOnlineMailbox -NotePropertyValue $null }
        $User.ExchangeLoaded = $false
        $User.MailboxDetails = $null
        $User.OnPremisesExchangeRecipient = $null
        $User.AdMailAttributes = $adMailAttributes
        $User.ExchangeOnlineMailbox = $null
        $User.Mailbox = $mailboxSources
        Write-HybridUserHydrationDiagnostic -Stage 'ExchangeMailbox' -Message 'No Exchange Online mailbox or Exchange On-Premises recipient data returned. AD mail attributes are not treated as Exchange mailbox data.' -Level WARN -Data ([pscustomobject]@{ Identity = $identity; ExchangeOnlineProviderRegistered = ($null -ne $script:HybridUserServiceState.ExchangeOnline); ExchangeOnPremisesProviderRegistered = ($null -ne $script:HybridUserServiceState.ExchangeOnPremises) })
        return $User
    }

    $statistics = @()
    $delegations = @()
    $distributionGroups = @()
    $forwarding = $null

    if ((Test-HybridExchangeMailboxObject -Mailbox $mailbox) -and $null -ne $script:HybridUserServiceState.ExchangeOnline) {
        $statistics = @(Invoke-HybridServiceOperation -Service $script:HybridUserServiceState.ExchangeOnline -OperationNames @('GetMailboxStatistics','GetMailboxStats','GetStatistics') -Arguments @($identity) | Select-Object -First 1)
        $delegations = @(Invoke-HybridServiceOperation -Service $script:HybridUserServiceState.ExchangeOnline -OperationNames @('GetMailboxDelegations','GetDelegations','GetMailboxPermissions','GetPermissions') -Arguments @($identity))
        $distributionGroups = @(Invoke-HybridServiceOperation -Service $script:HybridUserServiceState.ExchangeOnline -OperationNames @('GetDistributionGroups','GetOwnedDistributionGroups','GetRecipientGroups') -Arguments @($identity))
        $forwarding = @(Invoke-HybridServiceOperation -Service $script:HybridUserServiceState.ExchangeOnline -OperationNames @('GetMailboxForwarding','GetForwarding') -Arguments @($identity) | Select-Object -First 1)
    }

    if ((Get-HybridCollectionCount $distributionGroups) -eq 0 -and (Get-HybridCollectionCount $onPremDistributionGroups) -gt 0) { $distributionGroups = @($onPremDistributionGroups) }
    if ($null -eq $forwarding -and $null -ne $onPremForwarding) { $forwarding = $onPremForwarding }

    $primarySmtp = [string](Get-HybridObjectValue -InputObject $effectiveMailbox -Names @('PrimarySmtpAddress','WindowsEmailAddress','Mail','EmailAddress') -Default '')
    if ([string]::IsNullOrWhiteSpace($primarySmtp) -and $null -ne $onPremRecipient) {
        $primarySmtp = [string](Get-HybridObjectValue -InputObject $onPremRecipient -Names @('PrimarySmtpAddress','WindowsEmailAddress','Mail','EmailAddress') -Default '')
    }

    $recipientType = [string](Get-HybridObjectValue -InputObject $effectiveMailbox -Names @('RecipientTypeDetails','RecipientType','Type') -Default '')
    if ([string]::IsNullOrWhiteSpace($recipientType) -and $null -ne $onPremRecipient) {
        $recipientType = [string](Get-HybridObjectValue -InputObject $onPremRecipient -Names @('RecipientTypeDetails','RecipientType','Type') -Default '')
    }

    $mailboxDetails = [pscustomobject]@{
        PSTypeName = 'Hybrid.UserMailboxDetails'
        Mailbox = $effectiveMailbox
        AdMailAttributes = $adMailAttributes
        ExchangeOnlineMailbox = $mailbox
        ExchangeOnPremises = $exchangeOnPremisesMailbox
        OnPremisesRecipient = $onPremRecipient
        OnPremisesRemoteMailbox = $onPremRemoteMailbox
        SourceProvider = if ($null -ne $mailbox) { 'ExchangeOnline' } else { 'ExchangeOnPremises' }
        PrimarySmtpAddress = $primarySmtp
        RecipientTypeDetails = $recipientType
        HiddenFromAddressListsEnabled = Get-HybridObjectValue -InputObject $effectiveMailbox -Names @('HiddenFromAddressListsEnabled') -Default $null
        LitigationHoldEnabled = Get-HybridObjectValue -InputObject $effectiveMailbox -Names @('LitigationHoldEnabled') -Default $null
        RemoteRoutingAddress = Get-HybridObjectValue -InputObject $effectiveMailbox -Names @('RemoteRoutingAddress','TargetAddress') -Default (Get-HybridObjectValue -InputObject $onPremRecipient -Names @('RemoteRoutingAddress','TargetAddress') -Default $null)
        ForwardingSmtpAddress = Get-HybridObjectValue -InputObject $forwarding -Names @('ForwardingSmtpAddress','ForwardingAddress') -Default (Get-HybridObjectValue -InputObject $effectiveMailbox -Names @('ForwardingSmtpAddress','ForwardingAddress') -Default $null)
        DeliverToMailboxAndForward = Get-HybridObjectValue -InputObject $forwarding -Names @('DeliverToMailboxAndForward') -Default (Get-HybridObjectValue -InputObject $effectiveMailbox -Names @('DeliverToMailboxAndForward') -Default $null)
        Statistics = ($statistics | Select-Object -First 1)
        Delegations = @($delegations)
        DistributionGroups = @($distributionGroups)
        RetrievedOn = [datetime]::UtcNow
    }

    if ($User.PSObject.Properties.Name -notcontains 'OnPremisesExchangeRecipient') { Add-Member -InputObject $User -NotePropertyName OnPremisesExchangeRecipient -NotePropertyValue $onPremRecipient }
    if ($User.PSObject.Properties.Name -notcontains 'OnPremisesRemoteMailbox') { Add-Member -InputObject $User -NotePropertyName OnPremisesRemoteMailbox -NotePropertyValue $onPremRemoteMailbox }
    if ($User.PSObject.Properties.Name -notcontains 'AdMailAttributes') { Add-Member -InputObject $User -NotePropertyName AdMailAttributes -NotePropertyValue $adMailAttributes }
    if ($User.PSObject.Properties.Name -notcontains 'ExchangeOnlineMailbox') { Add-Member -InputObject $User -NotePropertyName ExchangeOnlineMailbox -NotePropertyValue $mailbox }
    if ($User.PSObject.Properties.Name -notcontains 'Mailbox') { Add-Member -InputObject $User -NotePropertyName Mailbox -NotePropertyValue $effectiveMailbox }
    if ($User.PSObject.Properties.Name -notcontains 'MailboxDetails') { Add-Member -InputObject $User -NotePropertyName MailboxDetails -NotePropertyValue $mailboxDetails }
    if ($User.PSObject.Properties.Name -notcontains 'ExchangeLoaded') { Add-Member -InputObject $User -NotePropertyName ExchangeLoaded -NotePropertyValue $false }
    if ($User.PSObject.Properties.Name -notcontains 'ExchangeRetrievedOn') { Add-Member -InputObject $User -NotePropertyName ExchangeRetrievedOn -NotePropertyValue $null }

    $User.OnPremisesExchangeRecipient = $onPremRecipient
    $User.OnPremisesRemoteMailbox = $onPremRemoteMailbox
    $User.AdMailAttributes = $adMailAttributes
    $User.ExchangeOnlineMailbox = $mailbox
    $User.Mailbox = $mailboxSources
    $User.MailboxDetails = $mailboxDetails
    $User.ExchangeLoaded = $true
    $User.ExchangeRetrievedOn = [datetime]::UtcNow
    return $User
}

function Initialize-HybridUserService {
    [CmdletBinding()]
    param(
        [AllowNull()][object]$ActiveDirectoryProvider,
        [AllowNull()][object]$MicrosoftGraphProvider,
        [AllowNull()][object]$ExchangeOnlineProvider,
        [AllowNull()][object]$ExchangeOnPremisesProvider
    )

    $script:HybridUserServiceState.ActiveDirectory = $ActiveDirectoryProvider
    $script:HybridUserServiceState.MicrosoftGraph = $MicrosoftGraphProvider
    $script:HybridUserServiceState.ExchangeOnline = $ExchangeOnlineProvider
    $script:HybridUserServiceState.ExchangeOnPremises = $ExchangeOnPremisesProvider
    $script:HybridUserServiceState.Initialized = $true
    $script:HybridUserServiceState.Cache.Clear()
    $script:HybridUserServiceState.DetailCache.Clear()
    $script:HybridUserServiceState.MailboxCache.Clear()

    [pscustomobject]@{
        PSTypeName = 'Hybrid.UserService'
        Name       = 'HybridUserService'
        Initialized = $true
        Providers  = @{
            ActiveDirectory = ($null -ne $ActiveDirectoryProvider)
            MicrosoftGraph  = ($null -ne $MicrosoftGraphProvider)
            ExchangeOnline  = ($null -ne $ExchangeOnlineProvider)
            ExchangeOnPremises = ($null -ne $ExchangeOnPremisesProvider)
        }
        SearchUser     = ({ param([string]$Query) Search-HybridUser -Query $Query }).GetNewClosure()
        GetUser        = ({ param([string]$Identity) Get-HybridUser -Identity $Identity }).GetNewClosure()
        GetUserDetails = ({ param([string]$Identity) Get-HybridUserDetails -Identity $Identity }).GetNewClosure()
        GetMailboxDetails = ({ param([string]$Identity) Get-HybridUserMailboxDetails -Identity $Identity }).GetNewClosure()
        GetHealth      = ({ Get-HybridUserServiceHealth }).GetNewClosure()
    }
}

function Search-HybridUser {
    [CmdletBinding()]
    param([string]$Query = '')

    if (-not $script:HybridUserServiceState.Initialized) { throw 'Hybrid user service has not been initialized.' }

    try {
        $script:HybridUserServiceState.LastQuery = $Query
        $adUsers = Invoke-HybridServiceOperationSafe -Service $script:HybridUserServiceState.ActiveDirectory -OperationNames @('SearchUser','SearchADUser','Search') -Arguments @($Query) -ProviderName 'ActiveDirectory'
        $graphUsers = Invoke-HybridServiceOperationSafe -Service $script:HybridUserServiceState.MicrosoftGraph -OperationNames @('SearchUser','SearchGraphUser','Search') -Arguments @($Query) -ProviderName 'MicrosoftGraph'
        Write-HybridUserHydrationDiagnostic -Stage 'Search' -Message "Search providers returned AD=$(@($adUsers).Count), Graph=$(@($graphUsers).Count) for query '$Query'." -Level INFO -Data ([pscustomobject]@{
            Query = $Query
            ActiveDirectoryResultCount = @($adUsers).Count
            MicrosoftGraphResultCount = @($graphUsers).Count
        })

        $candidateUsers = @()
        if (@($adUsers).Count -gt 0) { $candidateUsers += @($adUsers) }
        if (@($adUsers).Count -eq 0 -and @($graphUsers).Count -gt 0) { $candidateUsers += @($graphUsers) }

        if ((Get-HybridCollectionCount $candidateUsers) -eq 0) {
            Write-HybridUserHydrationDiagnostic -Stage 'Search' -Message "Search returned no candidates for '$Query'. Trying exact identity lookup before returning no results." -Level WARN
            $exactUser = @(Get-HybridUser -Identity $Query | Select-Object -First 1)
            $hasExactData = $false
            if ((Get-HybridCollectionCount $exactUser) -gt 0 -and $null -ne $exactUser[0]) {
                foreach ($sourceName in @('ActiveDirectory','MicrosoftGraph','ExchangeOnline','ExchangeOnPremises')) {
                    if ($exactUser[0].PSObject.Properties.Name -contains 'Sources' -and $null -ne $exactUser[0].Sources) {
                        $sourceStatus = $null
                        if ($exactUser[0].Sources -is [System.Collections.IDictionary] -and $exactUser[0].Sources.Contains($sourceName)) {
                            $sourceStatus = $exactUser[0].Sources[$sourceName]
                        }
                        elseif ($exactUser[0].Sources.PSObject.Properties.Name -contains $sourceName) {
                            $sourceStatus = $exactUser[0].Sources.$sourceName
                        }
                        else {
                            $sourceStatus = @($exactUser[0].Sources | Where-Object {
                                $_.PSObject.Properties.Name -contains 'Name' -and [string]$_.Name -eq $sourceName
                            } | Select-Object -First 1)
                            if ((Get-HybridCollectionCount $sourceStatus) -gt 0) { $sourceStatus = $sourceStatus[0] }
                        }
                        if ($null -ne $sourceStatus -and $sourceStatus.PSObject.Properties.Name -contains 'Available' -and [bool]$sourceStatus.Available) {
                            $hasExactData = $true
                        }
                    }
                }
            }
            if ($hasExactData) {
                $script:HybridUserServiceState.LastResult = @($exactUser)
                return @($exactUser)
            }
            $script:HybridUserServiceState.LastResult = @()
            return @()
        }

        $results = @()
        $seen = @{}
        foreach ($candidate in $candidateUsers) {
            $identity = [string](Get-HybridObjectValue -InputObject $candidate -Names @('UserPrincipalName','UPN','SamAccountName','Identity','Mail','DistinguishedName') -Default $Query)
            if ([string]::IsNullOrWhiteSpace($identity)) { continue }
            $dedupeKey = $identity.ToLowerInvariant()
            if ($seen.ContainsKey($dedupeKey)) { continue }
            $seen[$dedupeKey] = $true
            try { $results += @(Get-HybridUser -Identity $identity) }
            catch {
                Write-HybridUserHydrationDiagnostic -Stage 'Search' -Message "Candidate hydration failed for '$identity' - $($_.Exception.Message)" -Level WARN
            }
        }

        $script:HybridUserServiceState.LastResult = @($results)
        return @($results)
    }
    catch {
        $script:HybridUserServiceState.LastError = $_.Exception.Message
        throw
    }
}

function Get-HybridUser {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Identity)

    if (-not $script:HybridUserServiceState.Initialized) { throw 'Hybrid user service has not been initialized.' }
    if ([string]::IsNullOrWhiteSpace($Identity)) { throw 'User identity cannot be empty.' }

    $cacheKey = $Identity.ToLowerInvariant()
    if ($script:HybridUserServiceState.Cache.ContainsKey($cacheKey)) {
        return $script:HybridUserServiceState.Cache[$cacheKey]
    }

    $adUser = @(Invoke-HybridServiceOperationSafe -Service $script:HybridUserServiceState.ActiveDirectory -OperationNames @('GetUser','GetADUser','Get') -Arguments @($Identity) -ProviderName 'ActiveDirectory' | Select-Object -First 1)
    $adResolvedUser = if ((Get-HybridCollectionCount $adUser) -gt 0) { $adUser[0] } else { $null }
    $graphUser = @(Invoke-HybridGraphUserProviderLookup -Identity $Identity -ActiveDirectoryUser $adResolvedUser -OperationNames @('GetUser','GetGraphUser','Get') | Select-Object -First 1)
    $mailbox = @()
    $adMailSignal = $false
    if ($null -ne $adResolvedUser) {
        $adMailSignal = Test-HybridAdMailAttributeSnapshotHasMailSignal -Snapshot (New-HybridAdMailAttributeSnapshot -User $adResolvedUser)
    }
    if ($null -ne $script:HybridUserServiceState.ExchangeOnline -and $adMailSignal) {
        try {
            $mailbox = @(Invoke-HybridServiceOperationSafe -Service $script:HybridUserServiceState.ExchangeOnline -OperationNames @('GetMailbox','GetUserMailbox','Get') -Arguments @($Identity) -ProviderName 'ExchangeOnline' | Select-Object -First 1)
        }
        catch {
            Write-HybridUserHydrationDiagnostic -Stage 'ExchangeOnline' -Message "Base Exchange Online mailbox lookup deferred or unavailable for '$Identity' - $($_.Exception.Message)" -Level WARN
            $mailbox = @()
        }
    }
    elseif ($null -ne $script:HybridUserServiceState.ExchangeOnline) {
        Write-HybridUserHydrationDiagnostic -Stage 'ExchangeOnline' -Message "Skipped base Exchange Online mailbox lookup for '$Identity' because AD has no SMTP mail, proxyAddress, or targetAddress signal. This is expected for mailboxless ADM/admin accounts synced to Azure." -Level INFO
    }
    Write-HybridUserHydrationDiagnostic -Stage 'BaseHydration' -Message "Base hydration results AD=$(@($adUser).Count), Graph=$(@($graphUser).Count), Exchange=$(@($mailbox).Count) for identity '$Identity'." -Level INFO -Data ([pscustomobject]@{
        Identity = $Identity
        ActiveDirectoryResultCount = @($adUser).Count
        MicrosoftGraphResultCount = @($graphUser).Count
        ExchangeMailboxResultCount = @($mailbox).Count
    })

    $adHealth = Get-HybridProviderHealthSnapshot -Service $script:HybridUserServiceState.ActiveDirectory
    $graphHealth = Get-HybridProviderHealthSnapshot -Service $script:HybridUserServiceState.MicrosoftGraph
    $exchangeHealth = Get-HybridProviderHealthSnapshot -Service $script:HybridUserServiceState.ExchangeOnline
    $exchangeOnPremisesHealth = Get-HybridProviderHealthSnapshot -Service $script:HybridUserServiceState.ExchangeOnPremises

    $user = New-HybridCompositeUser `
        -Identity $Identity `
        -ActiveDirectoryUser $adResolvedUser `
        -GraphUser ($graphUser | Select-Object -First 1) `
        -Mailbox ($mailbox | Select-Object -First 1) `
        -ActiveDirectoryHealth $adHealth `
        -GraphHealth $graphHealth `
        -ExchangeHealth $exchangeHealth `
        -ExchangeOnPremisesHealth $exchangeOnPremisesHealth

    $script:HybridUserServiceState.Cache[$cacheKey] = $user
    return $user
}

function Get-HybridUserDetails {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Identity)

    if (-not $script:HybridUserServiceState.Initialized) { throw 'Hybrid user service has not been initialized.' }
    if ([string]::IsNullOrWhiteSpace($Identity)) { throw 'User identity cannot be empty.' }

    $cacheKey = $Identity.ToLowerInvariant()
    if ($script:HybridUserServiceState.DetailCache.ContainsKey($cacheKey)) {
        return $script:HybridUserServiceState.DetailCache[$cacheKey]
    }

    $user = Get-HybridUser -Identity $Identity
    $detailedUser = Add-HybridUserDetails -User $user
    $script:HybridUserServiceState.DetailCache[$cacheKey] = $detailedUser
    return $detailedUser
}

function Get-HybridUserMailboxDetails {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Identity)

    if (-not $script:HybridUserServiceState.Initialized) { throw 'Hybrid user service has not been initialized.' }
    if ([string]::IsNullOrWhiteSpace($Identity)) { throw 'User identity cannot be empty.' }

    $cacheKey = $Identity.ToLowerInvariant()
    if ($script:HybridUserServiceState.MailboxCache.ContainsKey($cacheKey)) {
        return $script:HybridUserServiceState.MailboxCache[$cacheKey]
    }

    $user = Get-HybridUserDetails -Identity $Identity
    $exchangeUser = Add-HybridUserMailboxDetails -User $user
    $script:HybridUserServiceState.MailboxCache[$cacheKey] = $exchangeUser
    return $exchangeUser
}

function Get-HybridUserServiceHealth {
    [CmdletBinding()]
    param()

    [pscustomobject]@{
        PSTypeName    = 'Hybrid.UserServiceHealth'
        Initialized   = [bool]$script:HybridUserServiceState.Initialized
        Providers     = @{
            ActiveDirectory = ($null -ne $script:HybridUserServiceState.ActiveDirectory)
            MicrosoftGraph  = ($null -ne $script:HybridUserServiceState.MicrosoftGraph)
            ExchangeOnline  = ($null -ne $script:HybridUserServiceState.ExchangeOnline)
            ExchangeOnPremises = ($null -ne $script:HybridUserServiceState.ExchangeOnPremises)
        }
        ProviderHealth     = @{
            ActiveDirectory = Get-HybridProviderHealthSnapshot -Service $script:HybridUserServiceState.ActiveDirectory
            MicrosoftGraph  = Get-HybridProviderHealthSnapshot -Service $script:HybridUserServiceState.MicrosoftGraph
            ExchangeOnline  = Get-HybridProviderHealthSnapshot -Service $script:HybridUserServiceState.ExchangeOnline
            ExchangeOnPremises = Get-HybridProviderHealthSnapshot -Service $script:HybridUserServiceState.ExchangeOnPremises
        }
        CacheEntries       = (Get-HybridCollectionCount $script:HybridUserServiceState.Cache)
        DetailCacheEntries = (Get-HybridCollectionCount $script:HybridUserServiceState.DetailCache)
        MailboxCacheEntries = (Get-HybridCollectionCount $script:HybridUserServiceState.MailboxCache)
        LastQuery          = $script:HybridUserServiceState.LastQuery
        LastError          = $script:HybridUserServiceState.LastError
    }
}

function Clear-HybridUserService {
    [CmdletBinding()]
    param()

    $script:HybridUserServiceState.Initialized = $false
    $script:HybridUserServiceState.ActiveDirectory = $null
    $script:HybridUserServiceState.MicrosoftGraph = $null
    $script:HybridUserServiceState.ExchangeOnline = $null
    $script:HybridUserServiceState.ExchangeOnPremises = $null
    $script:HybridUserServiceState.Cache.Clear()
    $script:HybridUserServiceState.DetailCache.Clear()
    $script:HybridUserServiceState.MailboxCache.Clear()
    $script:HybridUserServiceState.LastQuery = $null
    $script:HybridUserServiceState.LastResult = $null
    $script:HybridUserServiceState.LastError = $null
    return $true
}


#region Milestone 7 Phase 5 - Microsoft Graph Profile Extension
function Get-HybridUserGraphProfile {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Identity)

    if (-not $script:HybridUserServiceState.Initialized) { throw 'Hybrid user service has not been initialized.' }
    if ([string]::IsNullOrWhiteSpace($Identity)) { throw 'User identity cannot be empty.' }

    $profile = @(Invoke-HybridGraphUserProviderLookup -Identity $Identity -OperationNames @('GetGraphProfile','GetUserGraphProfile','GetAuthenticationProfile','GetUser','GetGraphUser','Get') | Select-Object -First 1)
    if ((Get-HybridCollectionCount $profile) -eq 0 -or $null -eq $profile[0]) { return $null }

    $raw = $profile[0]
    $methods = @(Get-HybridObjectValue -InputObject $raw -Names @('AuthenticationMethods','Methods') -Default @())
    $methodDetails = @(Get-HybridObjectValue -InputObject $raw -Names @('AuthenticationMethodDetails','AuthMethodDetails','MethodDetails') -Default @())
    $licenses = @(Get-HybridObjectValue -InputObject $raw -Names @('Licenses','licenses') -Default @())
    $assignedLicenses = @(Get-HybridObjectValue -InputObject $raw -Names @('AssignedLicenses','assignedLicenses') -Default @())
    if ((Get-HybridCollectionCount $licenses) -eq 0 -and (Get-HybridCollectionCount $assignedLicenses) -gt 0) { $licenses = @($assignedLicenses) }
    if ((Get-HybridCollectionCount $assignedLicenses) -eq 0 -and (Get-HybridCollectionCount $licenses) -gt 0) { $assignedLicenses = @($licenses) }
    $licenseAssignmentStates = @(Get-HybridObjectValue -InputObject $raw -Names @('LicenseAssignmentStates','licenseAssignmentStates') -Default @())
    $pimRoles = @(Get-HybridObjectValue -InputObject $raw -Names @('PimRoles','PIMRoles','PrivilegedIdentityRoles','DirectoryRoles','AzureRoles') -Default @())
    $directoryRoles = @(Get-HybridObjectValue -InputObject $raw -Names @('DirectoryRoles','AzureRoles') -Default @())
    if ((Get-HybridCollectionCount $directoryRoles) -eq 0 -and (Get-HybridCollectionCount $pimRoles) -gt 0) { $directoryRoles = @($pimRoles) }
    $graphDiagnostics = @(Get-HybridObjectValue -InputObject $raw -Names @('GraphDiagnostics','Diagnostics') -Default @())
    $licenseDiagnostic = [string](Get-HybridObjectValue -InputObject $raw -Names @('LicenseDiagnostic','LicenseDiagnostics') -Default '')
    $pimDiagnostic = [string](Get-HybridObjectValue -InputObject $raw -Names @('PimRoleDiagnostic','PimRoleDiagnostics','PimDiagnostics','RoleDiagnostic','RoleDiagnostics') -Default '')
    $riskState = [string](Get-HybridObjectValue -InputObject $raw -Names @('RiskState','UserRiskState','SignInRiskState','riskState') -Default 'none')
    $userRiskState = [string](Get-HybridObjectValue -InputObject $raw -Names @('UserRiskState','RiskState','riskState') -Default $riskState)
    $signInRiskState = [string](Get-HybridObjectValue -InputObject $raw -Names @('SignInRiskState','RiskState','riskState') -Default $riskState)
    $riskDetails = @(Get-HybridObjectValue -InputObject $raw -Names @('RiskDetails','RiskDetections','RiskySignIns') -Default @())
    $graphProfile = [pscustomobject]@{
        PSTypeName = 'Hybrid.GraphProfile'
        ObjectId = [string](Get-HybridObjectValue -InputObject $raw -Names @('ObjectId','Id','GraphObjectId') -Default '')
        UserPrincipalName = [string](Get-HybridObjectValue -InputObject $raw -Names @('UserPrincipalName','UPN') -Default $Identity)
        DisplayName = [string](Get-HybridObjectValue -InputObject $raw -Names @('DisplayName','Name') -Default $Identity)
        UserType = [string](Get-HybridObjectValue -InputObject $raw -Names @('UserType') -Default 'Member')
        PreferredLanguage = [string](Get-HybridObjectValue -InputObject $raw -Names @('PreferredLanguage') -Default 'en-US')
        UsageLocation = [string](Get-HybridObjectValue -InputObject $raw -Names @('UsageLocation') -Default 'US')
        LastSignInDateTime = Get-HybridObjectValue -InputObject $raw -Names @('LastSignInDateTime','LastSignIn','SignInActivity') -Default $null
        LastNonInteractiveSignInDateTime = Get-HybridObjectValue -InputObject $raw -Names @('LastNonInteractiveSignInDateTime','LastNonInteractiveSignIn') -Default $null
        PasswordLastChangedDateTime = Get-HybridObjectValue -InputObject $raw -Names @('PasswordLastChangedDateTime','LastPasswordChange','PasswordLastChanged') -Default $null
        AuthenticationMethods = @($methods)
        AuthenticationMethodDetails = @($methodDetails)
        Licenses = @($licenses)
        AssignedLicenses = @($assignedLicenses)
        LicenseAssignmentStates = @($licenseAssignmentStates)
        PimRoles = @($pimRoles)
        DirectoryRoles = @($directoryRoles)
        GraphDiagnostics = @($graphDiagnostics)
        LicenseDiagnostic = $licenseDiagnostic
        LicenseDiagnostics = $licenseDiagnostic
        PimRoleDiagnostic = $pimDiagnostic
        PimRoleDiagnostics = $pimDiagnostic
        PimDiagnostics = $pimDiagnostic
        MfaRegistered = [bool](Get-HybridObjectValue -InputObject $raw -Names @('MfaRegistered','MfaEnabled','IsMfaRegistered') -Default $false)
        MfaCapable = [bool](Get-HybridObjectValue -InputObject $raw -Names @('MfaCapable','IsMfaCapable') -Default $false)
        RiskState = $riskState
        UserRiskState = $userRiskState
        SignInRiskState = $signInRiskState
        RiskDetails = @($riskDetails)
        Source = [string](Get-HybridObjectValue -InputObject $raw -Names @('Source') -Default 'MicrosoftGraph')
        RetrievedOn = [datetime]::UtcNow
    }
    $graphProfile.PSObject.TypeNames.Insert(0, 'Hybrid.GraphProfile.Milestone7Phase5')
    return $graphProfile
}
#endregion

#region Milestone 7 Phase 6 - Authentication Profile Extension
function Get-HybridUserAuthenticationProfile {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Identity)

    if (-not $script:HybridUserServiceState.Initialized) { throw 'Hybrid user service has not been initialized.' }
    if ([string]::IsNullOrWhiteSpace($Identity)) { throw 'User identity cannot be empty.' }

    $profile = @(Invoke-HybridGraphUserProviderLookup -Identity $Identity -OperationNames @('GetAuthenticationProfile','GetUserAuthenticationProfile','GetGraphAuthenticationProfile','GetGraphProfile','GetUserGraphProfile','GetUser','GetGraphUser','Get') | Select-Object -First 1)
    if ((Get-HybridCollectionCount $profile) -eq 0 -or $null -eq $profile[0]) { return $null }

    $raw = $profile[0]
    $methods = @(Get-HybridObjectValue -InputObject $raw -Names @('AuthenticationMethods','Methods') -Default @())
    $methodDetails = @(Get-HybridObjectValue -InputObject $raw -Names @('AuthenticationMethodDetails','AuthMethodDetails','MethodDetails') -Default @())
    $defaultMethod = [string](Get-HybridObjectValue -InputObject $raw -Names @('DefaultMethod','DefaultAuthenticationMethod') -Default '')
    if ([string]::IsNullOrWhiteSpace($defaultMethod)) { $defaultMethod = if ((Get-HybridCollectionCount $methods) -gt 0) { [string]$methods[0] } else { 'password' } }
    $riskState = [string](Get-HybridObjectValue -InputObject $raw -Names @('SignInRiskState','RiskState','UserRiskState','riskState') -Default 'none')
    $userRiskState = [string](Get-HybridObjectValue -InputObject $raw -Names @('UserRiskState','RiskState','riskState') -Default $riskState)
    $riskLevel = [string](Get-HybridObjectValue -InputObject $raw -Names @('RiskLevel','riskLevel','RiskState','SignInRiskState') -Default $riskState)
    $riskDetails = @(Get-HybridObjectValue -InputObject $raw -Names @('RiskDetails','RiskDetections','RiskySignIns') -Default @())
    $conditionalAccessDetails = @(Get-HybridObjectValue -InputObject $raw -Names @('ConditionalAccessDetails','ConditionalAccessPolicies','AppliedConditionalAccessPolicies') -Default @())

    $authProfile = [pscustomobject]@{
        PSTypeName = 'Hybrid.AuthenticationProfile'
        UserPrincipalName = [string](Get-HybridObjectValue -InputObject $raw -Names @('UserPrincipalName','UPN') -Default $Identity)
        DisplayName = [string](Get-HybridObjectValue -InputObject $raw -Names @('DisplayName','Name') -Default $Identity)
        DefaultMethod = $defaultMethod
        AuthenticationMethods = @($methods)
        AuthenticationMethodDetails = @($methodDetails)
        MfaRegistered = [bool](Get-HybridObjectValue -InputObject $raw -Names @('MfaRegistered','MfaEnabled','IsMfaRegistered') -Default $false)
        MfaCapable = [bool](Get-HybridObjectValue -InputObject $raw -Names @('MfaCapable','IsMfaCapable') -Default $false)
        PasswordlessRegistered = [bool](Get-HybridObjectValue -InputObject $raw -Names @('PasswordlessRegistered','IsPasswordlessRegistered') -Default $false)
        TemporaryAccessPassEligible = [bool](Get-HybridObjectValue -InputObject $raw -Names @('TemporaryAccessPassEligible','TapEligible') -Default $false)
        AuthenticationStrength = [string](Get-HybridObjectValue -InputObject $raw -Names @('AuthenticationStrength','StrongAuthenticationRequirement') -Default 'Single-factor')
        ConditionalAccessState = [string](Get-HybridObjectValue -InputObject $raw -Names @('ConditionalAccessState','ConditionalAccess') -Default 'Not evaluated')
        ConditionalAccessDetails = @($conditionalAccessDetails)
        SignInRiskState = $riskState
        UserRiskState = $userRiskState
        RiskLevel = $riskLevel
        RiskDetails = @($riskDetails)
        LastMfaRegistrationDateTime = Get-HybridObjectValue -InputObject $raw -Names @('LastMfaRegistrationDateTime','MfaRegisteredOn') -Default $null
        LastSuccessfulSignInDateTime = Get-HybridObjectValue -InputObject $raw -Names @('LastSuccessfulSignInDateTime','LastSignInDateTime','LastSignIn') -Default $null
        PasswordLastChangedDateTime = Get-HybridObjectValue -InputObject $raw -Names @('PasswordLastChangedDateTime','PasswordLastChanged','LastPasswordChange') -Default $null
        Source = [string](Get-HybridObjectValue -InputObject $raw -Names @('Source') -Default 'MicrosoftGraph')
        RetrievedOn = [datetime]::UtcNow
    }
    $authProfile.PSObject.TypeNames.Insert(0, 'Hybrid.AuthenticationProfile.Milestone7Phase6')
    return $authProfile
}
#endregion
Export-ModuleMember -Function @(
    'Initialize-HybridUserService',
    'Search-HybridUser',
    'Get-HybridUser',
    'Get-HybridUserDetails',
    'Get-HybridUserMailboxDetails',
    'Get-HybridUserGraphProfile',
    
    'Get-HybridUserAuthenticationProfile',
    'Get-HybridUserServiceHealth',
    'Clear-HybridUserService'
)
